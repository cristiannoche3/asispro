import React, { useState, useCallback } from 'react';
import { INSTITUTIONAL_COLORS, APP_TITLE, AUTHOR_NAME } from '../constants';
import Button from './Button'; 
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';

const CORRECT_PASSWORD = "160721";
const SECURITY_QUESTIONS = [
  { question: "¿Cuál fue tu colegio favorito donde estudiaste?", answer: "rodolfo morales" },
  { question: "¿Cómo se llama tu perro?", answer: "miller" },
  { question: "¿Cuál es tu juego favorito?", answer: "fifa" },
];

interface LoginScreenProps {
  onLoginSuccess: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
  const [passwordInput, setPasswordInput] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  
  const [showRecovery, setShowRecovery] = useState(false);
  const [recoveryStep, setRecoveryStep] = useState(0);
  const [currentRecoveryAnswer, setCurrentRecoveryAnswer] = useState('');
  const [recoveryError, setRecoveryError] = useState('');
  const [recoverySuccessMessage, setRecoverySuccessMessage] = useState('');

  const handlePasswordSubmit = useCallback((e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (passwordInput === CORRECT_PASSWORD) {
      onLoginSuccess();
    } else {
      setLoginError('Contraseña incorrecta. Por favor, inténtelo de nuevo.');
      setPasswordInput('');
    }
  }, [passwordInput, onLoginSuccess]);

  const handleShowRecovery = useCallback(() => {
    setShowRecovery(true);
    setLoginError('');
    setPasswordInput('');
    setShowPassword(false);
    setRecoveryStep(0);
    setCurrentRecoveryAnswer('');
    setRecoveryError('');
    setRecoverySuccessMessage('');
  }, []);

  const handleBackToLogin = useCallback(() => {
    setShowRecovery(false);
    setRecoveryStep(0);
    setCurrentRecoveryAnswer('');
    setRecoveryError('');
    setRecoverySuccessMessage('');
  }, []);

  const handleRecoverySubmit = useCallback((e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const currentQuestionSet = SECURITY_QUESTIONS[recoveryStep];
    if (currentRecoveryAnswer.trim().toLowerCase() === currentQuestionSet.answer.toLowerCase()) {
      setRecoveryError('');
      setCurrentRecoveryAnswer('');
      if (recoveryStep < SECURITY_QUESTIONS.length - 1) {
        setRecoveryStep(prev => prev + 1);
      } else {
        setRecoverySuccessMessage(`Verificación exitosa. La contraseña es: ${CORRECT_PASSWORD}`);
      }
    } else {
      setRecoveryError('Respuesta incorrecta. Por favor, inténtelo de nuevo.');
      setCurrentRecoveryAnswer('');
    }
  }, [recoveryStep, currentRecoveryAnswer]);

  const renderLoginForm = () => (
    <form onSubmit={handlePasswordSubmit} className="space-y-6">
      <div>
        <label htmlFor="password" className={`block text-sm font-medium text-gray-700 mb-1`}>
          Contraseña de Acceso
        </label>
        <div className="relative">
            <input
            type={showPassword ? "text" : "password"}
            id="password"
            value={passwordInput}
            onChange={(e) => { setPasswordInput(e.target.value); setLoginError(''); }}
            className={`mt-1 block w-full px-4 py-3 pr-10 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-${INSTITUTIONAL_COLORS.BLUE} focus:border-${INSTITUTIONAL_COLORS.BLUE} text-lg transition-transform duration-150 focus:scale-[1.01]`}
            required
            aria-describedby="login-error"
            />
            <button
                type="button"
                onClick={() => setShowPassword(!showPassword)}
                className="absolute inset-y-0 right-0 px-3 flex items-center text-gray-500 hover:text-institucional-blue"
                aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
            >
                {showPassword ? <EyeSlashIcon className="h-5 w-5" /> : <EyeIcon className="h-5 w-5" />}
            </button>
        </div>
      </div>
      {loginError && <p id="login-error" className="text-sm text-red-600">{loginError}</p>}
      <div className="flex flex-col space-y-3 pt-2">
        <Button type="submit" variant="primary" size="lg" className="w-full !text-lg !font-semibold !py-3">
          Ingresar
        </Button>
        <Button type="button" variant="ghost" size="md" onClick={handleShowRecovery} className="w-full !text-sm !text-institucional-blue hover:!bg-sky-50 !font-normal">
          ¿Olvidó la contraseña?
        </Button>
      </div>
    </form>
  );

  const renderRecoveryForm = () => {
    if (recoverySuccessMessage) {
      return (
        <div className="space-y-6 text-center">
          <p className="text-lg text-green-700 font-semibold">{recoverySuccessMessage}</p>
          <Button onClick={handleBackToLogin} variant="primary" size="md" className="w-full sm:w-auto">
            Volver al Inicio de Sesión
          </Button>
        </div>
      );
    }

    const currentQuestion = SECURITY_QUESTIONS[recoveryStep];
    return (
      <form onSubmit={handleRecoverySubmit} className="space-y-6">
        <div className="text-center">
            <p className={`text-md font-medium text-gray-600`}>
            Pregunta de Seguridad {recoveryStep + 1} de {SECURITY_QUESTIONS.length}:
            </p>
            <p className="text-lg text-institucional-blue mt-1">{currentQuestion.question}</p>
        </div>
        <div>
          <label htmlFor="recoveryAnswer" className="sr-only">
            Respuesta
          </label>
          <input
            type="text"
            id="recoveryAnswer"
            value={currentRecoveryAnswer}
            onChange={(e) => { setCurrentRecoveryAnswer(e.target.value); setRecoveryError(''); }}
            className={`mt-1 block w-full px-4 py-3 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-${INSTITUTIONAL_COLORS.BLUE} focus:border-${INSTITUTIONAL_COLORS.BLUE} text-lg transition-transform duration-150 focus:scale-[1.01]`}
            required
            placeholder="Escriba su respuesta aquí"
            aria-describedby="recovery-error"
          />
        </div>
        {recoveryError && <p id="recovery-error" className="text-sm text-red-600">{recoveryError}</p>}
        <div className="flex flex-col sm:flex-row-reverse sm:justify-between sm:items-center gap-3 pt-2">
          <Button type="submit" variant="primary" size="md" className="w-full sm:w-auto !font-semibold">
            {recoveryStep < SECURITY_QUESTIONS.length - 1 ? 'Siguiente Pregunta' : 'Verificar Respuesta'}
          </Button>
          <Button type="button" variant="ghost" size="md" onClick={handleBackToLogin} className="w-full sm:w-auto !text-sm !text-gray-600 hover:!text-institucional-blue !font-normal">
            Cancelar Recuperación
          </Button>
        </div>
      </form>
    );
  };

  return (
    <div className={`min-h-screen bg-gradient-to-br from-sky-100 via-blue-100 to-sky-200 flex flex-col justify-center items-center p-4`}>
      <div className={`w-full max-w-md bg-white shadow-xl rounded-2xl p-8 md:p-10`}>
        {/* Placeholder for an institutional logo or avatar if desired */}
        {/* <div className="text-center mb-6">
          <img src="/path-to-your-logo.png" alt="Logo Institucional" className="mx-auto h-16 w-auto" /> 
        </div> */}
        
        <div className="text-center mb-8">
          <h1 className={`text-5xl font-bold text-${INSTITUTIONAL_COLORS.YELLOW} mb-2 asispro-logo-animated`}>{APP_TITLE}</h1>
          <p className={`text-lg text-${INSTITUTIONAL_COLORS.BLUE} font-semibold`}>
            {showRecovery ? 'Recuperación de Contraseña' : 'Inicio de Sesión Seguro'}
          </p>
        </div>
        
        {showRecovery ? renderRecoveryForm() : renderLoginForm()}
        
        <p className="text-xs text-gray-400 text-center mt-10">
          {AUTHOR_NAME}
        </p>
      </div>
    </div>
  );
};

export default LoginScreen;
