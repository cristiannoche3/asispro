
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Grade, Student, Period, AttendanceRecord, AttendanceStatus, ScreenView } from '../types';
import Button from './Button';
import Modal from './Modal'; 
import { INSTITUTIONAL_COLORS, CLASS_HOURS, COMPUTER_NUMBERS } from '../constants';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface TakeAttendanceScreenProps {
  grades: Grade[];
  students: Student[];
  periods: Period[];
  activePeriodId: string | null;
  attendanceRecords: AttendanceRecord[];
  saveAttendanceRecord: (recordToSave: AttendanceRecord) => void;
  setCurrentView: (view: ScreenView) => void;
  attendanceToEdit: AttendanceRecord | null;
  clearAttendanceToEdit: () => void;
  initialContext: { gradeId: string; date: string } | null;
  clearInitialContext: () => void;
  recentlySavedContexts: Set<string>;
  markContextAsSaved: (contextKey: string) => void;
  consumeSavedContext: (contextKey: string) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const today = new Date().toISOString().split('T')[0];

const TakeAttendanceScreen: React.FC<TakeAttendanceScreenProps> = ({
  grades,
  students,
  periods,
  activePeriodId,
  attendanceRecords,
  saveAttendanceRecord,
  setCurrentView,
  attendanceToEdit,
  clearAttendanceToEdit,
  initialContext,
  clearInitialContext,
  recentlySavedContexts,
  markContextAsSaved,
  consumeSavedContext,
  goBack,
  canGoBack
}) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>(initialContext?.gradeId || (grades.length > 0 ? grades[0].id : ''));
  const [selectedDate, setSelectedDate] = useState<string>(initialContext?.date || today);
  const [selectedClassHours, setSelectedClassHours] = useState<number[]>([]);
  const [currentStudentStatuses, setCurrentStudentStatuses] = useState<Map<string, AttendanceStatus>>(new Map());
  const [currentUsedComputers, setCurrentUsedComputers] = useState<Map<string, number>>(new Map());
  
  const [isSaveConfirmModalOpen, setIsSaveConfirmModalOpen] = useState(false);

  const studentsInSelectedGrade = useMemo(() => {
    return students
      .filter(s => s.gradeId === selectedGradeId)
      .sort((a, b) => a.assignedComputer - b.assignedComputer);
  }, [students, selectedGradeId]);

  const activePeriod = useMemo(() => {
    return periods.find(p => p.id === activePeriodId);
  }, [periods, activePeriodId]);

  const currentContextKey = useMemo(() => {
    if (!selectedGradeId || !selectedDate || !activePeriodId) return '';
    return `${selectedGradeId}_${selectedDate}_${activePeriodId}`;
  }, [selectedGradeId, selectedDate, activePeriodId]);
  
  useEffect(() => {
    // Initialize or reset form based on context
    const newStatusesMapLocal = new Map<string, AttendanceStatus>();
    const newUsedComputersMapLocal = new Map<string, number>();
    
    if (initialContext) {
      setSelectedGradeId(initialContext.gradeId);
      setSelectedDate(initialContext.date);
      // For initialContext, always start with a clean slate for a new "toma"
      students.filter(s => s.gradeId === initialContext.gradeId).forEach(student => {
          newStatusesMapLocal.set(student.id, AttendanceStatus.PRESENT); 
          newUsedComputersMapLocal.set(student.id, student.assignedComputer); 
      });
      setCurrentStudentStatuses(newStatusesMapLocal);
      setCurrentUsedComputers(newUsedComputersMapLocal);
      setSelectedClassHours([]);
      
      if (activePeriodId) {
        consumeSavedContext(`${initialContext.gradeId}_${initialContext.date}_${activePeriodId}`);
      }
      clearInitialContext(); // Consume initialContext after applying it
      return; // Exit early
    }

    if (attendanceToEdit) {
      setSelectedGradeId(attendanceToEdit.gradeId);
      setSelectedDate(attendanceToEdit.date);
      setSelectedClassHours([...attendanceToEdit.classHours]);

      students.filter(s => s.gradeId === attendanceToEdit.gradeId).forEach(student => {
        // Try to find if this student was part of the "toma" being edited
        const recordForThisStudentInToma = attendanceRecords.find(ar => 
            ar.studentId === student.id &&
            ar.date === attendanceToEdit.date &&
            ar.periodId === attendanceToEdit.periodId &&
            ar.classHours.join(',') === attendanceToEdit.classHours.join(',')
        );

        let statusForStudentInEditCtx = AttendanceStatus.PRESENT;
        let computerForStudentInEditCtx = student.assignedComputer;

        if (recordForThisStudentInToma) {
            statusForStudentInEditCtx = recordForThisStudentInToma.status;
            if (recordForThisStudentInToma.status === AttendanceStatus.ABSENT_UNEXCUSED || recordForThisStudentInToma.status === AttendanceStatus.ABSENT_EXCUSED) {
                computerForStudentInEditCtx = 0; // N/A
            } else {
                computerForStudentInEditCtx = recordForThisStudentInToma.usedComputer ?? student.assignedComputer;
            }
        }
        newStatusesMapLocal.set(student.id, statusForStudentInEditCtx);
        newUsedComputersMapLocal.set(student.id, computerForStudentInEditCtx);
      });
      
      setCurrentStudentStatuses(newStatusesMapLocal);
      setCurrentUsedComputers(newUsedComputersMapLocal);
      
      if (activePeriodId) { 
        consumeSavedContext(`${attendanceToEdit.gradeId}_${attendanceToEdit.date}_${activePeriodId}`);
      }
      return; // Exit early if we are editing
    }

    // Default initialization / reset after save / context change without edit
    if (!selectedGradeId || !activePeriodId || !selectedDate) {
      setCurrentStudentStatuses(new Map());
      setCurrentUsedComputers(new Map());
      setSelectedClassHours([]); 
      return;
    }

    // Reset to default (new toma) state
    studentsInSelectedGrade.forEach(student => {
      newStatusesMapLocal.set(student.id, AttendanceStatus.PRESENT);
      newUsedComputersMapLocal.set(student.id, student.assignedComputer); 
    });
    
    setCurrentStudentStatuses(newStatusesMapLocal);
    setCurrentUsedComputers(newUsedComputersMapLocal);
    setSelectedClassHours([]); // Always clear selected hours for a new take in this path
    
    if (recentlySavedContexts.has(currentContextKey)) {
      consumeSavedContext(currentContextKey); // Consume the flag so it doesn't reset again on next render
    }
    
  }, [
    selectedGradeId, 
    selectedDate, 
    activePeriodId, 
    students, 
    attendanceRecords,      
    attendanceToEdit, 
    initialContext,
    clearInitialContext,
    recentlySavedContexts, 
    currentContextKey,     
    consumeSavedContext,   
    studentsInSelectedGrade
  ]);

  const gradeSpecificLockedHours = useMemo(() => {
    if (!selectedGradeId || !selectedDate || !activePeriodId) return new Set<number>();
    const locked = new Set<number>();
    attendanceRecords.forEach(record => {
      if (record.gradeId === selectedGradeId && record.date === selectedDate && record.periodId === activePeriodId) {
        // If editing, the hours of the current record being edited are not considered "locked" by itself.
        if (attendanceToEdit && 
            record.classHours.join(',') === attendanceToEdit.classHours.join(',') &&
            record.date === attendanceToEdit.date && // Ensure all context matches
            record.periodId === attendanceToEdit.periodId &&
            record.gradeId === attendanceToEdit.gradeId
            ) {
          // This exact "toma" is being edited.
        } else {
          record.classHours.forEach(hour => locked.add(hour));
        }
      }
    });
    return locked;
  }, [selectedGradeId, selectedDate, activePeriodId, attendanceRecords, attendanceToEdit]);

  const globallyLockedHours = useMemo(() => {
    if (!selectedDate || !activePeriodId) return new Set<number>();
    const locked = new Set<number>();
    attendanceRecords.forEach(record => {
      if (record.date === selectedDate && record.periodId === activePeriodId) {
         if (attendanceToEdit && 
            record.classHours.join(',') === attendanceToEdit.classHours.join(',') &&
            record.date === attendanceToEdit.date &&
            record.periodId === attendanceToEdit.periodId &&
            record.gradeId === attendanceToEdit.gradeId
            ) {
            // This specific record instance (student, date, period, hours) is being edited.
        } else {
            record.classHours.forEach(hour => locked.add(hour));
        }
      }
    });
    return locked;
  }, [selectedDate, activePeriodId, attendanceRecords, attendanceToEdit]);


  const handleClassHourChange = useCallback((hour: number) => {
    const isHourPartOfCurrentEdit = attendanceToEdit && attendanceToEdit.classHours.includes(hour);
    
    if (gradeSpecificLockedHours.has(hour) && !isHourPartOfCurrentEdit) {
        alert("⚠️ Esta hora ya fue usada para este salón y fecha en otra toma.");
        return; 
    }
    // Also check globally if needed, but gradeSpecific is primary for this rule
    if (globallyLockedHours.has(hour) && !isHourPartOfCurrentEdit && !gradeSpecificLockedHours.has(hour) /* avoid double alert if both true */) {
        alert("⚠️ Esta hora ya fue tomada por otro grado/registro en esta fecha y periodo.");
        return;
    }

    setSelectedClassHours(prevSelectedHours => {
      const newSelectedHours = prevSelectedHours.includes(hour)
        ? prevSelectedHours.filter(h => h !== hour)
        : [...prevSelectedHours, hour];
      return newSelectedHours.sort((a,b) => a-b); 
    });
  }, [gradeSpecificLockedHours, globallyLockedHours, attendanceToEdit, setSelectedClassHours]);

  const availableComputersMap = useMemo(() => {
    const map = new Map<string, number[]>();
    if (!studentsInSelectedGrade || studentsInSelectedGrade.length === 0) return map;

    studentsInSelectedGrade.forEach(student => {
      const studentId = student.id;
      const currentStudentPC = currentUsedComputers.get(studentId);
      const isCurrentStudentEffectivelyPresent = 
        currentStudentStatuses.get(studentId) === AttendanceStatus.PRESENT ||
        currentStudentStatuses.get(studentId) === AttendanceStatus.SICK_BAY;

      const occupiedByOthers = new Set<number>();
      studentsInSelectedGrade.forEach(otherStudent => {
        if (otherStudent.id === studentId) return; 

        const otherStatus = currentStudentStatuses.get(otherStudent.id);
        const otherPC = currentUsedComputers.get(otherStudent.id);
        const isOtherEffectivelyPresent = otherStatus === AttendanceStatus.PRESENT || otherStatus === AttendanceStatus.SICK_BAY;

        if (isOtherEffectivelyPresent && otherPC !== 0 && otherPC !== undefined) {
          occupiedByOthers.add(otherPC);
        }
      });
      
      let studentOptions = COMPUTER_NUMBERS.filter(num => !occupiedByOthers.has(num));

      if (isCurrentStudentEffectivelyPresent && currentStudentPC !== 0 && currentStudentPC !== undefined && !studentOptions.includes(currentStudentPC)) {
        studentOptions.push(currentStudentPC);
        studentOptions.sort((a, b) => a - b);
      }
      map.set(studentId, studentOptions);
    });
    return map;
  }, [studentsInSelectedGrade, currentStudentStatuses, currentUsedComputers]);


  const handleStatusChange = useCallback((studentId: string, newSelectedStatus: AttendanceStatus) => {
    const student = students.find(s => s.id === studentId);
    if (!student) return;

    setCurrentStudentStatuses(prevStatuses => {
        const newStatusesMap = new Map(prevStatuses);
        const currentStudentActualStatus = prevStatuses.get(studentId) || AttendanceStatus.PRESENT;
        let finalStatusToSet: AttendanceStatus;

        if (currentStudentActualStatus === newSelectedStatus) {
            finalStatusToSet = AttendanceStatus.PRESENT; 
        } else {
            finalStatusToSet = newSelectedStatus;
        }
        newStatusesMap.set(studentId, finalStatusToSet);
        
        setCurrentUsedComputers(prevUsedComputers => {
            const newUsedComputersMap = new Map(prevUsedComputers);
            if (finalStatusToSet === AttendanceStatus.ABSENT_UNEXCUSED || finalStatusToSet === AttendanceStatus.ABSENT_EXCUSED) {
                newUsedComputersMap.set(studentId, 0); 
            } else {
                const currentPC = newUsedComputersMap.get(studentId);
                if (currentPC === 0 || currentPC === undefined) { 
                    newUsedComputersMap.set(studentId, student.assignedComputer);
                }
            }
            return newUsedComputersMap;
        });
        return newStatusesMap;
    });
  }, [students, setCurrentStudentStatuses, setCurrentUsedComputers]);

  const handleUsedComputerChange = useCallback((studentId: string, computerNumber: number) => {
    setCurrentUsedComputers(prev => {
        const newMap = new Map(prev);
        newMap.set(studentId, computerNumber);
        return newMap;
    });
  }, [setCurrentUsedComputers]);


  const openSaveConfirmModal = () => {
    if (!selectedGradeId || !activePeriodId || !selectedDate || selectedClassHours.length === 0) {
      alert("Por favor, asegúrese de que un grado, periodo activo, fecha y al menos una hora de clase estén seleccionados.");
      return;
    }
    
    let hourConflictDetectedForThisGrade = false;
    // If editing, we are checking if the *selected* hours (which might be different from attendanceToEdit.classHours)
    // conflict with other "tomas" for this grade.
    const originalHoursBeingEdited = attendanceToEdit ? new Set(attendanceToEdit.classHours) : new Set<number>();

    for (const hour of selectedClassHours) {
        // A conflict exists if the hour is locked by this grade, AND it wasn't part of the original set of hours being edited
        // (if we are indeed editing and these hours were the original ones).
        if (gradeSpecificLockedHours.has(hour)) {
            // If we are editing, and the conflicting hour *was* part of the original hours, it's not a "new" conflict.
            // But if we are editing and selected new hours that are locked, or if we are creating a new toma with locked hours, it's a conflict.
            let isThisHourConflictFreeDueToEdit = false;
            if (attendanceToEdit) {
                // Check if the *entire set* of selectedClassHours matches the attendanceToEdit.classHours.
                // If they match, then these hours are "owned" by the current edit session.
                const currentSelectedHoursStr = [...selectedClassHours].sort((a,b)=>a-b).join(',');
                const originalEditHoursStr = [...attendanceToEdit.classHours].sort((a,b)=>a-b).join(',');
                if (currentSelectedHoursStr === originalEditHoursStr) {
                    isThisHourConflictFreeDueToEdit = true;
                }
            }
            if(!isThisHourConflictFreeDueToEdit) {
                hourConflictDetectedForThisGrade = true;
                break;
            }
        }
    }

    if (hourConflictDetectedForThisGrade) {
        alert("❌ Una o más horas seleccionadas ya fueron usadas para este grado y fecha. No se puede duplicar.");
        return;
    }
    setIsSaveConfirmModalOpen(true);
  };

  const closeSaveConfirmModal = () => {
    setIsSaveConfirmModalOpen(false);
  };

  const executeSaveAttendance = useCallback(() => {
    if (!selectedGradeId || !activePeriodId || !selectedDate || selectedClassHours.length === 0) {
      closeSaveConfirmModal(); 
      return;
    }

    const pcUsageMap = new Map<number, string[]>(); 
    let pcConflictFound = false;

    studentsInSelectedGrade.forEach(student => {
        const status = currentStudentStatuses.get(student.id);
        const pc = currentUsedComputers.get(student.id);

        if ((status === AttendanceStatus.PRESENT || status === AttendanceStatus.SICK_BAY) && pc !== 0 && pc !== undefined) {
            if (!pcUsageMap.has(pc)) {
                pcUsageMap.set(pc, []);
            }
            pcUsageMap.get(pc)!.push(student.name);
        }
    });

    for (const [pc, studentNames] of pcUsageMap) {
        if (studentNames.length > 1) {
            alert(`Error: El computador N°${pc} está duplicado. Usado por ${studentNames.join(' y por ')}. Por favor, corrija antes de guardar.`);
            pcConflictFound = true;
            break;
        }
    }

    if (pcConflictFound) {
        closeSaveConfirmModal();
        return; 
    }

    studentsInSelectedGrade.forEach(student => { 
      const studentId = student.id;
      const status = currentStudentStatuses.get(studentId) || AttendanceStatus.PRESENT; 
      const pcToSave = (status === AttendanceStatus.ABSENT_UNEXCUSED || status === AttendanceStatus.ABSENT_EXCUSED)
                       ? 0 
                       : (currentUsedComputers.get(studentId) ?? student.assignedComputer);
      
      const sortedClassHours = [...selectedClassHours].sort((a,b) => a-b);
      const recordIdForThisToma = `${studentId}_${selectedDate}_${activePeriodId}_${sortedClassHours.join('-')}`;
      
      const recordToSave: AttendanceRecord = {
        id: recordIdForThisToma,
        studentId,
        gradeId: selectedGradeId,
        date: selectedDate,
        periodId: activePeriodId!, 
        classHours: sortedClassHours,
        status,
        usedComputer: pcToSave, 
      };
      saveAttendanceRecord(recordToSave);
    });
    
    if (currentContextKey) markContextAsSaved(currentContextKey); 
    clearAttendanceToEdit(); 
    
    alert('✅ Asistencia guardada correctamente. Formulario listo para nueva toma.');
    closeSaveConfirmModal();

  }, [currentStudentStatuses, currentUsedComputers, selectedGradeId, selectedDate, activePeriodId, selectedClassHours, saveAttendanceRecord, studentsInSelectedGrade, markContextAsSaved, currentContextKey, clearAttendanceToEdit, students, gradeSpecificLockedHours, attendanceToEdit]); 
  
  const getStatusColor = (status: AttendanceStatus): string => {
    switch (status) {
      case AttendanceStatus.PRESENT: return 'bg-present text-present-text';
      case AttendanceStatus.ABSENT_UNEXCUSED: return 'bg-absent-unexcused text-white';
      case AttendanceStatus.ABSENT_EXCUSED: return 'bg-absent-excused text-black';
      case AttendanceStatus.SICK_BAY: return 'bg-sick-bay text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };

  useEffect(() => {
    if (attendanceToEdit && 
        (attendanceToEdit.gradeId !== selectedGradeId || 
         attendanceToEdit.date !== selectedDate || 
         (activePeriodId && attendanceToEdit.periodId !== activePeriodId)
        )
       ) {
      clearAttendanceToEdit();
    }
  }, [selectedGradeId, selectedDate, activePeriodId, attendanceToEdit, clearAttendanceToEdit]);

  const baseScreenContent = (message: string, buttonTargetView?: ScreenView, buttonLabel?: string) => (
    <div className="p-6 text-center">
        {canGoBack && (
            <div className="text-left mb-6">
                <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
                    Regresar
                </Button>
            </div>
        )}
        <p className="text-gray-600 text-lg mb-4">{message}</p>
        {buttonTargetView && buttonLabel && (
            <Button onClick={() => setCurrentView(buttonTargetView)} variant="primary">
                {buttonLabel}
            </Button>
        )}
    </div>
  );

  if (grades.length === 0) return baseScreenContent("No hay grados creados.", ScreenView.MANAGE_GRADES, "Ir a Gestionar Grados");
  if (!activePeriod) return baseScreenContent("No hay periodo activo.", ScreenView.CONFIGURE_PERIODS, "Ir a Configurar Periodos");
  if (studentsInSelectedGrade.some(s => s.assignedComputer === undefined || s.assignedComputer === null)) {
      return baseScreenContent("Algunos estudiantes en este grado no tienen un número de computador asignado. Por favor, actualícelos en 'Agregar Estudiantes'.", ScreenView.ADD_STUDENTS, "Ir a Agregar Estudiantes")
  }

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="flex flex-col md:flex-row justify-between md:items-start mb-6 gap-4">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-2 md:mb-0`}>Llamar Asistencia</h2>
        <div className="w-full md:w-auto flex flex-col gap-4">
          <div className="flex flex-col sm:flex-row flex-wrap items-start sm:items-center gap-2 md:gap-4">
            <select value={selectedGradeId} onChange={(e) => setSelectedGradeId(e.target.value)} className="form-select w-full sm:w-auto" aria-label="Seleccionar Grado">
              {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
            <input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} className="form-select w-full sm:w-auto" aria-label="Seleccionar Fecha"/>
            <span className="text-gray-700 text-sm md:text-base w-full sm:w-auto text-center sm:text-left mt-2 sm:mt-0">
              Periodo: <span className="font-semibold">{activePeriod.name}</span>
            </span>
          </div>
          <div className="w-full">
            <label className="block text-sm font-medium text-gray-700 mb-1">Hora(s) de Clase Cubiertas:</label>
            <div className="grid grid-cols-4 sm:grid-cols-8 gap-2 p-2 border border-gray-300 rounded-md bg-white">
                {CLASS_HOURS.map(hour => {
                    const isPartOfCurrentEdit = attendanceToEdit && attendanceToEdit.classHours.includes(hour);
                    const isDisabledByGrade = gradeSpecificLockedHours.has(hour) && !isPartOfCurrentEdit;
                    const isDisabledGlobally = globallyLockedHours.has(hour) && !isPartOfCurrentEdit && !isDisabledByGrade; // Avoid double check if already disabled by grade
                    const isDisabled = isDisabledByGrade || isDisabledGlobally;
                    
                    let title = `Hora de clase ${hour}`;
                    if (isDisabledByGrade) title += " (Usada por este grado/fecha en otra toma)";
                    else if (isDisabledGlobally) title += " (Usada globalmente por otro grado/fecha)";

                    return (
                        <label key={hour} className={`flex items-center space-x-2 p-1 rounded ${isDisabled ? 'opacity-50 cursor-not-allowed' : 'hover:bg-gray-100 cursor-pointer'}`} title={title}>
                            <input 
                                type="checkbox" 
                                value={hour} 
                                checked={selectedClassHours.includes(hour)} 
                                onChange={() => handleClassHourChange(hour)} 
                                className="form-checkbox h-4 w-4 text-institucional-blue focus:ring-institucional-blue border-gray-300 rounded"
                                disabled={isDisabled}
                                aria-label={`Hora de clase ${hour}`}
                            />
                            <span className="text-sm text-gray-700">{hour}</span>
                        </label>
                    );
                })}
            </div>
            {selectedClassHours.length === 0 && <p className="text-xs text-red-500 mt-1">Debe seleccionar al menos una hora.</p>}
          </div>
        </div>
      </div>

      {selectedGradeId && studentsInSelectedGrade.length === 0 && <p className="text-gray-600 text-center py-10">No hay estudiantes en este grado.</p>}

      {selectedGradeId && studentsInSelectedGrade.length > 0 && (
        <div className="bg-white shadow-md rounded-lg overflow-hidden mb-6">
          <ul className="divide-y divide-gray-200">
            {studentsInSelectedGrade.map(student => {
              const status = currentStudentStatuses.get(student.id) || AttendanceStatus.PRESENT;
              const usedComputer = currentUsedComputers.get(student.id) ?? student.assignedComputer; 
              const isAbsent = status === AttendanceStatus.ABSENT_UNEXCUSED || status === AttendanceStatus.ABSENT_EXCUSED;
              const studentAvailablePCs = availableComputersMap.get(student.id) || COMPUTER_NUMBERS;
              
              return (
                <li key={student.id} className={`p-4 flex flex-col gap-3 md:flex-row justify-between md:items-center transition-colors ${getStatusColor(status)}`}>
                  <div className='flex-1'>
                    <span className={`text-lg font-medium ${status !== AttendanceStatus.ABSENT_EXCUSED ? 'text-inherit' : 'text-black'}`}>{student.name}</span>
                    <div className="text-xs mt-1">
                        <span className={`font-semibold ${status !== AttendanceStatus.ABSENT_EXCUSED ? 'text-inherit opacity-80' : 'text-gray-700'}`}>
                            PC Asignado: {student.assignedComputer}
                        </span>
                    </div>
                  </div>
                  <div className="flex flex-col sm:flex-row sm:items-center gap-2 md:gap-3 flex-wrap">
                     <div className="flex items-center space-x-2">
                        <label htmlFor={`pc-used-${student.id}`} className={`text-xs font-medium ${status !== AttendanceStatus.ABSENT_EXCUSED ? 'text-inherit opacity-90' : 'text-gray-800'}`}>
                            PC Usado Hoy:
                        </label>
                        <select
                            id={`pc-used-${student.id}`}
                            value={usedComputer} 
                            onChange={(e) => handleUsedComputerChange(student.id, parseInt(e.target.value))}
                            className={`form-select form-select-sm !py-1.5 !text-xs w-20 shadow-sm 
                                ${isAbsent 
                                    ? 'bg-gray-200 text-gray-500 cursor-not-allowed opacity-70' 
                                    : 'bg-white text-gray-900 border-gray-300 focus:ring-institucional-blue focus:border-institucional-blue'
                                }`}
                            disabled={isAbsent}
                            title={isAbsent ? "No disponible: el estudiante fue marcado como ausente" : `Computador usado hoy por ${student.name}`}
                            aria-label={`Computador usado hoy por ${student.name}`}
                            >
                            {isAbsent && (usedComputer === 0 || usedComputer === undefined) && <option value="0" disabled hidden>N/A</option>}
                            {studentAvailablePCs.map(num => (
                                <option key={`${student.id}-pc-${num}`} value={num} className="text-gray-900 bg-white">{num}</option>
                            ))}
                            {!(isAbsent && (usedComputer === 0 || usedComputer === undefined)) && 
                             !studentAvailablePCs.includes(usedComputer) && 
                             usedComputer !== 0 && usedComputer !== undefined &&
                             <option key={`${student.id}-pc-current-${usedComputer}`} value={usedComputer} className="text-gray-900 bg-white">{usedComputer} (Actual)</option>
                            }
                        </select>
                     </div>
                    <div className="flex space-x-1 sm:space-x-2 flex-wrap">
                        {[
                        { label: 'Ausente (S.E.)', status: AttendanceStatus.ABSENT_UNEXCUSED, color: 'bg-absent-unexcused hover:bg-red-700' },
                        { label: 'Ausente (Just.)', status: AttendanceStatus.ABSENT_EXCUSED, color: 'bg-absent-excused hover:bg-amber-600 text-black' },
                        { label: 'Enfermería', status: AttendanceStatus.SICK_BAY, color: 'bg-sick-bay hover:bg-blue-700' },
                        ].map(btn => (
                        <Button key={btn.status} size="sm" onClick={() => handleStatusChange(student.id, btn.status)} className={`${btn.color} ${currentStudentStatuses.get(student.id) === btn.status ? 'ring-2 ring-offset-1 ring-black' : ''} text-white !px-2 !py-1 !text-xs`}>
                            {btn.label}
                        </Button>
                        ))}
                        <Button size="sm" onClick={() => handleStatusChange(student.id, AttendanceStatus.PRESENT)} className={`bg-emerald-500 hover:bg-emerald-600 text-white ${currentStudentStatuses.get(student.id) === AttendanceStatus.PRESENT ? 'ring-2 ring-offset-1 ring-black' : ''} !px-2 !py-1 !text-xs`}>
                            Presente
                        </Button>
                    </div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>
      )}
      
      {selectedGradeId && studentsInSelectedGrade.length > 0 && (
        <Button onClick={openSaveConfirmModal} size="lg" className="w-full md:w-auto" disabled={selectedClassHours.length === 0}>
          Guardar Llamada de Asistencia
        </Button>
      )}

       <div className="mt-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
        <h4 className="font-semibold text-gray-700 mb-2">Leyenda de Colores:</h4>
        <ul className="space-y-1 text-sm">
          <li><span className="inline-block w-4 h-4 rounded-full bg-present mr-2 align-middle"></span> <span className="text-present-text">Presente</span></li>
          <li><span className="inline-block w-4 h-4 rounded-full bg-absent-unexcused mr-2 align-middle"></span> <span className="text-red-700">Ausente (Sin Excusa)</span></li>
          <li><span className="inline-block w-4 h-4 rounded-full bg-absent-excused mr-2 align-middle"></span> <span className="text-amber-700">Ausente (Justificado)</span></li>
          <li><span className="inline-block w-4 h-4 rounded-full bg-sick-bay mr-2 align-middle"></span> <span className="text-blue-700">En Enfermería</span></li>
        </ul>
      </div>
      
      <Modal
        isOpen={isSaveConfirmModalOpen}
        onClose={closeSaveConfirmModal}
        title="Confirmar Guardado de Asistencia"
        footer={
          <>
            <Button variant="ghost" onClick={closeSaveConfirmModal}>Cancelar</Button>
            <Button onClick={executeSaveAttendance}>Sí, Guardar y Reiniciar</Button> 
          </>
        }
      >
        <p className="text-gray-700">
          ¿Está seguro que desea guardar esta llamada de asistencia? Esta acción registrará la asistencia y limpiará el formulario para una nueva toma.
        </p>
      </Modal>

    </div>
  );
};

export default TakeAttendanceScreen;
