
import React, { useState, useMemo, useCallback } from 'react';
import { Grade, Student, Period, AttendanceRecord, ScreenView } from '../types';
import Button from './Button';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS, COMPUTER_NUMBERS, APP_TITLE, FOOTER_TEXT } from '../constants';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

interface ComputerUsageGeneralReportScreenProps {
  grades: Grade[];
  students: Student[];
  periods: Period[];
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const formatDisplayDate = (dateString: string): string => {
  if (!dateString) return "N/A";
  try {
    const dateObj = new Date(dateString + 'T00:00:00');
    return dateObj.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' });
  } catch(e) { return dateString; }
};


interface DailyComputerUsage {
    date: string;
    usages: {
        computerNumber: number;
        studentName?: string;
        gradeName?: string;
        isDifferentFromAssigned?: boolean;
    }[];
}

const ComputerUsageGeneralReportScreen: React.FC<ComputerUsageGeneralReportScreenProps> = ({
  grades, students, periods, attendanceRecords, setCurrentView, goBack, canGoBack
}) => {
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>(periods.length > 0 ? periods[0].id : '');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [showAllDates, setShowAllDates] = useState<boolean>(true);

  const reportData = useMemo(() => {
    if (!selectedPeriodId) return [];

    const recordsForPeriod = attendanceRecords.filter(r => 
        r.periodId === selectedPeriodId &&
        (showAllDates || (r.date >= startDate && r.date <= endDate))
    );

    const groupedByDate: { [date: string]: DailyComputerUsage['usages'] } = {};

    recordsForPeriod.forEach(record => {
        if (!groupedByDate[record.date]) {
            groupedByDate[record.date] = COMPUTER_NUMBERS.map(num => ({ computerNumber: num }));
        }
        const student = students.find(s => s.id === record.studentId);
        const grade = student ? grades.find(g => g.id === student.gradeId) : undefined;
        
        const computerSlot = groupedByDate[record.date].find(slot => slot.computerNumber === record.usedComputer);
        if (computerSlot) {
            computerSlot.studentName = student?.name || 'Desconocido';
            computerSlot.gradeName = grade?.name || 'N/A';
            computerSlot.isDifferentFromAssigned = student ? student.assignedComputer !== record.usedComputer : false;
        }
    });
    
    return Object.entries(groupedByDate)
        .map(([date, usages]) => ({ date, usages }))
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  }, [selectedPeriodId, startDate, endDate, showAllDates, attendanceRecords, students, grades]);

  const handleExport = useCallback((format: 'PDF' | 'Excel') => {
    if (reportData.length === 0) {
      alert("No hay datos para exportar.");
      return;
    }
    const periodName = periods.find(p => p.id === selectedPeriodId)?.name || 'N/A';
    let dateRangeStr = 'Todas las Fechas';
    if (!showAllDates && startDate && endDate) {
        dateRangeStr = `${formatDisplayDate(startDate).replace(/\sde\s/g, '-')} al ${formatDisplayDate(endDate).replace(/\sde\s/g, '-')}`;
    }
    const filename = `Reporte_General_Computadores_${periodName}_${dateRangeStr.replace(/[\/\s]/g, '_')}`;

    if (format === 'Excel') {
        const worksheetData: any[] = [];
        reportData.forEach(dailyEntry => {
            dailyEntry.usages.forEach(usage => {
                if (usage.studentName) { // Only include rows where a computer was used
                    worksheetData.push({
                        'Fecha': formatDisplayDate(dailyEntry.date),
                        'Computador N°': usage.computerNumber,
                        'Estudiante': usage.studentName,
                        'Curso/Grado': usage.gradeName,
                        'Observación': usage.isDifferentFromAssigned ? 'PC Distinto al Asignado' : ''
                    });
                }
            });
        });
        if(worksheetData.length === 0){ alert("No hay registros detallados para exportar."); return; }
        const worksheet = XLSX.utils.json_to_sheet(worksheetData);
        XLSX.utils.sheet_add_aoa(worksheet, [["Fecha", "Computador N°", "Estudiante", "Curso/Grado", "Observación"]], { origin: "A1" });
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Reporte General PCs");
        XLSX.writeFile(workbook, `${filename}.xlsx`);

    } else if (format === 'PDF') {
        const doc = new jsPDF('p', 'mm', 'a4');
        let isFirstPage = true;
        const legendText = "* Observación: El estudiante usó un PC diferente al que tiene asignado.";

        const drawPdfHeader = (pageDoc: jsPDF, isContinuation: boolean = false) => {
            pageDoc.setFillColor(INSTITUTIONAL_COLORS.BLUE.includes('institucional') ? '#0A4F8A' : INSTITUTIONAL_COLORS.BLUE);
            pageDoc.rect(0, 0, pageDoc.internal.pageSize.getWidth(), 15, 'F');
            pageDoc.setFontSize(16);
            pageDoc.setTextColor(INSTITUTIONAL_COLORS.WHITE.includes('institucional') ? '#FFFFFF' : INSTITUTIONAL_COLORS.WHITE);
            pageDoc.text(APP_TITLE, pageDoc.internal.pageSize.getWidth() / 2, 10, { align: 'center' });
            
            pageDoc.setFontSize(12);
            pageDoc.setTextColor(0,0,0);
            let titleY = 25;
            pageDoc.text(`Reporte General de Uso de Computadores ${isContinuation ? '(Continuación)' : ''}`, 14, titleY);
            pageDoc.setFontSize(10);
            titleY += 6;
            pageDoc.text(`Periodo: ${periodName}`, 14, titleY);
            titleY += 5;
            pageDoc.text(`Rango de Fechas: ${dateRangeStr}`, 14, titleY);
            titleY += 5;
            // Add Legend
            pageDoc.setFontSize(8);
            pageDoc.setTextColor(100,100,100);
            pageDoc.text(legendText, 14, titleY);
            return titleY + 3; // Return new Y position for table start
        }
        
        const drawPdfFooter = (pageDoc: jsPDF, pageNum: number, totalPages: number) => {
             pageDoc.setFontSize(8);
             pageDoc.setTextColor('#888888');
             pageDoc.text(FOOTER_TEXT, 14, pageDoc.internal.pageSize.getHeight() - 10);
             pageDoc.text(`Generado: ${new Date().toLocaleString('es-ES')}`, 14, pageDoc.internal.pageSize.getHeight() - 6);
             pageDoc.text(`Página ${pageNum} de ${totalPages}`, pageDoc.internal.pageSize.getWidth() - 14 - pageDoc.getStringUnitWidth(`Página ${pageNum} de ${totalPages}`) * pageDoc.getFontSize() / pageDoc.internal.scaleFactor, pageDoc.internal.pageSize.getHeight() - 10, {align:'left'});
        }

        let yPos = drawPdfHeader(doc); 

        reportData.forEach((dailyEntry, index) => {
            const dateHeader = `Fecha: ${formatDisplayDate(dailyEntry.date)}`;
            const dateHeaderHeight = 7;
            const tableHeaderHeight = 7;
            const rowHeight = 6;
            const pageHeight = doc.internal.pageSize.getHeight();
            const marginBottom = 20;

            const recordsForDate = dailyEntry.usages.filter(u => u.studentName);
            if (recordsForDate.length === 0) return; 

            const estimatedTableHeight = dateHeaderHeight + tableHeaderHeight + (recordsForDate.length * rowHeight);
            
            if (yPos + estimatedTableHeight > pageHeight - marginBottom && index > 0) { // Add page if not enough space, and not the first entry
                doc.addPage();
                yPos = drawPdfHeader(doc, true); 
                isFirstPage = false;
            } else if (index > 0) { // Space before next date block if not new page
                yPos += 5;
                 if (yPos + estimatedTableHeight > pageHeight - marginBottom) { // Re-check after adding space
                    doc.addPage();
                    yPos = drawPdfHeader(doc, true);
                    isFirstPage = false;
                 }
            }


            doc.setFontSize(11);
            doc.setFillColor(230, 230, 230); 
            doc.rect(14, yPos, doc.internal.pageSize.getWidth() - 28, dateHeaderHeight, 'F');
            doc.setTextColor(50,50,50);
            doc.text(dateHeader, 16, yPos + 5);
            yPos += dateHeaderHeight;

            const tableBody = recordsForDate.map(usage => [
                usage.computerNumber,
                usage.studentName,
                usage.gradeName,
                usage.isDifferentFromAssigned ? '*' : ''
            ]);

            (doc as any).autoTable({
                startY: yPos,
                head: [['PC N°', 'Estudiante', 'Curso/Grado', 'Obs.']],
                body: tableBody,
                theme: 'grid',
                headStyles: { fillColor: [10, 79, 138], textColor: 255, fontSize: 9 },
                bodyStyles: { fontSize: 8, cellPadding: 1.5 },
                columnStyles: { 
                    0: { cellWidth: 20, halign: 'center' }, 1: { cellWidth: 'auto' }, 2: { cellWidth: 40 }, 3: { cellWidth: 15, halign: 'center' }
                },
                margin: { top: yPos, bottom: marginBottom, left: 14, right: 14 },
                pageBreak: 'auto', 
                didDrawPage: (dataHook: any) => {
                    // If autoTable creates a new page internally, draw header and footer
                    if (dataHook.pageNumber > doc.getNumberOfPages()) { // Should not happen if startY is properly managed
                       // This case is tricky if autoTable itself breaks a single date's table across pages.
                    } else if (dataHook.pageNumber > 1 && dataHook.cursor.y < 40) { // If new page started by autoTable, redraw header
                        drawPdfHeader(doc, true);
                    }
                }
            });
            yPos = (doc as any).lastAutoTable.finalY + 2; // Small gap before potential next date block
        });
        
        const totalPages = doc.getNumberOfPages();
        for (let i = 1; i <= totalPages; i++) {
            doc.setPage(i);
            if (i > 1 && doc.getTextDimensions(legendText, {fontSize: 8}).h + 35 > (doc as any).lastAutoTable.finalY && (doc as any).lastAutoTable.pageCount === i) {
                // If it's a new page created by autoTable, and header wasn't redrawn by didDrawPage hook of autoTable
                // This part is complex because autoTable's didDrawPage might have already handled some headers.
                // The goal is to ensure every page has a header.
            }
            drawPdfFooter(doc, i, totalPages);
        }

        doc.save(`${filename}.pdf`);
    }
  }, [reportData, selectedPeriodId, startDate, endDate, showAllDates, periods]);

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-6`}>Reporte General de Computadores – Todos los Grados</h2>

      <div className="bg-white p-4 rounded-lg shadow mb-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="periodSelectGeneral" className="block text-sm font-medium text-gray-700 mb-1">Periodo:</label>
            <select id="periodSelectGeneral" value={selectedPeriodId} onChange={e => setSelectedPeriodId(e.target.value)} className="form-select w-full">
              {periods.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Filtrar Fechas:</label>
            <div className="flex items-center space-x-2">
                <input type="checkbox" id="showAllDatesGeneral" checked={showAllDates} onChange={e => setShowAllDates(e.target.checked)} className="form-checkbox h-5 w-5 text-institucional-blue rounded"/>
                <label htmlFor="showAllDatesGeneral" className="text-sm text-gray-700">Mostrar Todas las Fechas del Periodo</label>
            </div>
          </div>
        </div>
        {!showAllDates && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
            <div>
              <label htmlFor="startDateGeneral" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Inicio:</label>
              <input type="date" id="startDateGeneral" value={startDate} onChange={e => setStartDate(e.target.value)} className="form-select w-full" />
            </div>
            <div>
              <label htmlFor="endDateGeneral" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Fin:</label>
              <input type="date" id="endDateGeneral" value={endDate} onChange={e => setEndDate(e.target.value)} className="form-select w-full" />
            </div>
             {startDate && endDate && new Date(startDate) > new Date(endDate) && <p className="text-red-500 text-sm md:col-span-2">La fecha de inicio no puede ser posterior a la fecha de fin.</p>}
          </div>
        )}
        <div className="flex justify-end space-x-2">
            <Button onClick={() => handleExport('Excel')} variant="secondary" disabled={reportData.length === 0}>Exportar a Excel</Button>
            <Button onClick={() => handleExport('PDF')} variant="primary" disabled={reportData.length === 0}>Exportar a PDF</Button>
        </div>
        <p className="text-xs text-gray-500 pt-2 border-t">
            * Observación en PDF: El estudiante usó un PC diferente al que tiene asignado.
        </p>
      </div>

      {reportData.length > 0 ? (
        <div className="space-y-6">
          {reportData.map((dailyEntry) => (
            <div key={dailyEntry.date} className="bg-white p-4 rounded-lg shadow">
              <h3 className="text-lg font-semibold text-institucional-blue mb-3">
                Fecha: {formatDisplayDate(dailyEntry.date)}
              </h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">PC N°</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Estudiante</th>
                      <th className="px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase">Curso/Grado</th>
                      <th className="px-3 py-2 text-center text-xs font-medium text-gray-500 uppercase">Obs.</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {dailyEntry.usages.map((usage) => (
                      <tr key={usage.computerNumber} className={!usage.studentName ? 'bg-gray-100 opacity-60' : (usage.isDifferentFromAssigned ? 'bg-yellow-50' : '')}>
                        <td className="px-3 py-2 whitespace-nowrap font-medium text-center">{usage.computerNumber}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{usage.studentName || <span className="text-gray-400 italic">Libre</span>}</td>
                        <td className="px-3 py-2 whitespace-nowrap">{usage.gradeName || '-'}</td>
                        <td className="px-3 py-2 whitespace-nowrap text-center">
                          {usage.isDifferentFromAssigned && <span className="text-red-500 font-bold" title="PC usado diferente al asignado">*</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <p className="text-gray-600 text-center py-10">No hay datos para mostrar con los filtros seleccionados.</p>
      )}
    </div>
  );
};

export default ComputerUsageGeneralReportScreen;
