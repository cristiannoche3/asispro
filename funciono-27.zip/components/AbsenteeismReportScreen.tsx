
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { ScreenView, Student, AttendanceRecord, AttendanceStatus } from '../types';
import Button from './Button';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS } from '../constants';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList, LineChart, Line } from 'recharts';

interface AbsenteeismReportScreenProps {
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

type PeriodOption = 'today' | 'current_week' | 'current_month' | 'custom'; // Added 'custom'

const STATUS_COLORS = {
    PRESENT: '#10B981', // Green
    ABSENT: '#EF4444',   // Red
};

const formatDate = (date: Date): string => date.toISOString().split('T')[0];

const getWeekdaysInDateRange = (startDate: Date, endDate: Date): number => {
    let count = 0;
    const currentDate = new Date(startDate);
    while (currentDate <= endDate) {
        const day = currentDate.getDay();
        if (day >= 1 && day <= 5) { 
            count++;
        }
        currentDate.setDate(currentDate.getDate() + 1);
    }
    return count;
};

const getStartOfWeek = (date: Date): Date => {
    const d = new Date(date);
    const day = d.getDay();
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); 
    d.setDate(diff);
    d.setHours(0, 0, 0, 0);
    return d;
};

const todayGlobal = new Date();
const todayFormattedForMax = formatDate(todayGlobal);

// New external label renderer for the absenteeism pie chart
const renderAbsenteeismExternalLabel = (props: any) => {
  const { cx, cy, midAngle, outerRadius, fill, name, percent } = props;

  if (percent === undefined || name === undefined) return null;

  const RADIAN = Math.PI / 180;
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  
  // Adjust these values as needed for optimal appearance
  const lineStartRadius = outerRadius * 0.95; 
  const lineExtensionLength = 15;
  const textOffset = 18;

  const sx = cx + lineStartRadius * cos;
  const sy = cy + lineStartRadius * sin;
  const mx = cx + (lineStartRadius + lineExtensionLength) * cos;
  const my = cy + (lineStartRadius + lineExtensionLength) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * textOffset;
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';

  const percentageValue = (percent * 100).toFixed(1);
  
  // pieChartData is already filtered for d.value > 0, so 0% slices are not an issue here.
  // For 100% slices, this will display correctly.

  const emoji = name === 'Asistencia' ? '🟢' : '🔴';

  return (
    <g>
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2.5} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 5} y={ey} textAnchor={textAnchor} fill="#333333" dy={4} fontSize="12px">
        {`${emoji} ${name}: ${percentageValue}%`}
      </text>
    </g>
  );
};


const AbsenteeismReportScreen: React.FC<AbsenteeismReportScreenProps> = ({
  students, attendanceRecords, setCurrentView, goBack, canGoBack
}) => {
  const [periodOption, setPeriodOption] = useState<PeriodOption>('current_week');
  const [customStartDate, setCustomStartDate] = useState<string>(todayFormattedForMax);
  const [customEndDate, setCustomEndDate] = useState<string>(todayFormattedForMax);
  const [customDateError, setCustomDateError] = useState<string>('');

  useEffect(() => {
    if (periodOption === 'custom') {
        if (!customStartDate || !customEndDate) {
            setCustomDateError("Por favor, seleccione ambas fechas.");
            return;
        }
        const start = new Date(customStartDate);
        const end = new Date(customEndDate);
        const todayDt = new Date(todayFormattedForMax); // Use formatted today to compare against date inputs

        if (isNaN(start.getTime()) || isNaN(end.getTime())) {
            setCustomDateError("Fechas inválidas.");
            return;
        }
        if (start > end) {
            setCustomDateError("La fecha de inicio no puede ser posterior a la fecha de fin.");
        } else if (end > todayDt) { // Should be caught by max attribute, but good to check
            setCustomDateError("La fecha de fin no puede ser futura.");
        } else if (start > todayDt) { // Should be caught by max attribute
            setCustomDateError("La fecha de inicio no puede ser futura.");
        }
        else {
            setCustomDateError('');
        }
    } else {
        setCustomDateError('');
    }
  }, [customStartDate, customEndDate, periodOption]);


  const dateRange = useMemo(() => {
    const todayDt = new Date();
    todayDt.setHours(0,0,0,0);
    let calculatedStartDate = new Date(todayDt);
    let calculatedEndDate = new Date(todayDt);

    if (periodOption === 'custom') {
        if (customStartDate && customEndDate && !customDateError) {
            const start = new Date(customStartDate + "T00:00:00");
            const end = new Date(customEndDate + "T00:00:00");
             // Ensure dates are valid and logical before using them
            if (!isNaN(start.getTime()) && !isNaN(end.getTime()) && start <= end) {
                calculatedStartDate = start;
                calculatedEndDate = end;
            } else {
                // Fallback if error somehow bypassed or dates are invalid
                calculatedStartDate = new Date(todayDt);
                calculatedEndDate = new Date(todayDt);
            }
        } else {
            // If custom is selected but dates are not set or invalid, default to today
            calculatedStartDate = new Date(todayDt);
            calculatedEndDate = new Date(todayDt);
        }
    } else {
        switch (periodOption) {
        case 'today':
            // calculatedStartDate and calculatedEndDate are already todayDt
            break;
        case 'current_week':
            calculatedStartDate = getStartOfWeek(todayDt);
            calculatedEndDate = new Date(calculatedStartDate);
            calculatedEndDate.setDate(calculatedStartDate.getDate() + 4); // Monday to Friday
            break;
        case 'current_month':
            calculatedStartDate = new Date(todayDt.getFullYear(), todayDt.getMonth(), 1);
            calculatedEndDate = new Date(todayDt.getFullYear(), todayDt.getMonth() + 1, 0);
            break;
        }
    }
    return { startDate: calculatedStartDate, endDate: calculatedEndDate };
  }, [periodOption, customStartDate, customEndDate, customDateError]);

  const absenteeismData = useMemo(() => {
    const { startDate, endDate } = dateRange;
    
    const relevantRecords = attendanceRecords.filter(r => {
      const recordDate = new Date(r.date + "T00:00:00"); 
      return recordDate >= startDate && recordDate <= endDate;
    });

    const studentDayAbsences = new Set<string>();
    relevantRecords.forEach(r => {
      if (r.status !== AttendanceStatus.PRESENT) {
        studentDayAbsences.add(`${r.studentId}_${r.date}`);
      }
    });
    const totalStudentDayAbsences = studentDayAbsences.size;
    const totalStudentsRegistered = students.length;
    const activeSchoolDaysInPeriod = getWeekdaysInDateRange(startDate, endDate);

    let overallAbsenteeismLevel = 0;
    if (totalStudentsRegistered > 0 && activeSchoolDaysInPeriod > 0) {
      overallAbsenteeismLevel = (totalStudentDayAbsences / (totalStudentsRegistered * activeSchoolDaysInPeriod)) * 100;
    }

    let absenteeismColor = 'bg-green-500'; // Low
    if (overallAbsenteeismLevel > 15) absenteeismColor = 'bg-red-500'; // High
    else if (overallAbsenteeismLevel > 5) absenteeismColor = 'bg-yellow-500'; // Moderate

    const absencesByDayOfWeek: { [key: number]: number } = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 }; 
    const dailyAbsencesMap = new Map<string, Set<string>>(); 

    relevantRecords.forEach(r => {
        if (r.status !== AttendanceStatus.PRESENT) {
            if (!dailyAbsencesMap.has(r.date)) {
                dailyAbsencesMap.set(r.date, new Set());
            }
            dailyAbsencesMap.get(r.date)!.add(r.studentId);
        }
    });
    
    dailyAbsencesMap.forEach((studentSet, dateStr) => {
        const recordDate = new Date(dateStr + "T00:00:00");
        const dayOfWeek = recordDate.getDay(); 
        if (dayOfWeek >= 1 && dayOfWeek <= 5) {
            absencesByDayOfWeek[dayOfWeek] = (absencesByDayOfWeek[dayOfWeek] || 0) + studentSet.size;
        }
    });

    const barChartData = [
      { name: 'Lun', Ausencias: absencesByDayOfWeek[1] },
      { name: 'Mar', Ausencias: absencesByDayOfWeek[2] },
      { name: 'Mié', Ausencias: absencesByDayOfWeek[3] },
      { name: 'Jue', Ausencias: absencesByDayOfWeek[4] },
      { name: 'Vie', Ausencias: absencesByDayOfWeek[5] },
    ];

    const pieChartData = [
      { name: 'Ausentismo', value: parseFloat(overallAbsenteeismLevel.toFixed(1)), fill: STATUS_COLORS.ABSENT },
      { name: 'Asistencia', value: parseFloat((100 - overallAbsenteeismLevel).toFixed(1)), fill: STATUS_COLORS.PRESENT },
    ].filter(d => d.value > 0.05); // Filter out very small or zero values to avoid rendering issues if one is 100%
                                   // Use 0.05 to catch tiny non-zero values from parseFloat.toFixed(1) that might result in 0.0% visually

    const lineChartData: { date: string; absenteeismRate: number }[] = [];
    const currentDateIter = new Date(startDate);
    while (currentDateIter <= endDate) {
        const dayOfWeek = currentDateIter.getDay();
        if (dayOfWeek >= 1 && dayOfWeek <= 5) { 
            const dateStr = formatDate(currentDateIter);
            const dailyAbs = dailyAbsencesMap.get(dateStr)?.size || 0;
            const dailyAbsenteeismRate = totalStudentsRegistered > 0 ? (dailyAbs / totalStudentsRegistered) * 100 : 0;
            lineChartData.push({ date: dateStr.substring(5), absenteeismRate: parseFloat(dailyAbsenteeismRate.toFixed(1)) });
        }
        currentDateIter.setDate(currentDateIter.getDate() + 1);
    }
    
    // Aggregation logic for line chart based on period type or custom range duration
    const aggregateWeekly = (currentLineData: { date: string; absenteeismRate: number }[], aggStartDate: Date, aggEndDate: Date) => {
        if (currentLineData.length === 0 && !(aggStartDate <= aggEndDate) ) return []; // No data to aggregate or invalid range
        const weeklyTrend: { date: string; absenteeismRate: number }[] = [];
        let currentWeekStart = getStartOfWeek(new Date(aggStartDate));
        while(currentWeekStart <= aggEndDate) {
            const currentWeekEnd = new Date(currentWeekStart);
            currentWeekEnd.setDate(currentWeekStart.getDate() + 4); // Up to Friday
            
            let weekAbsences = 0;
            let weekSchoolDays = 0;
            
            const weekDateIter = new Date(currentWeekStart);
            while(weekDateIter <= currentWeekEnd && weekDateIter <= aggEndDate) {
                if (weekDateIter >= aggStartDate) { // Ensure it's within original bounds
                    const dayOfWeekIter = weekDateIter.getDay();
                    if (dayOfWeekIter >=1 && dayOfWeekIter <=5) {
                        weekSchoolDays++;
                        weekAbsences += dailyAbsencesMap.get(formatDate(weekDateIter))?.size || 0;
                    }
                }
                weekDateIter.setDate(weekDateIter.getDate() + 1);
            }

            if (weekSchoolDays > 0 && totalStudentsRegistered > 0) {
                 const weeklyAbsenteeismRate = (weekAbsences / (totalStudentsRegistered * weekSchoolDays)) * 100;
                 weeklyTrend.push({ date: `Sem ${formatDate(currentWeekStart).substring(5)}`, absenteeismRate: parseFloat(weeklyAbsenteeismRate.toFixed(1)) });
            }
             // Ensure we move to the start of the *next* week to avoid infinite loops on short endDate
            const nextWeekStartAttempt = new Date(currentWeekStart);
            nextWeekStartAttempt.setDate(currentWeekStart.getDate() + 7);
            if (nextWeekStartAttempt <= currentWeekStart) break; // Safety break if date doesn't advance
            currentWeekStart = nextWeekStartAttempt;
        }
        return weeklyTrend;
    };
    
    if (periodOption === 'custom') {
        const diffTime = Math.abs(endDate.getTime() - startDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1; // Add 1 to include both start and end day in count for duration
        if (diffDays > 60) {
            const aggregated = aggregateWeekly(lineChartData, startDate, endDate);
            if (aggregated.length > 0) lineChartData.splice(0, lineChartData.length, ...aggregated);
        }
    } else if (periodOption === 'current_month' && lineChartData.length > 7) { // current_month and more than 1 week of daily data
        const aggregated = aggregateWeekly(lineChartData, startDate, endDate);
        if (aggregated.length > 0) lineChartData.splice(0, lineChartData.length, ...aggregated);
    }


    return {
      overallAbsenteeismLevel: parseFloat(overallAbsenteeismLevel.toFixed(2)),
      absenteeismColor,
      activeSchoolDaysInPeriod,
      totalStudentDayAbsences,
      barChartData,
      pieChartData,
      lineChartData,
      startDate,
      endDate
    };
  }, [dateRange, attendanceRecords, students, periodOption]);


  const getLineChartXAxisLabel = () => {
    if (periodOption === 'custom') {
        const diffTime = Math.abs(absenteeismData.endDate.getTime() - absenteeismData.startDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1;
        return diffDays > 60 ? 'Semana (MM-DD)' : 'Día (MM-DD)';
    }
    return periodOption === 'current_month' ? 'Semana (MM-DD)' : 'Día (MM-DD)';
  }

  return (
    <div className="p-4 md:p-6 animate-fadeIn space-y-6">
      <div className="flex justify-between items-center">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE}`}>Reporte de Ausentismo</h2>
        {canGoBack && (
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        )}
      </div>

      <div className="bg-white p-4 rounded-lg shadow space-y-3">
        <div>
            <label htmlFor="periodSelect" className="block text-sm font-medium text-gray-700 mb-1">Seleccionar Período:</label>
            <select
            id="periodSelect"
            value={periodOption}
            onChange={(e) => setPeriodOption(e.target.value as PeriodOption)}
            className="form-select w-full md:w-auto"
            >
            <option value="today">Hoy</option>
            <option value="current_week">Esta Semana (L-V)</option>
            <option value="current_month">Este Mes (L-V)</option>
            <option value="custom">Seleccionar rango personalizado</option>
            </select>
        </div>

        {periodOption === 'custom' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-3">
            <div>
              <label htmlFor="customStartDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de inicio:</label>
              <input
                type="date"
                id="customStartDate"
                value={customStartDate}
                onChange={(e) => setCustomStartDate(e.target.value)}
                max={todayFormattedForMax}
                className="form-select w-full"
              />
            </div>
            <div>
              <label htmlFor="customEndDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de fin:</label>
              <input
                type="date"
                id="customEndDate"
                value={customEndDate}
                onChange={(e) => setCustomEndDate(e.target.value)}
                max={todayFormattedForMax}
                className="form-select w-full"
              />
            </div>
            {customDateError && <p className="text-red-500 text-sm md:col-span-2">{customDateError}</p>}
          </div>
        )}
         <p className="text-xs text-gray-500 mt-1">
          Mostrando datos desde {absenteeismData.startDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' })} hasta {absenteeismData.endDate.toLocaleDateString('es-ES', { day: '2-digit', month: 'long', year: 'numeric' })}.
        </p>
      </div>

      <div className={`p-4 rounded-lg shadow text-white text-center ${absenteeismData.absenteeismColor}`}>
        <h3 className="text-lg font-semibold">Nivel de Ausentismo General</h3>
        <p className="text-4xl font-bold">{absenteeismData.overallAbsenteeismLevel}%</p>
        <p className="text-sm">(Total Ausencias Estudiante-Día: {absenteeismData.totalStudentDayAbsences} / Días Escolares Activos: {absenteeismData.activeSchoolDaysInPeriod})</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-3 text-center">Ausencias por Día de la Semana</h3>
          {absenteeismData.barChartData.some(d => d.Ausencias > 0) ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={absenteeismData.barChartData} margin={{ top: 5, right: 0, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis allowDecimals={false} />
                <Tooltip />
                <Bar dataKey="Ausencias" fill={INSTITUTIONAL_COLORS.BLUE.includes('institucional') ? '#0A4F8A' : INSTITUTIONAL_COLORS.BLUE } >
                   <LabelList dataKey="Ausencias" position="top" style={{ fill: '#333' }} />
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          ) : <p className="text-gray-500 text-center py-10">No hay datos de ausencias para el gráfico de barras.</p>}
        </div>

        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-3 text-center">Distribución General Asistencia vs. Ausentismo</h3>
          {absenteeismData.pieChartData.length > 0 ? ( // Check if there's data to render
            <ResponsiveContainer width="100%" height={300}>
              <PieChart margin={{ top: 20, right: 30, bottom: 20, left: 30 }}>
                <Pie
                  data={absenteeismData.pieChartData}
                  cx="50%"
                  cy="50%"
                  labelLine={true}
                  label={renderAbsenteeismExternalLabel}
                  outerRadius={80} // Reduced to make space for external labels
                  dataKey="value"
                  nameKey="name" // Ensure nameKey is passed for label props
                  isAnimationActive={true}
                >
                  {absenteeismData.pieChartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill || '#000'} />
                  ))}
                </Pie>
                <Tooltip formatter={(value: number) => `${value.toFixed(1)}%`} />
                <Legend wrapperStyle={{fontSize: "12px", paddingTop: "20px"}} />
              </PieChart>
            </ResponsiveContainer>
          ) : <p className="text-gray-500 text-center py-10">No hay datos para el gráfico circular.</p>}
        </div>
      </div>

      <div className="bg-white p-4 rounded-lg shadow">
        <h3 className="text-lg font-semibold text-gray-700 mb-3 text-center">Tendencia de Ausentismo ({getLineChartXAxisLabel()})</h3>
         {absenteeismData.lineChartData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
            <LineChart data={absenteeismData.lineChartData} margin={{ top: 5, right: 20, left: 0, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis label={{ value: '% Ausentismo', angle: -90, position: 'insideLeft' }} domain={[0, 'auto']}/>
                <Tooltip formatter={(value: number) => [`${value}%`, 'Ausentismo']}/>
                <Legend />
                <Line type="monotone" dataKey="absenteeismRate" name="% Ausentismo" stroke={INSTITUTIONAL_COLORS.YELLOW.includes('institucional') ? '#FFCD00' : INSTITUTIONAL_COLORS.YELLOW} strokeWidth={2} activeDot={{ r: 6 }} />
            </LineChart>
            </ResponsiveContainer>
         ) : <p className="text-gray-500 text-center py-10">No hay datos suficientes para mostrar la tendencia.</p>}
      </div>
    </div>
  );
};

export default AbsenteeismReportScreen;
