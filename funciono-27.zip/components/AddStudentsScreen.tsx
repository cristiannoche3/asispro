
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { Grade, Student, ScreenView } from '../types';
import Button from './Button';
import Modal from './Modal';
import PlusIcon from './icons/PlusIcon';
import EditIcon from './icons/EditIcon';
import DeleteIcon from './icons/DeleteIcon';
import UploadIcon from './icons/UploadIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import SwitchHorizontalIcon from './icons/SwitchHorizontalIcon'; // New Icon
import { INSTITUTIONAL_COLORS, COMPUTER_NUMBERS } from '../constants';

interface AddStudentsScreenProps {
  grades: Grade[];
  students: Student[];
  addStudent: (name: string, gradeId: string, assignedComputer: number, document?: string) => Student | null;
  addStudentsBatch: (studentsData: { name: string; document?: string; assignedComputer: number }[], gradeId: string) => void;
  editStudent: (id: string, newName: string, newAssignedComputer: number, newDocument?: string) => void;
  deleteStudent: (id: string) => void;
  changeStudentGrade: (studentId: string, newGradeId: string) => void; // New prop
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const AddStudentsScreen: React.FC<AddStudentsScreenProps> = ({
  grades,
  students,
  addStudent,
  addStudentsBatch,
  editStudent,
  deleteStudent,
  changeStudentGrade,
  setCurrentView,
  goBack,
  canGoBack
}) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>(grades.length > 0 ? grades[0].id : '');
  
  // Modal for Add/Edit Student
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentName, setStudentName] = useState('');
  const [studentDocument, setStudentDocument] = useState('');
  const [assignedComputer, setAssignedComputer] = useState<number | '' >('');
  const [error, setError] = useState('');
  
  const [searchTerm, setSearchTerm] = useState('');
  const [manualEntryText, setManualEntryText] = useState('');

  // Modal for Change Grade
  const [isChangeGradeModalOpen, setIsChangeGradeModalOpen] = useState(false);
  const [studentToChangeGrade, setStudentToChangeGrade] = useState<Student | null>(null);
  const [newSelectedGradeIdForChange, setNewSelectedGradeIdForChange] = useState<string>('');
  const [pcConflictError, setPcConflictError] = useState<string>('');

  const filteredStudents = useMemo(() => {
    return students
      .filter(s => s.gradeId === selectedGradeId)
      .filter(s => s.name.toLowerCase().includes(searchTerm.toLowerCase()) || `PC: ${s.assignedComputer}`.includes(searchTerm))
      .sort((a,b) => a.name.localeCompare(b.name));
  }, [students, selectedGradeId, searchTerm]);

  const openModalForAdd = useCallback(() => {
    if (!selectedGradeId) {
        alert("Por favor, seleccione un grado primero.");
        return;
    }
    setEditingStudent(null);
    setStudentName('');
    setStudentDocument('');
    setAssignedComputer('');
    setError('');
    setIsModalOpen(true);
  }, [selectedGradeId]);

  const openModalForEdit = useCallback((student: Student) => {
    setEditingStudent(student);
    setStudentName(student.name);
    setStudentDocument(student.document || '');
    setAssignedComputer(student.assignedComputer);
    setError('');
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setEditingStudent(null);
    setStudentName('');
    setStudentDocument('');
    setAssignedComputer('');
    setError('');
  }, []);

  // Real-time PC validation for new students
  useEffect(() => {
    if (!editingStudent && selectedGradeId) { // Only for new students
      if (assignedComputer !== '') {
        const computerNumber = Number(assignedComputer);
        const conflictingStudent = students.find(
          s => s.gradeId === selectedGradeId && s.assignedComputer === computerNumber
        );
        if (conflictingStudent) {
          setError(`⚠️ El PC N°${computerNumber} ya está asignado a ${conflictingStudent.name} en este grado. Seleccione uno libre o modifique la asignación del otro estudiante.`);
        } else {
          // Clear PC specific error only if it was previously set
          if (error.startsWith("⚠️ El PC N°")) {
            setError('');
          }
        }
      } else {
        // Clear PC specific error if PC selection is cleared
        if (error.startsWith("⚠️ El PC N°")) {
          setError('');
        }
      }
    }
  }, [assignedComputer, selectedGradeId, students, editingStudent, error]); // error is included to allow re-evaluation if error state changes externally


  const handleStudentSubmit = useCallback(() => {
    if (!studentName.trim()) {
      setError('El nombre del estudiante no puede estar vacío.');
      return;
    }
    if (assignedComputer === '') { // Check if a PC is selected
      setError('Debe seleccionar un número de computador asignado.');
      return;
    }
    
    const pcNumber = Number(assignedComputer);
    if (pcNumber < 1 || pcNumber > 35) { // This check might be redundant if select is used properly
      setError('El número de computador asignado debe estar entre 1 y 35.');
      return;
    }

    if (!selectedGradeId && !editingStudent) { 
        setError('Debe seleccionar un grado.');
        return;
    }
    
    const gradeIdToCheck = editingStudent ? editingStudent.gradeId : selectedGradeId;

    const computerInUseByOther = students.find(s => 
        s.gradeId === gradeIdToCheck && 
        s.assignedComputer === pcNumber &&
        s.id !== editingStudent?.id
    );

    if (computerInUseByOther) {
        setError(`El computador N° ${pcNumber} ya está asignado a ${computerInUseByOther.name} en este grado.`);
        return;
    }

    if (editingStudent) {
      editStudent(editingStudent.id, studentName.trim(), pcNumber, studentDocument.trim());
    } else {
      addStudent(studentName.trim(), selectedGradeId, pcNumber, studentDocument.trim());
    }
    closeModal();
  }, [studentName, studentDocument, assignedComputer, selectedGradeId, editingStudent, addStudent, editStudent, closeModal, students]);

  const handleStudentDelete = useCallback((id: string) => {
    if (window.confirm('¿Está seguro que desea eliminar este estudiante? Esta acción no se puede deshacer.')) {
      deleteStudent(id);
    }
  }, [deleteStudent]);

  const handleManualEntrySubmit = useCallback(() => {
    if (!selectedGradeId) {
      alert("Por favor, seleccione un grado para agregar los estudiantes.");
      return;
    }
    const lines = manualEntryText.split('\n').map(line => line.trim()).filter(line => line);
    if (lines.length === 0) {
      alert("Por favor, ingrese al menos un estudiante en el cuadro de texto.");
      return;
    }

    const studentsData: { name: string; assignedComputer: number; document?: string }[] = [];
    let parseError = false;
    for (const line of lines) {
        const parts = line.split(',');
        const name = parts[0]?.trim();
        const computerStr = parts[1]?.trim();
        const computerNum = parseInt(computerStr || '', 10);

        if (!name) {
            alert(`Error: Línea "${line}" no contiene un nombre válido.`);
            parseError = true;
            break;
        }
        if (isNaN(computerNum) || computerNum < 1 || computerNum > 35) {
            alert(`Error: Línea "${line}" - el número de computador "${computerStr}" no es válido (debe ser entre 1-35).`);
            parseError = true;
            break;
        }
        if (studentsData.some(s => s.assignedComputer === computerNum)) {
            alert(`Error: El número de computador ${computerNum} está duplicado en la lista de entrada manual.`);
            parseError = true;
            break;
        }
        const existingStudentWithPC = students.find(s => s.gradeId === selectedGradeId && s.assignedComputer === computerNum);
        if (existingStudentWithPC) {
            alert(`Error: El computador N° ${computerNum} ya está asignado a ${existingStudentWithPC.name} en este grado.`);
            parseError = true;
            break;
        }
        studentsData.push({ name, assignedComputer: computerNum });
    }

    if (parseError) return;

    addStudentsBatch(studentsData, selectedGradeId);
    setManualEntryText('');
    alert(`${studentsData.length} estudiante(s) agregado(s) al grado seleccionado.`);
  }, [manualEntryText, selectedGradeId, addStudentsBatch, students]);

  const handleCsvImport = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    if (!selectedGradeId) {
      alert("Por favor, seleccione un grado antes de importar el archivo CSV.");
      event.target.value = ''; 
      return;
    }
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const text = e.target?.result as string;
        const lines = text.split('\n').slice(1);
        const importedStudents: { name: string; document?: string; assignedComputer: number }[] = [];
        let importError = false;

        for (const line of lines) {
            if (!line.trim()) continue;
            const parts = line.split(',');
            const name = parts[0]?.trim();
            const computerStr = parts[1]?.trim(); 
            const document = parts[2]?.trim(); 
            const computerNum = parseInt(computerStr || '', 10);

            if (!name) {
                alert(`Error en CSV: Línea "${line}" no contiene un nombre válido.`);
                importError = true; break;
            }
            if (isNaN(computerNum) || computerNum < 1 || computerNum > 35) {
                alert(`Error en CSV: Línea "${line}" - PC "${computerStr}" no es válido (1-35).`);
                importError = true; break;
            }
            if (importedStudents.some(s => s.assignedComputer === computerNum)) {
                alert(`Error en CSV: El número de computador ${computerNum} está duplicado en el archivo.`);
                importError = true; break;
            }
            const existingStudentWithPC = students.find(s => s.gradeId === selectedGradeId && s.assignedComputer === computerNum);
            if (existingStudentWithPC) {
                alert(`Error en CSV: El computador N° ${computerNum} ya está asignado a ${existingStudentWithPC.name} en este grado.`);
                importError = true; break;
            }
            importedStudents.push({ name, document, assignedComputer: computerNum });
        }
        
        if (importError) {
            event.target.value = '';
            return;
        }

        if (importedStudents.length > 0) {
          addStudentsBatch(importedStudents, selectedGradeId);
          alert(`${importedStudents.length} estudiantes importados desde CSV.`);
        } else {
          alert("No se encontraron estudiantes válidos en el archivo CSV o el formato es incorrecto. Asegúrese: Col A: Nombre, Col B: PC Asignado (1-35). Opcional Col C: Documento.");
        }
        event.target.value = ''; 
      };
      reader.readAsText(file);
    }
  }, [selectedGradeId, addStudentsBatch, students]);

  // --- Change Grade Modal Logic ---
  const openChangeGradeModal = useCallback((student: Student) => {
    setStudentToChangeGrade(student);
    setNewSelectedGradeIdForChange(''); 
    setPcConflictError('');
    setIsChangeGradeModalOpen(true);
  }, []);

  const closeChangeGradeModal = useCallback(() => {
    setIsChangeGradeModalOpen(false);
    setStudentToChangeGrade(null);
    setNewSelectedGradeIdForChange('');
    setPcConflictError('');
  }, []);

  useEffect(() => {
    if (studentToChangeGrade && newSelectedGradeIdForChange) {
      const studentPC = studentToChangeGrade.assignedComputer;
      const conflictStudent = students.find(
        s => s.gradeId === newSelectedGradeIdForChange && s.assignedComputer === studentPC && s.id !== studentToChangeGrade.id
      );
      if (conflictStudent) {
        const newGradeObj = grades.find(g => g.id === newSelectedGradeIdForChange);
        setPcConflictError(
          `Conflicto de PC: El computador N° ${studentPC} ya está asignado a ${conflictStudent.name} en el grado ${newGradeObj?.name || 'destino'}. Por favor, cambie el PC del estudiante actual o del estudiante en el grado destino antes de moverlo.`
        );
      } else {
        setPcConflictError('');
      }
    } else {
      setPcConflictError('');
    }
  }, [newSelectedGradeIdForChange, studentToChangeGrade, students, grades]);

  const handleChangeGradeSubmit = useCallback(() => {
    if (!studentToChangeGrade || !newSelectedGradeIdForChange || pcConflictError) {
      alert("Por favor, resuelva los conflictos o seleccione un nuevo grado válido.");
      return;
    }
    const newGradeObj = grades.find(g => g.id === newSelectedGradeIdForChange);
    if (window.confirm(`¿Estás seguro de que deseas mover a ${studentToChangeGrade.name} al grado ${newGradeObj?.name || 'desconocido'}? Todos sus registros se conservarán.`)) {
      changeStudentGrade(studentToChangeGrade.id, newSelectedGradeIdForChange);
      alert(`${studentToChangeGrade.name} ha sido movido al grado ${newGradeObj?.name || 'desconocido'} exitosamente.`);
      closeChangeGradeModal();
    }
  }, [studentToChangeGrade, newSelectedGradeIdForChange, pcConflictError, grades, changeStudentGrade, closeChangeGradeModal]);
  
  if (grades.length === 0) {
    return (
      <div className="p-6 text-center">
         {canGoBack && (
            <div className="text-left mb-6">
            <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
                Regresar
            </Button>
            </div>
        )}
        <p className="text-gray-600 text-lg mb-4">No hay grados creados. Por favor, primero gestione los grados.</p>
        <Button onClick={() => setCurrentView(ScreenView.MANAGE_GRADES)} variant="primary">
          Ir a Gestionar Grados
        </Button>
      </div>
    );
  }

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="flex flex-col md:flex-row justify-between md:items-center mb-6 gap-4">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE}`}>Agregar y Administrar Estudiantes</h2>
        <div className="flex items-center gap-2">
            <label htmlFor="gradeSelect" className="sr-only">Seleccionar Grado</label>
            <select
                id="gradeSelect"
                value={selectedGradeId}
                onChange={(e) => setSelectedGradeId(e.target.value)}
                className="form-select"
            >
                {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
            <Button onClick={openModalForAdd} leftIcon={<PlusIcon className="w-5 h-5" />} disabled={!selectedGradeId}>
                Nuevo Estudiante
            </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-6">
        <div className="lg:col-span-1 bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Agregar Manualmente (Lista)</h3>
           <p className="text-sm text-gray-500 mb-2">Formato: Nombre Completo,NúmeroPC (ej: Juan Perez,5)</p>
          <textarea
            value={manualEntryText}
            onChange={(e) => setManualEntryText(e.target.value)}
            placeholder="Pegue la lista (uno por línea). Ej: Ana Soto,10"
            rows={5}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue mb-2"
            disabled={!selectedGradeId}
          />
          <Button onClick={handleManualEntrySubmit} className="w-full" disabled={!selectedGradeId || !manualEntryText.trim()}>
            Agregar Lista al Grado Seleccionado
          </Button>
        </div>
        <div className="lg:col-span-1 bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-semibold text-gray-700 mb-2">Importar desde CSV</h3>
          <p className="text-sm text-gray-500 mb-2">Col A: Nombre, Col B: PC Asignado (1-35). Opcional Col C: Documento.</p>
          <input
            type="file"
            accept=".csv"
            onChange={handleCsvImport}
            className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-institucional-blue file:text-institucional-white hover:file:bg-sky-800 disabled:opacity-50"
            disabled={!selectedGradeId}
          />
           {!selectedGradeId && <p className="text-xs text-red-500 mt-1">Seleccione un grado para habilitar la importación.</p>}
        </div>
         <div className="lg:col-span-1 bg-white p-4 rounded-lg shadow">
           <h3 className="text-lg font-semibold text-gray-700 mb-2">Buscar Estudiante</h3>
            <input
                type="text"
                placeholder="Buscar por nombre o PC asignado..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
                disabled={!selectedGradeId}
            />
        </div>
      </div>
      
      {selectedGradeId && (
        <>
            <h3 className="text-xl font-semibold text-gray-700 mb-3">
                Estudiantes en {grades.find(g => g.id === selectedGradeId)?.name || 'Grado Desconocido'}
            </h3>
            {filteredStudents.length === 0 ? (
                <p className="text-gray-600 text-center py-10">
                {searchTerm ? 'No se encontraron estudiantes con ese nombre o PC.' : 'No hay estudiantes en este grado. Agregue estudiantes individualmente, pegando una lista o importando un CSV.'}
                </p>
            ) : (
                <div className="bg-white shadow-md rounded-lg overflow-hidden">
                <ul className="divide-y divide-gray-200">
                    {filteredStudents.map((student) => (
                    <li key={student.id} className="p-4 flex flex-col sm:flex-row justify-between sm:items-center gap-3 hover:bg-gray-50 transition-colors">
                        <div>
                            <span className="text-lg text-gray-700">{student.name}</span>
                            <span className="block text-sm text-blue-600 font-medium">PC Asignado: {student.assignedComputer}</span>
                            {student.document && <span className="block text-sm text-gray-500">Doc: {student.document}</span>}
                        </div>
                        <div className="flex flex-wrap gap-2 justify-start sm:justify-end">
                          <Button variant="ghost" size="sm" onClick={() => openModalForEdit(student)} leftIcon={<EditIcon className="w-4 h-4" />}>Editar</Button>
                          <Button variant="ghost" size="sm" onClick={() => openChangeGradeModal(student)} leftIcon={<SwitchHorizontalIcon className="w-4 h-4" />} className="text-purple-600 border-purple-300 hover:bg-purple-50">Cambiar Grado</Button>
                          <Button variant="danger" size="sm" onClick={() => handleStudentDelete(student.id)} leftIcon={<DeleteIcon className="w-4 h-4" />}>Eliminar</Button>
                        </div>
                    </li>
                    ))}
                </ul>
                </div>
            )}
        </>
      )}
      {!selectedGradeId && grades.length > 0 && (
         <p className="text-gray-600 text-center py-10">Por favor, seleccione un grado para ver y administrar estudiantes.</p>
      )}

      {/* Modal for Add/Edit Student */}
      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingStudent ? 'Editar Estudiante' : 'Nuevo Estudiante'}
        footer={
          <>
            <Button variant="ghost" onClick={closeModal}>Cancelar</Button>
            <Button onClick={handleStudentSubmit} disabled={!editingStudent && !!error && error.startsWith("⚠️ El PC N°")}>
                {editingStudent ? 'Guardar Cambios' : 'Crear Estudiante'}
            </Button>
          </>
        }
      >
        <div>
          <div className="mb-4">
            <label htmlFor="studentNameModal" className="block text-sm font-medium text-gray-700 mb-1">Nombre Completo</label>
            <input
              type="text"
              id="studentNameModal"
              value={studentName}
              onChange={(e) => setStudentName(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
              placeholder="Ej: Ana María Pérez"
              required
            />
          </div>
           <div className="mb-4">
            <label htmlFor="assignedComputerModal" className="block text-sm font-medium text-gray-700 mb-1">Número de Computador Asignado</label>
            {editingStudent ? (
                 <input // Keep input for editing for flexibility, validation on submit
                    type="number"
                    id="assignedComputerModal"
                    value={assignedComputer}
                    onChange={(e) => setAssignedComputer(e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                    min="1"
                    max="35"
                    className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
                    placeholder="Ej: 15"
                    required
                 />
            ) : (
                <select
                    id="assignedComputerModal"
                    value={assignedComputer}
                    onChange={(e) => setAssignedComputer(e.target.value === '' ? '' : parseInt(e.target.value, 10))}
                    className="form-select w-full"
                    required
                >
                    <option value="">-- Seleccione un PC --</option>
                    {COMPUTER_NUMBERS.map(num => (
                        <option key={num} value={num}>{num}</option>
                    ))}
                </select>
            )}
          </div>
          <div>
            <label htmlFor="studentDocumentModal" className="block text-sm font-medium text-gray-700 mb-1">Documento (Opcional)</label>
            <input
              type="text"
              id="studentDocumentModal"
              value={studentDocument}
              onChange={(e) => setStudentDocument(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
              placeholder="Ej: TI 1234567890"
            />
          </div>
          {error && <p className="text-red-500 text-sm mt-2">{error}</p>}
        </div>
      </Modal>

      {/* Modal for Change Grade */}
      {studentToChangeGrade && (
        <Modal
            isOpen={isChangeGradeModalOpen}
            onClose={closeChangeGradeModal}
            title={`Cambiar Grado de ${studentToChangeGrade.name}`}
            footer={
            <>
                <Button variant="ghost" onClick={closeChangeGradeModal}>Cancelar</Button>
                <Button 
                    onClick={handleChangeGradeSubmit} 
                    disabled={!newSelectedGradeIdForChange || !!pcConflictError}
                >
                    Confirmar Cambio
                </Button>
            </>
            }
        >
            <div>
            <p className="text-sm text-gray-600 mb-1">
                Grado Actual: <span className="font-semibold">{grades.find(g => g.id === studentToChangeGrade.gradeId)?.name || 'N/A'}</span>
            </p>
            <p className="text-sm text-gray-600 mb-3">
                PC Asignado: <span className="font-semibold">{studentToChangeGrade.assignedComputer}</span>
            </p>
            
            <label htmlFor="newGradeSelect" className="block text-sm font-medium text-gray-700 mb-1">Seleccionar Nuevo Grado:</label>
            <select
                id="newGradeSelect"
                value={newSelectedGradeIdForChange}
                onChange={(e) => setNewSelectedGradeIdForChange(e.target.value)}
                className="form-select w-full"
            >
                <option value="">-- Seleccione un nuevo grado --</option>
                {grades
                    .filter(g => g.id !== studentToChangeGrade.gradeId) // Exclude current grade
                    .map(g => <option key={g.id} value={g.id}>{g.name}</option>)
                }
            </select>

            {pcConflictError && (
                <p className="text-red-500 text-sm mt-2">{pcConflictError}</p>
            )}
            {!pcConflictError && newSelectedGradeIdForChange && (
                <p className="text-green-600 text-sm mt-2">
                    PC N° {studentToChangeGrade.assignedComputer} está disponible en el grado destino.
                </p>
            )}
             <p className="text-xs text-gray-500 mt-4">
                Todos los registros de asistencia y reportes del estudiante se conservarán y asociarán al nuevo grado.
             </p>
            </div>
        </Modal>
      )}
    </div>
  );
};

export default AddStudentsScreen;
