
import React, { useMemo, useState, useEffect } from 'react';
import { ScreenView, Student, AttendanceRecord, AttendanceStatus, Grade } from '../types';
import Button from './Button';
import { INSTITUTIONAL_COLORS, ALERT_THRESHOLD_UNEXCUSED_ABSENCES } from '../constants';

interface DailySummaryScreenProps {
  setCurrentView: (view: ScreenView) => void;
  students: Student[];
  attendanceRecords: AttendanceRecord[];
  grades: Grade[];
}

// Helper function to get the start of the week (Monday)
const getStartOfWeek = (date: Date): Date => {
    const d = new Date(date);
    const day = d.getDay(); // Sunday - 0, Monday - 1, ..., Saturday - 6
    const diff = d.getDate() - day + (day === 0 ? -6 : 1); // Adjust when day is Sunday
    d.setDate(diff)
    d.setHours(0,0,0,0);
    return d;
};

interface StudentAlertDetail {
  studentId: string;
  studentName: string;
  gradeId: string;
  gradeName: string;
  unexcusedAbsenceCount: number;
  lastUnexcusedAbsenceDate: string; // YYYY-MM-DD
}

interface GroupedAlerts {
  [gradeId: string]: {
    gradeName: string;
    alerts: StudentAlertDetail[];
  };
}


const DailySummaryScreen: React.FC<DailySummaryScreenProps> = ({ setCurrentView, students, attendanceRecords, grades }) => {
  const todayDateObject = new Date();
  const currentDayOfWeek = todayDateObject.getDay(); // 0 for Sunday, 6 for Saturday
  const isWeekend = currentDayOfWeek === 0 || currentDayOfWeek === 6;

  const [activeGradeTabId, setActiveGradeTabId] = useState<string | null>(null);

  const dailyStats = useMemo(() => {
    if (isWeekend) {
      return {
        isWeekendDay: true,
        totalStudentsRegistered: 0,
        absencesToday: 0,
        attendancePercentageToday: 'N/A',
      };
    }

    const todayStr = todayDateObject.toISOString().split('T')[0];
    const totalStudentsRegistered = students.length;

    const recordsToday = attendanceRecords.filter(r => r.date === todayStr);
    const studentIdsWithAnyRecordToday = new Set(recordsToday.map(r => r.studentId));

    const actualPresentStudents = new Set<string>();
    const actualAbsentStudentsStrict = new Set<string>();

    studentIdsWithAnyRecordToday.forEach(studentId => {
        const studentRecordsToday = recordsToday.filter(r => r.studentId === studentId);
        const wasPresent = studentRecordsToday.some(r => r.status === AttendanceStatus.PRESENT);
        
        if (wasPresent) {
            actualPresentStudents.add(studentId);
        } else { 
            actualAbsentStudentsStrict.add(studentId);
        }
    });

    const numberOfStudentsWhoDidNotAttend = actualAbsentStudentsStrict.size;
    const numberOfAttendingStudents = actualPresentStudents.size;
    const totalStudentsWithRecordsToday = studentIdsWithAnyRecordToday.size;

    const attendancePercentageToday = totalStudentsWithRecordsToday > 0
        ? ((numberOfAttendingStudents / totalStudentsWithRecordsToday) * 100).toFixed(2)
        : 'N/A';

    return {
      isWeekendDay: false,
      totalStudentsRegistered,
      absencesToday: numberOfStudentsWhoDidNotAttend,
      attendancePercentageToday,
    };
  }, [students, attendanceRecords, isWeekend, todayDateObject]);

  const groupedAlertsData = useMemo(() => {
    const studentAbsenceDetails: Record<string, { student: Student; count: number; lastDate: string }> = {};

    attendanceRecords.forEach(record => {
        if (record.status === AttendanceStatus.ABSENT_UNEXCUSED) {
            if (!studentAbsenceDetails[record.studentId]) {
                const student = students.find(s => s.id === record.studentId);
                if (student) {
                    studentAbsenceDetails[record.studentId] = { student, count: 0, lastDate: '' };
                }
            }
            if (studentAbsenceDetails[record.studentId]) {
                studentAbsenceDetails[record.studentId].count++;
                if (record.date > studentAbsenceDetails[record.studentId].lastDate) {
                    studentAbsenceDetails[record.studentId].lastDate = record.date;
                }
            }
        }
    });

    const filteredStudentAlerts: StudentAlertDetail[] = Object.values(studentAbsenceDetails)
        .filter(data => data.count >= ALERT_THRESHOLD_UNEXCUSED_ABSENCES)
        .map(data => {
            const grade = grades.find(g => g.id === data.student.gradeId);
            return {
                studentId: data.student.id,
                studentName: data.student.name,
                gradeId: data.student.gradeId,
                gradeName: grade?.name || 'N/A',
                unexcusedAbsenceCount: data.count,
                lastUnexcusedAbsenceDate: data.lastDate,
            };
        });

    const grouped: GroupedAlerts = {};
    filteredStudentAlerts.forEach(alert => {
        if (!grouped[alert.gradeId]) {
            grouped[alert.gradeId] = {
                gradeName: alert.gradeName,
                alerts: [],
            };
        }
        grouped[alert.gradeId].alerts.push(alert);
        grouped[alert.gradeId].alerts.sort((a,b) => b.unexcusedAbsenceCount - a.unexcusedAbsenceCount || a.studentName.localeCompare(b.studentName));
    });
    
    const gradeIdsWithAlerts = Object.keys(grouped).sort((a, b) => (grouped[a]?.gradeName || '').localeCompare(grouped[b]?.gradeName || ''));

    return { grouped, gradeIdsWithAlerts };
  }, [attendanceRecords, students, grades]);

  useEffect(() => {
    const { gradeIdsWithAlerts } = groupedAlertsData;
    if (gradeIdsWithAlerts.length > 0 && !activeGradeTabId) {
        setActiveGradeTabId(gradeIdsWithAlerts[0]);
    } else if (gradeIdsWithAlerts.length > 0 && activeGradeTabId && !gradeIdsWithAlerts.includes(activeGradeTabId)) {
        // If current active tab is no longer valid (e.g. alerts cleared for it), switch to first available
        setActiveGradeTabId(gradeIdsWithAlerts[0]);
    } else if (gradeIdsWithAlerts.length === 0 && activeGradeTabId) {
        setActiveGradeTabId(null); // No alerts, no active tab
    }
  }, [groupedAlertsData, activeGradeTabId]);


  const weeklySummary = useMemo(() => {
    const startOfWeek = getStartOfWeek(todayDateObject);
    
    const daysOfWeekBusiness = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
    const weeklyDataInit: Record<string, { dateStr: string, present: number, absent: number, records: number }> = {};

    for (let i = 0; i < 5; i++) { // Iterate only for Monday to Friday
        const currentDate = new Date(startOfWeek);
        currentDate.setDate(startOfWeek.getDate() + i);
        const dateStr = currentDate.toISOString().split('T')[0];
        weeklyDataInit[daysOfWeekBusiness[i]] = { dateStr, present: 0, absent: 0, records: 0 };
    }

    let totalWeeklyPresentSessions = 0;
    let totalWeeklyRegisteredSessions = 0;

    attendanceRecords.forEach(record => {
        const recordDate = new Date(record.date + 'T00:00:00Z');
        recordDate.setUTCHours(0,0,0,0);
        
        const recordDayOfWeek = recordDate.getUTCDay(); // Sunday=0, Monday=1 ... Saturday=6

        if (recordDayOfWeek === 0 || recordDayOfWeek === 6) {
            return;
        }

        const endOfWeekForBusinessDays = new Date(startOfWeek);
        endOfWeekForBusinessDays.setDate(startOfWeek.getDate() + 4); 
        endOfWeekForBusinessDays.setUTCHours(23,59,59,999);

        if (recordDate >= startOfWeek && recordDate <= endOfWeekForBusinessDays) {
            const dayIndex = (recordDayOfWeek + 6) % 7; 
            const dayName = daysOfWeekBusiness[dayIndex];

            if (dayName && weeklyDataInit[dayName]) {
                 weeklyDataInit[dayName].records++; 
                 totalWeeklyRegisteredSessions++;

                if (record.status === AttendanceStatus.PRESENT) {
                    weeklyDataInit[dayName].present++;
                    totalWeeklyPresentSessions++;
                } else if (
                    record.status === AttendanceStatus.ABSENT_UNEXCUSED ||
                    record.status === AttendanceStatus.ABSENT_EXCUSED ||
                    record.status === AttendanceStatus.SICK_BAY
                ) {
                    weeklyDataInit[dayName].absent++;
                }
            }
        }
    });

    const averageWeeklyAttendance = totalWeeklyRegisteredSessions > 0
        ? ((totalWeeklyPresentSessions / totalWeeklyRegisteredSessions) * 100).toFixed(1)
        : '0.0';

    let maxAbsences = -1;
    let daysWithMaxAbsences: string[] = [];
    Object.entries(weeklyDataInit).forEach(([day, data]) => {
        if (data.absent > 0 && data.absent > maxAbsences) {
            maxAbsences = data.absent;
            daysWithMaxAbsences = [day];
        } else if (data.absent > 0 && data.absent === maxAbsences) {
            daysWithMaxAbsences.push(day);
        }
    });
    
    const dailySummaryForDisplay = daysOfWeekBusiness.map(dayName => {
        const dayData = weeklyDataInit[dayName];
        const dateObj = new Date(dayData.dateStr + 'T00:00:00Z');
        return {
            day: dayName,
            date: `${String(dateObj.getUTCDate()).padStart(2, '0')}/${String(dateObj.getUTCMonth() + 1).padStart(2, '0')}`,
            present: dayData.present,
            absent: dayData.absent,
        };
    });

    return {
        dailySummary: dailySummaryForDisplay,
        averageWeeklyAttendance,
        daysWithMaxAbsences: maxAbsences > 0 ? daysWithMaxAbsences.join(', ') : 'Ninguno',
    };
  }, [attendanceRecords, todayDateObject]);


  return (
    <div className="p-6 md:p-10 flex flex-col items-center justify-center min-h-[calc(100vh-150px)] animate-fadeIn">
      <div className="w-full max-w-3xl text-center">
        <h1 className={`text-3xl md:text-4xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-3`}>
          Resumen del Día
        </h1>
        <p className="text-lg text-gray-600 mb-6">
          {todayDateObject.toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        </p>

        <div className="mb-8 p-6 bg-white shadow-xl rounded-lg border-t-4 border-institucional-yellow">
          {dailyStats.isWeekendDay ? (
            <p className="text-2xl text-institucional-blue font-semibold py-8">
              Hoy no hay clases. ¡Disfruta tu fin de semana! &#x1F60A;
            </p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="p-4 bg-gray-50 rounded-lg shadow-inner">
                <p className="text-4xl font-extrabold text-institucional-blue">{dailyStats.totalStudentsRegistered}</p>
                <p className="text-md text-gray-600 mt-1">Estudiantes Totales</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg shadow-inner">
                <p className={`text-4xl font-extrabold ${dailyStats.absencesToday > 0 ? 'text-red-500' : 'text-green-500'}`}>
                  {dailyStats.absencesToday}
                </p>
                <p className="text-md text-gray-600 mt-1">Estudiantes Ausentes Hoy</p>
              </div>
              <div className="p-4 bg-gray-50 rounded-lg shadow-inner">
                <p className={`text-4xl font-extrabold ${dailyStats.attendancePercentageToday === 'N/A' || parseFloat(dailyStats.attendancePercentageToday) < 70 ? 'text-red-500' : 'text-green-500'}`}>
                  {dailyStats.attendancePercentageToday}{dailyStats.attendancePercentageToday !== 'N/A' ? '%' : ''}
                </p>
                <p className="text-md text-gray-600 mt-1">Asistencia Hoy (%)</p>
              </div>
            </div>
          )}
        </div>

        {groupedAlertsData.gradeIdsWithAlerts.length > 0 && (
            <div className="mb-8 p-4 sm:p-6 bg-red-50 shadow-lg rounded-lg border-2 border-red-500 text-left">
                <h2 className="text-xl sm:text-2xl font-semibold text-red-700 mb-4 text-center">
                    Alerta de Inasistencias (Sin Excusa Acumuladas)
                </h2>
                <div className="mb-4 border-b border-red-300 pb-2 flex flex-wrap justify-center gap-2">
                    {groupedAlertsData.gradeIdsWithAlerts.map(gradeId => (
                        <Button
                            key={gradeId}
                            onClick={() => setActiveGradeTabId(gradeId)}
                            variant={activeGradeTabId === gradeId ? 'danger' : 'ghost'}
                            size="sm"
                            className={`${activeGradeTabId === gradeId ? '!bg-red-600 text-white' : 'border-red-400 text-red-600 hover:bg-red-100'} !px-3 !py-1.5`}
                        >
                            {groupedAlertsData.grouped[gradeId]?.gradeName || 'Desconocido'}
                        </Button>
                    ))}
                </div>

                {activeGradeTabId && groupedAlertsData.grouped[activeGradeTabId]?.alerts.length > 0 ? (
                    <ul className="divide-y divide-red-200 max-h-96 overflow-y-auto">
                        {groupedAlertsData.grouped[activeGradeTabId].alerts.map(alert => (
                            <li key={alert.studentId} className="py-3 px-2">
                                <div className="flex justify-between items-center">
                                    <div>
                                        <span className="font-medium text-red-800">{alert.studentName}</span>
                                        <span className="text-xs text-red-600 block sm:inline sm:ml-1">({alert.gradeName})</span>
                                    </div>
                                    <span className="text-sm text-red-700 font-semibold whitespace-nowrap">
                                        {alert.unexcusedAbsenceCount} Inasistencias S.E.
                                    </span>
                                </div>
                                <p className="text-xs text-red-500 mt-0.5">
                                    Última ausencia: {new Date(alert.lastUnexcusedAbsenceDate + 'T00:00:00').toLocaleDateString('es-ES', { day: '2-digit', month: 'short', year: 'numeric' })}
                                </p>
                            </li>
                        ))}
                    </ul>
                ) : (
                  activeGradeTabId && (
                    <p className="text-center text-green-700 font-semibold py-4">
                        Sin alertas en {groupedAlertsData.grouped[activeGradeTabId]?.gradeName || 'este grado'} ✅
                    </p>
                  )
                )}
                 {!activeGradeTabId && groupedAlertsData.gradeIdsWithAlerts.length > 0 && (
                    <p className="text-center text-gray-600 py-4">Seleccione un grado para ver las alertas.</p>
                )}
            </div>
        )}
        {groupedAlertsData.gradeIdsWithAlerts.length === 0 && !isWeekend && (
             <div className="mb-8 p-6 bg-green-50 shadow-lg rounded-lg border-2 border-green-500 text-center">
                <p className="text-xl font-semibold text-green-700">No hay alertas de inasistencias activas. ¡Buen trabajo! ✅</p>
            </div>
        )}


        <div className="mb-8 p-6 bg-white shadow-xl rounded-lg border-t-4 border-institucional-blue text-left">
            <h2 className={`text-2xl font-semibold text-${INSTITUTIONAL_COLORS.BLUE} mb-4 text-center`}>Resumen Semanal (Lunes a Viernes)</h2>
            <div className="overflow-x-auto mb-4">
                <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                        <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Día</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Presentes (Sesiones)</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ausentes (Sesiones)</th>
                        </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {weeklySummary.dailySummary.map(dayData => (
                            <tr key={dayData.day}>
                                <td className="px-4 py-2 whitespace-nowrap text-sm font-medium text-gray-900">{dayData.day}</td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-gray-500">{dayData.date}</td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-green-600 text-right">{dayData.present}</td>
                                <td className="px-4 py-2 whitespace-nowrap text-sm text-red-600 text-right">{dayData.absent}</td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-center md:text-left">
                <p className="text-md text-gray-700">
                    <strong>Promedio Semanal de Asistencia (sesiones): </strong> 
                    <span className={`font-bold ${parseFloat(weeklySummary.averageWeeklyAttendance) < 70 ? 'text-red-500' : 'text-green-600'}`}>
                        {weeklySummary.averageWeeklyAttendance}%
                    </span>
                </p>
                <p className="text-md text-gray-700">
                    <strong>Día(s) con Mayor Nº de Ausencias: </strong>
                    <span className="font-bold text-institucional-blue">{weeklySummary.daysWithMaxAbsences}</span>
                </p>
            </div>
        </div>


        <Button
          onClick={() => setCurrentView(ScreenView.MAIN_MENU)}
          size="lg"
          variant="primary"
          className="px-10 py-4 text-xl mt-4"
        >
          Empezar Gestión de Asistencia
        </Button>
         <p className="text-gray-500 mt-10 text-sm">
           Bienvenido al sistema de Llamada Fácil de Asistencia.
        </p>
      </div>
    </div>
  );
};

export default DailySummaryScreen;
