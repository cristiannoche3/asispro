
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import { Student, Grade, Period, AttendanceRecord, ScreenView, AttendanceStatus } from '../types';
import Modal from './Modal';
import Button from './Button';
import { INSTITUTIONAL_COLORS } from '../constants';

interface AsiBotProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  grades: Grade[];
  periods: Period[];
  activePeriodId: string | null;
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
}

interface ChatMessage {
  id: string;
  sender: 'user' | 'asibot';
  text: string;
}

const suggestedQuestions = [
  "¿Quién faltó hoy en 7B?",
  "¿Qué computador usó Juan Pérez ayer?",
  "¿Cómo genero un reporte de asistencia?",
  "¿Qué horas ya fueron tomadas para 6A hoy?",
  "¿Cómo puedo ver las asistencias guardadas?",
  "Explícame cómo agregar un nuevo estudiante.",
  "¿Qué hago si un PC está asignado a dos estudiantes?",
];


const AsiBot: React.FC<AsiBotProps> = ({
  isOpen,
  onClose,
  students,
  grades,
  periods,
  activePeriodId,
  attendanceRecords,
  setCurrentView
}) => {
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const chatBodyRef = useRef<HTMLDivElement>(null);
  const ai = useRef<GoogleGenAI | null>(null);

  useEffect(() => {
    if (isOpen) {
        try {
            if (!ai.current) { // Initialize only if not already initialized
                 // Ensure process.env.API_KEY is available.
                 // If not, this will throw and be caught by the catch block.
                if (!process.env.API_KEY) {
                    throw new Error("API_KEY no está configurada.");
                }
                ai.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
            }
            if (chatMessages.length === 0) {
                setChatMessages([{ id: Date.now().toString(), sender: 'asibot', text: "Hola, soy AsiBot. ¿En qué puedo ayudarte hoy sobre la asistencia o los registros de AsisPRO?" }]);
            }
        } catch (error) {
            console.error("Error initializing GoogleGenAI for AsiBot:", error);
            const errorMessage = error instanceof Error ? error.message : "Error desconocido al inicializar.";
            setChatMessages([{ id: Date.now().toString(), sender: 'asibot', text: `Lo siento, no puedo conectarme en este momento. Error: ${errorMessage}` }]);
        }
    }
  }, [isOpen, chatMessages.length]); // Added chatMessages.length to ensure welcome message appears if cleared

  useEffect(() => {
    if (chatBodyRef.current) {
      chatBodyRef.current.scrollTop = chatBodyRef.current.scrollHeight;
    }
  }, [chatMessages]);

  const handleSendMessage = useCallback(async (messageText?: string) => {
    const currentMessage = (messageText || userInput).trim();
    if (!currentMessage || isLoading || !ai.current) return;

    const newUserMessage: ChatMessage = { id: Date.now().toString() + 'u', sender: 'user', text: currentMessage };
    setChatMessages(prev => [...prev, newUserMessage]);
    if (!messageText) { // Clear input only if it wasn't a suggested question click
        setUserInput('');
    }
    setIsLoading(true);

    try {
      const activePeriod = periods.find(p => p.id === activePeriodId);
      const today = new Date().toISOString().split('T')[0];

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      sevenDaysAgo.setHours(0,0,0,0); 

      const relevantAttendance = attendanceRecords
        .filter(r => {
          const recordDateParts = r.date.split('-').map(part => parseInt(part, 10));
          const recordDate = new Date(recordDateParts[0], recordDateParts[1] - 1, recordDateParts[2]);
          recordDate.setHours(0,0,0,0); 
          return recordDate >= sevenDaysAgo;
        })
        .sort((a, b) => { 
            const dateComparison = new Date(b.date).getTime() - new Date(a.date).getTime();
            if (dateComparison !== 0) return dateComparison;
            const studentA = students.find(s => s.id === a.studentId)?.name || '';
            const studentB = students.find(s => s.id === b.studentId)?.name || '';
            return studentA.localeCompare(studentB);
        })
        .slice(0, 150); // Reduced sample size slightly

      const dataContext = `
        Today's Date: ${today} (Format: YYYY-MM-DD)
        Active Period: ${activePeriod ? activePeriod.name : 'No configurado'}
        Grades: ${JSON.stringify(grades.map(g => ({ id: g.id, name: g.name })))}
        Students (sample, sensitive info like document omitted): ${JSON.stringify(students.slice(0,50).map(s => ({ id: s.id, name: s.name, gradeId: s.gradeId, assignedComputer: s.assignedComputer })))}
        Attendance Records (sample from last 7 days, max 150 records, sorted recent first): ${JSON.stringify(relevantAttendance.map(ar => ({
          studentId: ar.studentId,
          studentName: students.find(s => s.id === ar.studentId)?.name || 'Desconocido',
          gradeId: ar.gradeId,
          gradeName: grades.find(g => g.id === ar.gradeId)?.name || 'Desconocido',
          date: ar.date,
          status: ar.status,
          usedComputer: ar.usedComputer,
          classHours: ar.classHours.join(',')
        })))}
        Periods: ${JSON.stringify(periods.map(p => ({ id: p.id, name: p.name })))}
        Attendance Status Meanings: ${JSON.stringify(AttendanceStatus)}
      `;

      const prompt = `
        Eres AsiBot, un asistente virtual IA para la plataforma AsisPRO. Tu propósito es ayudar a los usuarios a entender y usar AsisPRO.
        Debes ser conciso, factual y basar tus respuestas ÚNICAMENTE en la información del 'Data Context' y el conocimiento general sobre AsisPRO que te proporciono a continuación.
        Usa párrafos cortos. Si una lista es apropiada, usa '*' para viñetas o '1.' para numeración.

        CONOCIMIENTO GENERAL DE ASISPRO:
        - Funcionalidad Principal: AsisPRO gestiona la asistencia de estudiantes y el uso de computadores en un colegio.
        - Módulos Clave:
          * Gestionar Grados: Crear, editar, eliminar grados/cursos.
          * Agregar Estudiantes: Añadir estudiantes a grados, asignarles un PC. Permite carga manual, por lista, o CSV. Se puede cambiar un estudiante de grado.
          * Llamar Asistencia: Registrar asistencia (Presente, Ausente S.E., Ausente Just., Enfermería) y PC usado por cada estudiante para horas de clase específicas en una fecha. Valida conflictos de PC y duplicación de horas para un mismo grado/fecha.
          * Ver Asistencias Guardadas: Consultar, modificar o eliminar registros de asistencia ya tomados. Permite gestionar asistencias por día.
          * Reportes de Asistencia: Individual (detalle por estudiante) y Grupal (resumen por grado). Incluye gráficos. Exportables a PDF/CSV.
          * Reportes de Computadores:
              - Por Grado: Detalla qué PC usó cada estudiante de un grado en fechas específicas.
              - General: Muestra qué estudiante usó cada PC en el colegio en fechas seleccionadas, abarcando todos los grados.
          * Reporte de Ausentismo: Analiza niveles y tendencias de ausentismo (general, por día de semana) con gráficos. Permite filtrar por periodos (hoy, semana, mes, personalizado).
          * Configurar Periodos: Definir periodos académicos (ej: Primer Periodo) y marcar uno como activo.
        - Seguridad:
          * Login: Se requiere contraseña para acceder.
          * Recuperación de Contraseña: Mediante preguntas de seguridad.
          * Cerrar Sesión: Botón para salir y volver al login.
        - Validaciones Comunes:
          * Al tomar asistencia: No se puede asignar el mismo PC a dos estudiantes en la misma sesión. Un estudiante ausente no usa PC. No se pueden tomar las mismas horas dos veces para el mismo grado/fecha.
          * Al agregar estudiantes: No se pueden asignar PCs ya ocupados en el mismo grado.

        RESPUESTAS A PREGUNTAS COMUNES:
        - "Quién faltó hoy en [GradoX]?": Busca en 'Attendance Records' estudiantes de [GradoX] con estado Ausente (S.E. o Just.) para 'Today's Date'. Lista sus nombres. Si no hay, informa "No hubo ausentes en [GradoX] hoy."
        - "[EstudianteX] usó el PC [Y] ayer?": Busca a 'EstudianteX'. Revisa sus 'Attendance Records' para 'yesterday's date' y si 'usedComputer' fue [Y]. Responde sí/no, con detalles.
        - "Se llamó lista hoy en [GradoX]?": Revisa si hay 'Attendance Records' para [GradoX] en 'Today's Date'. Si sí, menciona las horas. Si no, "No hay registros de asistencia para [GradoX] hoy."
        - "Cómo genero un reporte de [TipoReporte]?": Dirige al usuario. Ej: "Para el reporte de ausentismo, ve a 'Reporte de Ausentismo' en el Menú Principal." No intentes generar el contenido del reporte tú mismo.
        - "Qué horas ya tomaron para [GradoX] hoy?": Basado en 'Attendance Records' para [GradoX] y 'Today's Date', lista las 'classHours' ya registradas.

        REGLAS IMPORTANTES:
        1.  Si la información solicitada NO está en el 'Data Context' o el conocimiento general provisto, INDICA CLARAMENTE que no tienes esa información. Ej: "No tengo registros de asistencia para 8A el 15 de julio." o "No puedo acceder a detalles de configuración específicos."
        2.  No inventes respuestas. No hagas suposiciones.
        3.  Sé breve y directo.

        Data Context:
        ${dataContext}

        User Question: ${currentMessage}
        AsiBot:
      `;

      const response: GenerateContentResponse = await ai.current.models.generateContent({
        model: 'gemini-2.5-flash-preview-04-17', // Recommended model
        contents: prompt,
        config: { thinkingConfig: { thinkingBudget: 0 } } 
      });

      const botResponseText = response.text || "No pude procesar tu solicitud en este momento.";
      setChatMessages(prev => [...prev, { id: Date.now().toString() + 'b', sender: 'asibot', text: botResponseText.trim() }]);

    } catch (error) {
      console.error('Error fetching response from Gemini API:', error);
      setChatMessages(prev => [...prev, { id: Date.now().toString() + 'e', sender: 'asibot', text: "Lo siento, ocurrió un error al intentar responder." }]);
    } finally {
      setIsLoading(false);
    }
  }, [userInput, isLoading, periods, activePeriodId, attendanceRecords, students, grades]);

  const handleSuggestedQuestionClick = (question: string) => {
    setUserInput(question); // Set input to display the question
    handleSendMessage(question); // Send it immediately
  };


  if (!isOpen) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title="💬 Consultar a AsiBot">
      <div className="flex flex-col h-[60vh] sm:h-[70vh]">
        <div ref={chatBodyRef} className="flex-grow overflow-y-auto mb-4 p-3 bg-gray-50 rounded border border-gray-200 space-y-3">
          {chatMessages.map(msg => (
            <div key={msg.id} className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                className={`max-w-[85%] p-2.5 rounded-lg shadow-sm text-sm whitespace-pre-wrap ${
                  msg.sender === 'user'
                    ? `bg-${INSTITUTIONAL_COLORS.BLUE} text-white`
                    : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                {msg.text}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
                <div className="max-w-[80%] p-2.5 rounded-lg shadow-sm text-sm bg-gray-200 text-gray-600 animate-pulse">
                    AsiBot está pensando...
                </div>
            </div>
          )}
        </div>

        {/* Suggested Questions */}
        {!isLoading && chatMessages.length > 0 && (
            <div className="mb-3 border-t pt-3">
                <p className="text-xs text-gray-500 mb-1.5 text-center">Sugerencias:</p>
                <div className="flex flex-wrap gap-1.5 justify-center">
                    {suggestedQuestions.map((q, index) => (
                        <Button
                            key={index}
                            variant="ghost"
                            size="sm"
                            className="!text-xs !px-2 !py-1 border-sky-500 text-sky-600 hover:bg-sky-100"
                            onClick={() => handleSuggestedQuestionClick(q)}
                        >
                            {q}
                        </Button>
                    ))}
                </div>
            </div>
        )}

        <div className="flex items-center border-t pt-3">
          <input
            type="text"
            value={userInput}
            onChange={(e) => setUserInput(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && !isLoading && handleSendMessage()}
            placeholder="Escribe tu pregunta aquí..."
            className="flex-grow px-3 py-2 border border-gray-300 rounded-l-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
            disabled={isLoading}
            aria-label="Entrada de chat para AsiBot"
          />
          <Button
            onClick={() => handleSendMessage()}
            disabled={isLoading || !userInput.trim()}
            className="rounded-l-none"
            aria-label="Enviar mensaje a AsiBot"
          >
            Enviar
          </Button>
        </div>
      </div>
    </Modal>
  );
};

export default AsiBot;
