import React, { useState, useMemo, useCallback } from 'react';
import { Grade, Student, Period, AttendanceRecord, AttendanceStatus, ScreenView } from '../types';
import Button from './Button';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS, APP_TITLE, FOOTER_TEXT } from '../constants';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import * as XLSX from 'xlsx';

interface ComputerUsageByGradeReportScreenProps {
  grades: Grade[];
  students: Student[];
  periods: Period[];
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const STATUS_LABELS: Record<AttendanceStatus, string> = {
  [AttendanceStatus.PRESENT]: 'P', // Presente
  [AttendanceStatus.ABSENT_UNEXCUSED]: 'A(SE)', // Ausente (S.E.)
  [AttendanceStatus.ABSENT_EXCUSED]: 'A(J)', // Ausente (Just.)
  [AttendanceStatus.SICK_BAY]: 'Enf.', // Enfermería
};

const formatDisplayDate = (dateString: string): string => {
  if (!dateString) return "N/A";
  try {
    const dateObj = new Date(dateString + 'T00:00:00'); // Treat as local
    return dateObj.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' });
  } catch (e) {
    return dateString; // Fallback
  }
};

const ComputerUsageByGradeReportScreen: React.FC<ComputerUsageByGradeReportScreenProps> = ({
  grades, students, periods, attendanceRecords, setCurrentView, goBack, canGoBack
}) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>(grades.length > 0 ? grades[0].id : '');
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>(periods.length > 0 ? periods[0].id : '');
  const [startDate, setStartDate] = useState<string>('');
  const [endDate, setEndDate] = useState<string>('');
  const [showAllDates, setShowAllDates] = useState<boolean>(true);

  const reportData = useMemo(() => {
    if (!selectedGradeId || !selectedPeriodId) return [];

    const studentsInGrade = students.filter(s => s.gradeId === selectedGradeId);
    if (studentsInGrade.length === 0) return [];

    const recordsForPeriod = attendanceRecords.filter(r => 
        r.gradeId === selectedGradeId && 
        r.periodId === selectedPeriodId &&
        (showAllDates || (r.date >= startDate && r.date <= endDate))
    );
    
    const groupedByStudent: { 
        studentName: string; 
        assignedComputer: number; 
        records: { date: string; usedComputer: number; status: AttendanceStatus }[] 
    }[] = [];

    studentsInGrade.forEach(student => {
      const studentRecords = recordsForPeriod
        .filter(r => r.studentId === student.id)
        .map(r => ({
          date: r.date,
          usedComputer: r.usedComputer, // This will be 0 if absent
          status: r.status
        }))
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

      if (studentRecords.length > 0) {
        groupedByStudent.push({
          studentName: student.name,
          assignedComputer: student.assignedComputer,
          records: studentRecords
        });
      }
    });
    return groupedByStudent.sort((a,b) => a.studentName.localeCompare(b.studentName));
  }, [selectedGradeId, selectedPeriodId, startDate, endDate, showAllDates, students, attendanceRecords]);

  const handleExport = useCallback((format: 'PDF' | 'Excel') => {
    if (reportData.length === 0) {
      alert("No hay datos para exportar.");
      return;
    }

    const gradeName = grades.find(g => g.id === selectedGradeId)?.name || 'N/A';
    const periodName = periods.find(p => p.id === selectedPeriodId)?.name || 'N/A';
    let dateRangeStr = 'Todas las Fechas';
    if (!showAllDates && startDate && endDate) {
        dateRangeStr = `${formatDisplayDate(startDate)} - ${formatDisplayDate(endDate)}`;
    }
    
    const filename = `Reporte_Computadores_Grado_${gradeName}_${periodName}_${dateRangeStr.replace(/[\/\s]/g, '-')}`;

    if (format === 'Excel') {
        const worksheetData: any[] = [];
        reportData.forEach(studentEntry => {
            studentEntry.records.forEach(record => {
                worksheetData.push({
                    'Estudiante': studentEntry.studentName,
                    'PC Asignado': studentEntry.assignedComputer,
                    'Fecha': formatDisplayDate(record.date),
                    'PC Usado': record.usedComputer === 0 ? 'N/A (Ausente)' : record.usedComputer,
                    'Estado Asistencia': STATUS_LABELS[record.status]
                });
            });
        });
        if(worksheetData.length === 0){ alert("No hay registros detallados para exportar."); return; }
        const worksheet = XLSX.utils.json_to_sheet(worksheetData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Reporte PCs Grado");
        XLSX.writeFile(workbook, `${filename}.xlsx`);

    } else if (format === 'PDF') {
        const doc = new jsPDF('l', 'mm', 'a4'); // Landscape
        
        doc.setFillColor(INSTITUTIONAL_COLORS.BLUE.includes('institucional') ? '#0A4F8A' : INSTITUTIONAL_COLORS.BLUE);
        doc.rect(0, 0, doc.internal.pageSize.getWidth(), 15, 'F');
        doc.setFontSize(16);
        doc.setTextColor(INSTITUTIONAL_COLORS.WHITE.includes('institucional') ? '#FFFFFF' : INSTITUTIONAL_COLORS.WHITE);
        doc.text(APP_TITLE, doc.internal.pageSize.getWidth() / 2, 10, { align: 'center' });
        
        doc.setFontSize(12);
        doc.setTextColor(0,0,0);
        doc.text(`Reporte de Uso de Computadores por Grado`, 14, 25);
        doc.setFontSize(10);
        doc.text(`Grado: ${gradeName}`, 14, 31);
        doc.text(`Periodo: ${periodName}`, 14, 36);
        doc.text(`Rango de Fechas: ${dateRangeStr}`, 14, 41);

        const tableRows: any[] = [];
        reportData.forEach(studentEntry => {
          studentEntry.records.forEach((record, index) => {
            tableRows.push({
              studentName: studentEntry.studentName,
              assignedComputer: studentEntry.assignedComputer,
              date: formatDisplayDate(record.date),
              usedComputerDisplay: record.usedComputer === 0 ? 'N/A (Ausente)' : record.usedComputer.toString(),
              usedComputerRaw: record.usedComputer, // Keep raw value for logic
              status: STATUS_LABELS[record.status],
              isFirstRecordForStudent: index === 0,
              totalRecordsForStudent: studentEntry.records.length
            });
          });
        });
        
        (doc as any).autoTable({
            startY: 48,
            head: [['Estudiante', 'PC Asignado', 'Fecha', 'PC Usado', 'Estado Asistencia']],
            body: tableRows.map(row => [
                row.isFirstRecordForStudent ? row.studentName : '',
                row.isFirstRecordForStudent ? row.assignedComputer : '',
                row.date,
                row.usedComputerDisplay,
                row.status
            ]),
            theme: 'grid',
            headStyles: { fillColor: [10, 79, 138], textColor: 255, fontSize: 9 },
            bodyStyles: { fontSize: 8, cellPadding: 1.5 },
            columnStyles: {
                0: { cellWidth: 'auto' }, 1: { cellWidth: 25, halign: 'center' }, 
                2: { cellWidth: 25 }, 3: { cellWidth: 30, halign: 'center' }, 4: { cellWidth: 30 } // Adjusted PC Usado width
            },
            didParseCell: function (data: any) {
                const row = tableRows[data.row.index]; // Access the pre-processed row data
                if (row && typeof row === 'object') {
                    if (data.column.index === 0 && row.isFirstRecordForStudent) {
                        data.cell.styles.rowSpan = row.totalRecordsForStudent;
                    }
                    if (data.column.index === 1 && row.isFirstRecordForStudent) {
                        data.cell.styles.rowSpan = row.totalRecordsForStudent;
                    }
                    if (data.column.index === 3) { // "PC Usado" column
                        // Highlight if PC used is different from assigned AND not N/A
                        if (row.usedComputerRaw !== 0 && row.usedComputerRaw !== row.assignedComputer) {
                            data.cell.styles.textColor = [255, 0, 0]; // Red text
                            data.cell.styles.fontStyle = 'bold';
                        }
                    }
                }
            },
            didDrawPage: (dataHook: any) => { 
              const pageCount = doc.getNumberOfPages();
              doc.setFontSize(8);
              doc.setTextColor('#888888');
              doc.text(FOOTER_TEXT, dataHook.settings.margin.left, doc.internal.pageSize.getHeight() - 10);
              doc.text(`Generado: ${new Date().toLocaleString('es-ES')}`, dataHook.settings.margin.left, doc.internal.pageSize.getHeight() - 6);
              doc.text(`Página ${dataHook.pageNumber} de ${pageCount}`, doc.internal.pageSize.getWidth() - dataHook.settings.margin.right - 10, doc.internal.pageSize.getHeight() - 10, {align:'left'});
            }
        });
        doc.save(`${filename}.pdf`);
    }
  }, [reportData, selectedGradeId, selectedPeriodId, startDate, endDate, showAllDates, grades, periods]);

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-6`}>Reporte de Computadores Usados – Por Grado</h2>

      <div className="bg-white p-4 rounded-lg shadow mb-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="gradeSelect" className="block text-sm font-medium text-gray-700 mb-1">Grado:</label>
            <select id="gradeSelect" value={selectedGradeId} onChange={e => setSelectedGradeId(e.target.value)} className="form-select w-full">
              {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          </div>
          <div>
            <label htmlFor="periodSelect" className="block text-sm font-medium text-gray-700 mb-1">Periodo:</label>
            <select id="periodSelect" value={selectedPeriodId} onChange={e => setSelectedPeriodId(e.target.value)} className="form-select w-full">
              {periods.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
           <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Filtrar Fechas:</label>
            <div className="flex items-center space-x-2">
                <input type="checkbox" id="showAllDates" checked={showAllDates} onChange={e => setShowAllDates(e.target.checked)} className="form-checkbox h-5 w-5 text-institucional-blue rounded"/>
                <label htmlFor="showAllDates" className="text-sm text-gray-700">Mostrar Todas las Fechas del Periodo</label>
            </div>
          </div>
        </div>
        {!showAllDates && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border-t pt-4">
            <div>
              <label htmlFor="startDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Inicio:</label>
              <input type="date" id="startDate" value={startDate} onChange={e => setStartDate(e.target.value)} className="form-select w-full" />
            </div>
            <div>
              <label htmlFor="endDate" className="block text-sm font-medium text-gray-700 mb-1">Fecha de Fin:</label>
              <input type="date" id="endDate" value={endDate} onChange={e => setEndDate(e.target.value)} className="form-select w-full" />
            </div>
            {startDate && endDate && new Date(startDate) > new Date(endDate) && <p className="text-red-500 text-sm md:col-span-2">La fecha de inicio no puede ser posterior a la fecha de fin.</p>}
          </div>
        )}
         <div className="flex justify-end space-x-2">
            <Button onClick={() => handleExport('Excel')} variant="secondary" disabled={reportData.length === 0}>Exportar a Excel</Button>
            <Button onClick={() => handleExport('PDF')} variant="primary" disabled={reportData.length === 0}>Exportar a PDF</Button>
        </div>
      </div>

      {reportData.length > 0 ? (
        <div className="bg-white p-4 rounded-lg shadow overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Estudiante</th>
                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">PC Asignado</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Fecha</th>
                <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">PC Usado</th>
                <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {reportData.map((studentEntry, studentIdx) => (
                <React.Fragment key={studentEntry.studentName + studentIdx}>
                  {studentEntry.records.map((record, recordIdx) => (
                    <tr key={`${studentEntry.studentName}-${record.date}-${recordIdx}`} className={recordIdx % 2 === 0 ? '' : 'bg-gray-50/50'}>
                      {recordIdx === 0 ? (
                        <td rowSpan={studentEntry.records.length} className="px-4 py-2 align-top whitespace-nowrap border-r font-medium text-gray-900">{studentEntry.studentName}</td>
                      ) : null}
                      {recordIdx === 0 ? (
                         <td rowSpan={studentEntry.records.length} className="px-4 py-2 align-top whitespace-nowrap border-r text-center">{studentEntry.assignedComputer}</td>
                      ) : null}
                      <td className="px-4 py-2 whitespace-nowrap">{formatDisplayDate(record.date)}</td>
                      <td className={`px-4 py-2 whitespace-nowrap text-center ${record.usedComputer !== 0 && record.usedComputer !== studentEntry.assignedComputer ? 'text-red-600 font-bold' : ''}`}>
                        {record.usedComputer === 0 ? 'N/A (Ausente)' : record.usedComputer}
                      </td>
                      <td className="px-4 py-2 whitespace-nowrap">{STATUS_LABELS[record.status]}</td>
                    </tr>
                  ))}
                </React.Fragment>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <p className="text-gray-600 text-center py-10">No hay datos para mostrar con los filtros seleccionados.</p>
      )}
    </div>
  );
};

export default ComputerUsageByGradeReportScreen;