
import React, { useState, useCallback } from 'react';
import * as XLSX from 'xlsx';
import { Grade, Student, ScreenView } from '../types';
import Button from './Button';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import UploadIcon from './icons/UploadIcon';
import { INSTITUTIONAL_COLORS } from '../constants';

interface BulkUploadScreenProps {
  grades: Grade[];
  students: Student[]; // Pass students for duplicate checking
  addGrade: (name: string) => string;
  addStudentsBatch: (studentsData: { name: string, assignedComputer: number }[], gradeId: string) => void;
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

interface ParsedStudentData {
    name: string;
    assignedComputer: number;
}

interface ParsedSheetData {
  sheetName: string; // Course name
  studentsData: ParsedStudentData[];
  isNewCourse: boolean;
  existingGradeId?: string;
  newStudentsToImport: ParsedStudentData[]; // Students from Excel that will actually be added
  conflicts: string[]; // Messages for conflicts like duplicate PC numbers
}

const BulkUploadScreen: React.FC<BulkUploadScreenProps> = ({
  grades,
  students,
  addGrade,
  addStudentsBatch,
  setCurrentView,
  goBack,
  canGoBack
}) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [parsedData, setParsedData] = useState<ParsedSheetData[] | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [feedback, setFeedback] = useState<{ type: 'success' | 'error' | 'info'; message: string } | null>(null);
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const validExtensions = ['.xlsx', '.xls'];
      const fileExtension = file.name.substring(file.name.lastIndexOf('.')).toLowerCase();
      if (!validExtensions.includes(fileExtension)) {
        setFeedback({ type: 'error', message: 'Archivo no válido. Por favor, suba un archivo .xlsx o .xls.' });
        setSelectedFile(null);
        setParsedData(null);
        if (fileInputRef.current) fileInputRef.current.value = '';
        return;
      }
      setSelectedFile(file);
      setParsedData(null); 
      setFeedback(null);
    }
  };

  const handleParseFile = useCallback(async () => {
    if (!selectedFile) {
      setFeedback({ type: 'error', message: 'Por favor, seleccione un archivo primero.' });
      return;
    }
    setIsLoading(true);
    setFeedback(null);

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const data = e.target?.result;
        if (data) {
          const workbook = XLSX.read(data, { type: 'binary' });
          const sheetDataPreview: ParsedSheetData[] = [];
          let overallParsingError = false;

          workbook.SheetNames.forEach(sheetName => {
            const worksheet = workbook.Sheets[sheetName];
            const sheetStudentData: ParsedStudentData[] = [];
            const conflicts: string[] = [];

            const rows = XLSX.utils.sheet_to_json<any>(worksheet, { header: 1, defval: null });

            for (let i = 0; i < rows.length; i++) { // Start from first row, assuming no header or header is handled by filtering
              const row = rows[i];
              const studentName = row[0] ? String(row[0]).trim() : null;
              const computerNumRaw = row[1]; // Computer number from Col B
              
              if (!studentName && computerNumRaw === null && rows.slice(i).every(r => r[0] === null && r[1] === null) ) {
                // If current and all subsequent rows are entirely empty for name and PC, stop processing this sheet.
                break; 
              }

              if (!studentName) {
                 if(computerNumRaw !== null) conflicts.push(`Fila ${i + 1}: Nombre de estudiante vacío pero con número de PC.`);
                 continue; // Skip if name is empty
              }

              const assignedComputer = parseInt(String(computerNumRaw), 10);

              if (isNaN(assignedComputer) || assignedComputer < 1 || assignedComputer > 35) {
                conflicts.push(`Estudiante "${studentName}": Número de PC "${computerNumRaw}" inválido (debe ser 1-35).`);
                overallParsingError = true;
                continue;
              }
              
              // Check for duplicate PC number within the current sheet's parsed students
              if (sheetStudentData.some(s => s.assignedComputer === assignedComputer)) {
                conflicts.push(`Estudiante "${studentName}": PC ${assignedComputer} duplicado en esta hoja.`);
                overallParsingError = true;
                continue;
              }
              sheetStudentData.push({ name: studentName, assignedComputer });
            }
            
            if (sheetStudentData.length === 0 && conflicts.length === 0) {
                console.warn(`Hoja "${sheetName}" no contiene estudiantes o datos válidos. Se omitirá.`);
                return; 
            }
            
            const existingGrade = grades.find(g => g.name.toLowerCase() === sheetName.trim().toLowerCase());
            const studentsInExistingGrade = existingGrade ? students.filter(s => s.gradeId === existingGrade.id) : [];
            
            const newStudentsToImport: ParsedStudentData[] = [];
            sheetStudentData.forEach(excelStudent => {
                // Check if PC is already assigned in the target grade (new or existing) by another student
                const pcConflictInGrade = studentsInExistingGrade.find(s => s.assignedComputer === excelStudent.assignedComputer);
                if (pcConflictInGrade) {
                    conflicts.push(`Estudiante "${excelStudent.name}" (PC ${excelStudent.assignedComputer}): PC ya asignado a "${pcConflictInGrade.name}" en el curso existente "${sheetName}".`);
                    overallParsingError = true;
                    return; // Skip this student due to PC conflict
                }
                // Check if student name already exists in the target grade
                const nameConflictInGrade = studentsInExistingGrade.find(s => s.name.toLowerCase() === excelStudent.name.toLowerCase());
                if (nameConflictInGrade) {
                    // Student name exists. If their PC is different, it's a conflict (handled above).
                    // If PC is same, it's a duplicate entry that can be ignored.
                    // If PC is different, original logic: we don't update existing students, only add new.
                    // For now, if name exists, we assume it's an attempt to re-add, skip.
                    // This part can be refined if updating existing students' PCs via Excel is desired.
                    return; // Skip if student name already exists in the grade.
                }
                newStudentsToImport.push(excelStudent);
            });


            sheetDataPreview.push({
              sheetName: sheetName.trim(),
              studentsData: sheetStudentData, // All valid students from sheet
              isNewCourse: !existingGrade,
              existingGradeId: existingGrade?.id,
              newStudentsToImport: newStudentsToImport, // Students that will actually be added
              conflicts
            });
          });
          
          if (overallParsingError) {
             setFeedback({ type: 'error', message: 'Se encontraron errores en el archivo. Revise los conflictos en la vista previa y corrija el archivo.' });
          } else if (sheetDataPreview.length === 0) {
            setFeedback({ type: 'info', message: 'El archivo no contiene hojas válidas con estudiantes (Col A) y PCs asignados (Col B).' });
          }
          setParsedData(sheetDataPreview);
        }
        setIsLoading(false);
      };
      reader.onerror = () => {
        setFeedback({ type: 'error', message: 'Error al leer el archivo.' });
        setIsLoading(false);
      };
      reader.readAsBinaryString(selectedFile);
    } catch (error) {
      console.error("Error parsing Excel file:", error);
      setFeedback({ type: 'error', message: 'Ocurrió un error al procesar el archivo Excel.' });
      setIsLoading(false);
    }
  }, [selectedFile, grades, students]);

  const handleConfirmImport = useCallback(async () => {
    if (!parsedData || parsedData.some(sheet => sheet.conflicts.length > 0)) {
      setFeedback({ type: 'error', message: 'Corrija los errores en el archivo o en la previsualización antes de importar.' });
      return;
    }
    setIsLoading(true);
    setFeedback(null);
    let coursesCreatedCount = 0;
    let studentsAddedCount = 0;
    let importSummaryMessages: string[] = [];

    try {
      for (const sheet of parsedData) {
        if (sheet.newStudentsToImport.length === 0 && !sheet.isNewCourse) {
            importSummaryMessages.push(`Hoja "${sheet.sheetName}": No hay estudiantes nuevos para agregar.`);
            continue;
        }
        if (sheet.newStudentsToImport.length === 0 && sheet.isNewCourse) {
             importSummaryMessages.push(`Hoja "${sheet.sheetName}" (Nuevo Curso): No hay estudiantes para agregar.`);
            continue;
        }


        let gradeIdToUse = sheet.existingGradeId;

        if (sheet.isNewCourse) {
          const checkExisting = grades.find(g => g.name.toLowerCase() === sheet.sheetName.toLowerCase());
          if (checkExisting) {
            gradeIdToUse = checkExisting.id;
            importSummaryMessages.push(`Hoja "${sheet.sheetName}": Usando curso existente encontrado con el mismo nombre.`);
          } else {
            gradeIdToUse = addGrade(sheet.sheetName); 
            if (gradeIdToUse) {
                coursesCreatedCount++;
                importSummaryMessages.push(`Hoja "${sheet.sheetName}": Nuevo curso creado.`);
            } else {
                 importSummaryMessages.push(`Hoja "${sheet.sheetName}": ERROR al crear nuevo curso.`);
                 console.error(`Error: No se pudo crear o obtener el ID para el nuevo curso "${sheet.sheetName}"`);
                 continue; // Skip this sheet if grade creation failed
            }
          }
        }
        
        if (gradeIdToUse) {
          if (sheet.newStudentsToImport.length > 0) {
            addStudentsBatch(sheet.newStudentsToImport, gradeIdToUse);
            studentsAddedCount += sheet.newStudentsToImport.length;
            importSummaryMessages.push(`Hoja "${sheet.sheetName}": ${sheet.newStudentsToImport.length} estudiantes agregados.`);
          }
        }
      }
      setFeedback({ type: 'success', message: `¡Importación completada! Cursos creados: ${coursesCreatedCount}. Estudiantes agregados: ${studentsAddedCount}. Detalles:\n${importSummaryMessages.join('\n')}` });
      setParsedData(null);
      setSelectedFile(null);
      if (fileInputRef.current) fileInputRef.current.value = '';

    } catch (error) {
      console.error("Error during import confirmation:", error);
      setFeedback({ type: 'error', message: 'Ocurrió un error durante la importación.' });
    } finally {
      setIsLoading(false);
    }
  }, [parsedData, addGrade, addStudentsBatch, grades]);

  const canConfirmImport = parsedData && parsedData.length > 0 && !parsedData.some(sheet => sheet.conflicts.length > 0) && parsedData.some(sheet => sheet.newStudentsToImport.length > 0 || (sheet.isNewCourse && sheet.studentsData.length > 0));


  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-6`}>Gestionar Curso – Carga Masiva desde Excel</h2>

      <div className="bg-white p-6 rounded-lg shadow-md space-y-6">
        <div>
          <label htmlFor="fileUpload" className="block text-sm font-medium text-gray-700 mb-1">
            Seleccionar archivo Excel (.xlsx, .xls)
          </label>
          <div className="flex items-center space-x-3">
            <input
              ref={fileInputRef}
              type="file"
              id="fileUpload"
              accept=".xlsx, .xls"
              onChange={handleFileChange}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-institucional-blue file:text-institucional-white hover:file:bg-sky-800 cursor-pointer"
            />
            <Button
              onClick={handleParseFile}
              disabled={!selectedFile || isLoading}
              leftIcon={<UploadIcon className="w-5 h-5" />}
            >
              {isLoading ? 'Procesando...' : 'Cargar y Previsualizar'}
            </Button>
          </div>
          <p className="text-xs text-gray-500 mt-2">
            Cada hoja del libro representa un curso (ej: "6A"). Columna A: Nombre Estudiante, Columna B: Número PC (1-35).
          </p>
        </div>

        {feedback && (
          <div className={`p-3 rounded-md text-sm whitespace-pre-wrap ${
            feedback.type === 'success' ? 'bg-green-100 text-green-700' :
            feedback.type === 'error' ? 'bg-red-100 text-red-700' :
            'bg-blue-100 text-blue-700'
          }`}>
            {feedback.message}
          </div>
        )}

        {parsedData && parsedData.length > 0 && (
          <div className="border-t pt-4">
            <h3 className="text-lg font-semibold text-gray-700 mb-3">Vista Previa de Importación:</h3>
            <div className="max-h-[50vh] overflow-y-auto space-y-3 pr-2">
              {parsedData.map((sheet, index) => (
                <div key={index} className={`p-3 border rounded-md ${sheet.conflicts.length > 0 ? 'border-red-300 bg-red-50' : 'bg-gray-50'}`}>
                  <p className="font-medium text-gray-800">
                    Hoja: <span className="font-bold">{sheet.sheetName}</span> 
                    {sheet.isNewCourse 
                        ? <span className="ml-2 text-xs bg-green-200 text-green-800 px-2 py-0.5 rounded-full">Nuevo Curso</span>
                        : <span className="ml-2 text-xs bg-blue-200 text-blue-800 px-2 py-0.5 rounded-full">Curso Existente</span>
                    }
                  </p>
                  <p className="text-sm text-gray-600">
                    Estudiantes en archivo: {sheet.studentsData.length}.
                    Se importarán: {sheet.newStudentsToImport.length} estudiantes.
                  </p>
                  {sheet.conflicts.length > 0 && (
                    <div className="mt-2 text-xs text-red-600">
                        <p className="font-semibold">Conflictos:</p>
                        <ul className="list-disc list-inside pl-4">
                            {sheet.conflicts.map((conflict, cIdx) => <li key={cIdx}>{conflict}</li>)}
                        </ul>
                    </div>
                  )}
                  {sheet.studentsData.length > 0 && (
                    <details className="text-xs mt-1">
                        <summary className="cursor-pointer text-gray-500 hover:text-gray-700">Ver lista de estudiantes del archivo ({sheet.studentsData.length})</summary>
                        <ul className="list-disc list-inside pl-4 max-h-32 overflow-y-auto bg-white p-2 rounded border mt-1">
                            {sheet.studentsData.map((sData, sIdx) => <li key={sIdx}>{sData.name} (PC: {sData.assignedComputer})</li>)}
                        </ul>
                    </details>
                  )}
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-end space-x-3">
              <Button variant="ghost" onClick={() => { setParsedData(null); setSelectedFile(null); setFeedback(null); if(fileInputRef.current) fileInputRef.current.value = '';}} disabled={isLoading}>
                Cancelar
              </Button>
              <Button onClick={handleConfirmImport} disabled={isLoading || !canConfirmImport}>
                {isLoading ? 'Importando...' : 'Confirmar Importación'}
              </Button>
            </div>
          </div>
        )}
         {parsedData === null && selectedFile && !isLoading && (
            <p className="text-gray-500 text-center py-4">Haga clic en "Cargar y Previsualizar" para ver los datos del archivo.</p>
        )}
      </div>
    </div>
  );
};

export default BulkUploadScreen;