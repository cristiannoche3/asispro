
import React from 'react';

const ChatBubbleIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3.686-3.686c-1.03.22-2.074.333-3.153.333H5.75c-1.136 0-2.097-.847-2.193-1.98A11.984 11.984 0 012.25 12.797V8.511c0-1.136.847-2.097 1.98-2.193.34-.027.68-.052 1.02-.072V3.75L9 7.436c1.03-.22 2.074-.333 3.153-.333h5.25c.969 0 1.813.527 2.25 1.318z" />
    <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 10.875h7.5M8.25 13.125h4.5" />
  </svg>
);

export default ChatBubbleIcon;
