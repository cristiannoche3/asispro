
import React from 'react';

const PresentationChartBarIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3.75M3.75 14.25m-1.5 0h15m-15 0v2.25A2.25 2.25 0 005.25 18.75h13.5A2.25 2.25 0 0021 16.5v-2.25m-15 0h15M6.75 12.75h.008v.008H6.75v-.008zm3.75 0h.008v.008h-.008v-.008zm3.75 0h.008v.008h-.008v-.008z" />
  </svg>
);

export default PresentationChartBarIcon;