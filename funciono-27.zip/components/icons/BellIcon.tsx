
import React from 'react';

const BellIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0M3.124 7.5A8.969 8.969 0 015.25 3h13.5c1.37 0 2.634.429 3.626 1.153a8.97 8.97 0 011.823 4.345M3.124 7.5c-.622.397-1.184.883-1.655 1.44A8.97 8.97 0 001.5 12v.75c0 1.504.307 2.918.851 4.219M20.876 7.5c.622.397 1.184.883 1.655 1.44A8.97 8.97 0 0122.5 12v.75c0 1.504-.307 2.918-.851 4.219" />
  </svg>
);

export default BellIcon;
