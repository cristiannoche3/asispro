
import React from 'react';

const ChartIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" {...props}>
    <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 3v11.25A2.25 2.25 0 006 16.5h12A2.25 2.25 0 0020.25 14.25V3M3.75 14.25v-1.875c0-.621.504-1.125 1.125-1.125h2.25c.621 0 1.125.504 1.125 1.125v1.875M3.75 7.5h2.25M3.75 12h5.25m-5.25 3h6.75m2.25-7.5H18a.75.75 0 00.75-.75V3.75m0 3.75c0 .621-.504 1.125-1.125 1.125H15M12 12.75H15m3 0h.008v.015H18m0 0h.008v.015H18m0 0h.008v.015H18m0 0h.008v.015H18z" />
  </svg>
);
export default ChartIcon;
    