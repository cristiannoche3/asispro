
import React from 'react';
import { ScreenView } from '../types';
import Button from './Button';
import BookIcon from './icons/BookIcon';
import UserPlusIcon from './icons/UserPlusIcon';
import ChecklistIcon from './icons/ChecklistIcon';
import ChartIcon from './icons/ChartIcon';
import CalendarIcon from './icons/CalendarIcon';
import ArchiveBoxIcon from './icons/ArchiveBoxIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon'; 
import PresentationChartBarIcon from './icons/PresentationChartBarIcon';
import DesktopComputerIcon from './icons/DesktopComputerIcon'; // For the hub
// import IdentificationIcon from './icons/IdentificationIcon'; // No longer needed here directly
import { INSTITUTIONAL_COLORS } from '../constants';

interface MainMenuProps {
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

interface MenuItem {
  label: string;
  icon: React.ReactElement<React.SVGProps<SVGSVGElement>>;
  view: ScreenView;
  color: 'primary' | 'secondary' | 'ghost';
}

const MainMenu: React.FC<MainMenuProps> = ({ setCurrentView, goBack, canGoBack }) => {
  const menuItems: MenuItem[] = [
    { label: 'Gestionar Grados', icon: <BookIcon className="w-10 h-10" />, view: ScreenView.MANAGE_GRADES, color: 'primary' },
    { label: 'Agregar Estudiantes', icon: <UserPlusIcon className="w-10 h-10" />, view: ScreenView.ADD_STUDENTS, color: 'secondary' },
    { label: 'Llamar Asistencia', icon: <ChecklistIcon className="w-10 h-10" />, view: ScreenView.TAKE_ATTENDANCE, color: 'primary' },
    { label: 'Ver Asistencias Guardadas', icon: <ArchiveBoxIcon className="w-10 h-10" />, view: ScreenView.VIEW_SAVED_ATTENDANCE, color: 'secondary' },
    { label: 'Reportes de Asistencia', icon: <ChartIcon className="w-10 h-10" />, view: ScreenView.ATTENDANCE_REPORTS, color: 'primary' },
    { label: 'Reportes de Computadores', icon: <DesktopComputerIcon className="w-10 h-10" />, view: ScreenView.COMPUTER_REPORTS_HUB, color: 'secondary' }, // New Hub
    { label: 'Reporte de Ausentismo', icon: <PresentationChartBarIcon className="w-10 h-10" />, view: ScreenView.ABSENTEEISM_REPORT, color: 'primary' },
    { label: 'Configurar Periodos', icon: <CalendarIcon className="w-10 h-10" />, view: ScreenView.CONFIGURE_PERIODS, color: 'secondary' },
  ];

  const handleMenuClick = (view: ScreenView) => {
    setCurrentView(view);
  }
  
  return (
    <div className="p-6 md:p-10 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="text-center mb-8">
        <h2 className={`text-xl font-semibold text-gray-700 mb-2`}>
          Menú Principal
        </h2>
        <p className="text-gray-500">
          Hoy es {new Date().toLocaleDateString('es-ES', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {menuItems.map((item) => (
          <Button
            key={item.label}
            variant={item.color}
            size="lg"
            className="flex flex-col items-center justify-center h-48 text-center !text-lg transform hover:scale-105 transition-transform duration-200 !font-medium"
            onClick={() => handleMenuClick(item.view)}
            aria-label={item.label}
          >
            {React.cloneElement(item.icon, { 
              className: `w-12 h-12 mb-3 ${
                item.color === 'primary' ? 'text-institucional-yellow' 
                : item.color === 'secondary' ? 'text-institucional-blue' 
                : 'text-gray-700'
              }` 
            })}
            {item.label}
          </Button>
        ))}
      </div>
      <p className="text-center text-gray-500 mt-12 text-sm">
        Seleccione una opción para comenzar.
      </p>
    </div>
  );
};

export default MainMenu;