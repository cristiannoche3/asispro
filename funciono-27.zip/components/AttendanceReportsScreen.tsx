
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Grade, Student, Period, AttendanceRecord, AttendanceStatus, ScreenView, ReportData } from '../types';
import Button from './Button';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, LabelList } from 'recharts';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS, APP_TITLE, FOOTER_TEXT } from '../constants';

// Make sure 'canvg' is in index.html importmap: "canvg": "https://esm.sh/canvg@^4.0.1"
const convertSvgToImage = async (svgElement: SVGElement): Promise<string> => {
  const { Canvg } = await import('canvg'); // Dynamically import Canvg
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (!ctx) throw new Error('Canvas context not found for SVG conversion.');

  const svgText = new XMLSerializer().serializeToString(svgElement);
  
  // Use SVG's own width/height attributes if available and valid, otherwise default.
  // Recharts SVGs usually have explicit width/height.
  const svgWidthAttr = svgElement.getAttribute('width');
  const svgHeightAttr = svgElement.getAttribute('height');

  const width = svgWidthAttr && !svgWidthAttr.includes('%') ? parseInt(svgWidthAttr, 10) : 600;
  const height = svgHeightAttr && !svgHeightAttr.includes('%') ? parseInt(svgHeightAttr, 10) : 300;
  
  canvas.width = width;
  canvas.height = height;

  const v = Canvg.fromString(ctx, svgText, {
    ignoreMouse: true,
    ignoreAnimation: true,
    ignoreDimensions: false, // Respect SVG dimensions
  });
  await v.render();
  return canvas.toDataURL('image/png');
};


const STATUS_COLORS: Record<AttendanceStatus, string> = {
  [AttendanceStatus.PRESENT]: '#10B981',
  [AttendanceStatus.ABSENT_UNEXCUSED]: '#EF4444',
  [AttendanceStatus.ABSENT_EXCUSED]: '#F59E0B',
  [AttendanceStatus.SICK_BAY]: '#3B82F6',
};

const STATUS_LABELS: Record<AttendanceStatus, string> = {
  [AttendanceStatus.PRESENT]: 'Presente',
  [AttendanceStatus.ABSENT_UNEXCUSED]: 'Ausente (S.E.)',
  [AttendanceStatus.ABSENT_EXCUSED]: 'Ausente (Just.)',
  [AttendanceStatus.SICK_BAY]: 'Enfermería',
};

const RADIAN = Math.PI / 180;

// Label renderer for Pie Chart in Group Report (external labels)
const renderOuterCustomizedPieLabel = (props: any) => {
  const { cx, cy, midAngle, outerRadius, fill, payload, percent, value, name } = props;
  if (!payload || percent === undefined || value === undefined || name === undefined) return null;
  
  const sin = Math.sin(-RADIAN * midAngle);
  const cos = Math.cos(-RADIAN * midAngle);
  const sx = cx + (outerRadius + 0) * cos; 
  const sy = cy + (outerRadius + 0) * sin;
  const mx = cx + (outerRadius + 15) * cos; 
  const my = cy + (outerRadius + 15) * sin;
  const ex = mx + (cos >= 0 ? 1 : -1) * 12; 
  const ey = my;
  const textAnchor = cos >= 0 ? 'start' : 'end';
  
  const percentageValue = (percent * 100).toFixed(1);
  if (parseFloat(percentageValue) < 1) return null;

  return (
    <g>
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 6} y={ey} textAnchor={textAnchor} fill="#333" dy={4} fontSize="11px" fontWeight="normal">
        {`${name}: ${value} (${percentageValue}%)`}
      </text>
    </g>
  );
};

// PDF Header
const drawHeader = (doc: jsPDF, title: string) => {
  const pageWidth = doc.internal.pageSize.getWidth();
  doc.setFillColor(INSTITUTIONAL_COLORS.BLUE.includes('institucional') ? '#0A4F8A' : INSTITUTIONAL_COLORS.BLUE); // Use hex for PDF
  doc.rect(0, 0, pageWidth, 15, 'F');
  doc.setFontSize(18);
  doc.setTextColor(INSTITUTIONAL_COLORS.WHITE.includes('institucional') ? '#FFFFFF' : INSTITUTIONAL_COLORS.WHITE);
  doc.text(APP_TITLE, pageWidth / 2, 10, { align: 'center' });
  doc.setFontSize(14);
  doc.setTextColor('#000000'); // Reset text color
  doc.text(title, pageWidth / 2, 25, { align: 'center' });
};

// PDF Footer
const drawFooter = (doc: jsPDF) => {
  const pageCount = doc.getNumberOfPages();
  const pageWidth = doc.internal.pageSize.getWidth();
  const pageHeight = doc.internal.pageSize.getHeight();
  doc.setFontSize(8);
  doc.setTextColor('#888888');
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i);
    doc.text(FOOTER_TEXT, pageWidth / 2, pageHeight - 15, { align: 'center' });
    doc.text(`Generado: ${new Date().toLocaleString('es-ES')}`, 14, pageHeight - 10);
    doc.text(`Página ${i} de ${pageCount}`, pageWidth - 14 - doc.getStringUnitWidth(`Página ${i} de ${pageCount}`) * doc.getFontSize() / doc.internal.scaleFactor, pageHeight - 10, {align: 'left'});
  }
};

interface AttendanceReportsScreenProps {
  grades: Grade[];
  students: Student[];
  periods: Period[];
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const AttendanceReportsScreen: React.FC<AttendanceReportsScreenProps> = ({
  grades, students, periods, attendanceRecords, setCurrentView, goBack, canGoBack
}) => {
  const [reportType, setReportType] = useState<'individual' | 'group'>('individual');
  const [selectedGradeId, setSelectedGradeId] = useState<string>(grades.length > 0 ? grades[0].id : '');
  const [selectedStudentId, setSelectedStudentId] = useState<string>('');
  const [selectedPeriodId, setSelectedPeriodId] = useState<string>(periods.length > 0 ? periods[0].id : '');
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false); // For off-screen chart rendering

  const studentsInSelectedGrade = useMemo(() => students.filter(s => s.gradeId === selectedGradeId), [students, selectedGradeId]);
  
  useEffect(() => {
    if (reportType === 'individual' && studentsInSelectedGrade.length > 0) {
      if (!selectedStudentId || !studentsInSelectedGrade.find(s => s.id === selectedStudentId)) {
         setSelectedStudentId(studentsInSelectedGrade[0].id);
      }
    } else if (reportType === 'individual' && studentsInSelectedGrade.length === 0) {
        setSelectedStudentId('');
    }
  }, [selectedGradeId, studentsInSelectedGrade, reportType, selectedStudentId]);

  const individualReportData = useMemo(() => {
    if (reportType !== 'individual' || !selectedStudentId || !selectedPeriodId) return null;
    
    const studentDetails = students.find(s => s.id === selectedStudentId);
    if (!studentDetails) return null;

    const studentRecordsForPeriod = attendanceRecords.filter(
      r => r.studentId === selectedStudentId && r.periodId === selectedPeriodId
    );

    const summary: Record<AttendanceStatus, number> = { PRESENT: 0, ABSENT_UNEXCUSED: 0, ABSENT_EXCUSED: 0, SICK_BAY: 0 };
    let pcChanges = 0;
    let lastUnexcusedAbsenceDate: string | null = null;

    studentRecordsForPeriod.forEach(r => {
        summary[r.status]++;
        if (r.usedComputer && studentDetails.assignedComputer && r.usedComputer !== studentDetails.assignedComputer) {
            pcChanges++;
        }
        if (r.status === AttendanceStatus.ABSENT_UNEXCUSED) {
            if (!lastUnexcusedAbsenceDate || new Date(r.date) > new Date(lastUnexcusedAbsenceDate)) {
                lastUnexcusedAbsenceDate = r.date;
            }
        }
    });
    
    const totalRecords = studentRecordsForPeriod.length; 
    const attendancePercentage = totalRecords > 0 ? (summary.PRESENT / totalRecords * 100).toFixed(1) : '0.0';

    const chartData: ReportData[] = (Object.keys(STATUS_LABELS) as AttendanceStatus[]).map(status => ({
      name: STATUS_LABELS[status],
      value: summary[status], 
      fill: STATUS_COLORS[status]
    })).filter(d => d.value > 0); // Filter for Pie chart data to avoid 0 value slices issues

    const dailyRecordsTable = studentRecordsForPeriod.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .map(r => {
        const usedPc = r.usedComputer ?? studentDetails.assignedComputer;
        const pcObservation = r.usedComputer && r.usedComputer !== studentDetails.assignedComputer 
            ? `Se cambió a PC #${r.usedComputer}` 
            : '-';
        return {
          date: new Date(r.date + 'T00:00:00').toLocaleDateString('es-ES', { year: 'numeric', month: '2-digit', day: '2-digit' }),
          classHoursCovered: r.classHours.join(', '), 
          statusLabel: STATUS_LABELS[r.status],
          statusColor: STATUS_COLORS[r.status],
          assignedComputer: studentDetails.assignedComputer,
          usedComputer: usedPc,
          pcObservation: pcObservation
        };
      });

    return { 
        summary, 
        attendancePercentage, 
        pieChartData: chartData, // For Pie
        barChartData: chartData, // For Bar (if needed, but using Pie for individual)
        totalRecords, 
        dailyRecordsTable, 
        studentName: studentDetails.name,
        pcChanges,
        lastUnexcusedAbsenceDate
    };
  }, [reportType, selectedStudentId, selectedPeriodId, attendanceRecords, students]);

  const groupReportData = useMemo(() => {
    if (reportType !== 'group' || !selectedGradeId || !selectedPeriodId) return null;

    const gradeStudents = students.filter(s => s.gradeId === selectedGradeId);
    const studentIdsInGrade = gradeStudents.map(s => s.id);

    const recordsForGradeAndPeriod = attendanceRecords.filter(
      r => studentIdsInGrade.includes(r.studentId) && r.periodId === selectedPeriodId
    );
    
    const summary: Record<AttendanceStatus, number> = { PRESENT: 0, ABSENT_UNEXCUSED: 0, ABSENT_EXCUSED: 0, SICK_BAY: 0 };
    recordsForGradeAndPeriod.forEach(r => summary[r.status]++);
    
    const totalSessions = recordsForGradeAndPeriod.length; 
    const groupAttendancePercentage = totalSessions > 0 ? (summary.PRESENT / totalSessions * 100).toFixed(1) : '0.0';

    const chartData: ReportData[] = (Object.keys(STATUS_LABELS) as AttendanceStatus[]).map(status => ({
      name: STATUS_LABELS[status],
      value: summary[status] || 0, 
      fill: STATUS_COLORS[status]
    })).filter(item => item.value > 0);

    const studentSummaries = gradeStudents.map(student => {
      const studRecords = recordsForGradeAndPeriod.filter(r => r.studentId === student.id);
      const studSummaryCounts: Record<AttendanceStatus, number> = { PRESENT: 0, ABSENT_UNEXCUSED: 0, ABSENT_EXCUSED: 0, SICK_BAY: 0 };
      studRecords.forEach(r => studSummaryCounts[r.status]++);
      const totalStudSessions = studRecords.length;
      return {
        name: student.name,
        assignedComputer: student.assignedComputer, 
        ...studSummaryCounts,
        TotalSesionesRegistradas: totalStudSessions, 
        PorcentajeAsistencia: totalStudSessions > 0 ? (studSummaryCounts.PRESENT / totalStudSessions * 100).toFixed(1) + '%' : '0.0%'
      };
    });

    return { 
        pieChartData: chartData, // For Pie
        barChartData: chartData, // For Bar
        groupAttendancePercentage, 
        summary, 
        totalRecords: totalSessions, 
        studentSummaries 
    };
  }, [reportType, selectedGradeId, selectedPeriodId, attendanceRecords, students]);

  const exportToCSV = (data: any[], filename: string) => {
    if (!data || data.length === 0) { alert("No hay datos para exportar."); return; }
    const header = Object.keys(data[0]).join(',');
    const rows = data.map(row => Object.values(row).map(val => `"${String(val).replace(/"/g, '""')}"`).join(',')).join('\n');
    const csvContent = `\uFEFF${header}\n${rows}`; 
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", filename);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    }
  };
  
  const handleExport = useCallback(async (format: 'PDF' | 'CSV') => {
    setIsGeneratingPdf(format === 'PDF'); // Trigger re-render for PDF chart capture if needed

    // Small delay to allow DOM to update if isGeneratingPdf caused changes
    if (format === 'PDF') {
        await new Promise(resolve => setTimeout(resolve, 100));
    }

    const currentGradeName = grades.find(g => g.id === selectedGradeId)?.name || 'N/A';
    const currentPeriodName = periods.find(p => p.id === selectedPeriodId)?.name || 'N/A';

    if (format === 'CSV') {
      if (reportType === 'individual' && individualReportData?.dailyRecordsTable) {
        const dataToExport = individualReportData.dailyRecordsTable.map(r => ({ 
            Fecha: r.date, 
            HorasCubiertas: r.classHoursCovered, 
            Estado: r.statusLabel,
            PCAsignado: r.assignedComputer,
            PCUsadoHoy: r.usedComputer,
            ObservacionPC: r.pcObservation
        }));
        exportToCSV(dataToExport, `Reporte_Individual_${individualReportData.studentName}_${currentGradeName}_${currentPeriodName}.csv`);
      } else if (reportType === 'group' && groupReportData?.studentSummaries) {
        const dataToExport = groupReportData.studentSummaries.map(s => ({
            Estudiante: s.name,
            PCAsignado: s.assignedComputer,
            [STATUS_LABELS.PRESENT]: s.PRESENT,
            [STATUS_LABELS.ABSENT_UNEXCUSED]: s.ABSENT_UNEXCUSED,
            [STATUS_LABELS.ABSENT_EXCUSED]: s.ABSENT_EXCUSED,
            [STATUS_LABELS.SICK_BAY]: s.SICK_BAY,
            TotalSesionesRegistradas: s.TotalSesionesRegistradas,
            PorcentajeAsistencia: s.PorcentajeAsistencia
        }));
        exportToCSV(dataToExport, `Reporte_Grupal_${currentGradeName}_${currentPeriodName}.csv`);
      } else { alert("No hay datos para exportar en formato CSV."); }
      setIsGeneratingPdf(false);
    } else if (format === 'PDF') {
      const doc = new jsPDF({ orientation: 'p', unit: 'mm', format: 'a4' });
      let yPos = 35; // Initial Y position after header
      
      if (reportType === 'individual' && individualReportData) {
        drawHeader(doc, `Reporte Individual de Asistencia`);
        doc.setFontSize(10);
        doc.text(`Estudiante: ${individualReportData.studentName}`, 14, yPos); yPos += 6;
        doc.text(`Grado: ${currentGradeName} - Periodo: ${currentPeriodName}`, 14, yPos); yPos += 6;
        doc.text(`Total Sesiones Registradas: ${individualReportData.totalRecords}`, 14, yPos); yPos += 6;
        doc.text(`Porcentaje de Asistencia (sesiones): ${individualReportData.attendancePercentage}%`, 14, yPos); yPos += 8;
        
        // Chart
        const chartContainerId = 'pdf-individual-pie-chart';
        const chartContainer = document.getElementById(chartContainerId);
        let chartImage: string | null = null;
        if (chartContainer) {
            const svgElement = chartContainer.querySelector('svg');
            if (svgElement) {
                try { chartImage = await convertSvgToImage(svgElement); }
                catch (e) { console.error("Error converting individual report chart:", e); }
            }
        }
        if (chartImage) {
            const imgWidth = 80; const imgHeight = 40; // A4 width is ~210mm
            const chartX = (doc.internal.pageSize.getWidth() - imgWidth) / 2;
            doc.addImage(chartImage, 'PNG', chartX, yPos, imgWidth, imgHeight);
            yPos += imgHeight + 10;
        } else { yPos +=5; /* space if no chart */ }

        // Additional Info Section
        doc.setFontSize(11);
        doc.setFillColor(230, 230, 230); // Light gray fill
        doc.roundedRect(14, yPos -2, doc.internal.pageSize.getWidth() - 28, 22, 3, 3, 'F');
        doc.setTextColor(50,50,50);
        doc.text("Información Adicional:", 16, yPos + 4); yPos += 10;
        doc.setFontSize(9);
        doc.text(`- Total Sesiones Asistidas: ${individualReportData.summary.PRESENT}`, 18, yPos); yPos +=5;
        doc.text(`- Número de Cambios de Computador: ${individualReportData.pcChanges}`, 18, yPos); yPos +=5;
        if(individualReportData.lastUnexcusedAbsenceDate) {
            doc.text(`- Última Inasistencia (S.E.): ${new Date(individualReportData.lastUnexcusedAbsenceDate + 'T00:00:00').toLocaleDateString('es-ES')}`, 18, yPos); yPos+=5;
        } else {
            doc.text(`- Última Inasistencia (S.E.): Ninguna registrada`, 18, yPos); yPos+=5;
        }
        yPos += 5; // Extra space after additional info
        
        if (individualReportData.dailyRecordsTable.length > 0) {
          const tableBody = individualReportData.dailyRecordsTable.map(r => [r.date, r.classHoursCovered, r.statusLabel, r.assignedComputer, r.usedComputer, r.pcObservation]);
          (doc as any).autoTable({ 
            startY: yPos, 
            head: [['Fecha', 'Horas', 'Estado', 'PC Asig.', 'PC Usado', 'Obs. PC']], 
            body: tableBody, 
            theme: 'grid', 
            headStyles: { fillColor: [10, 79, 138], textColor: 255, fontSize: 8 },
            bodyStyles: { fontSize: 7, cellPadding: 1.5 },
            columnStyles: { 
                0: { cellWidth: 20 }, 1: { cellWidth: 18 }, 2: { cellWidth: 25 }, 
                3: { cellWidth: 18 }, 4: { cellWidth: 18 }, 5: { cellWidth: 'auto'} 
            },
            didDrawPage: (data: any) => { drawFooter(doc); drawHeader(doc, `Reporte Individual de Asistencia`); } // Redraw header/footer on new pages
          });
        }
        drawFooter(doc); // Final footer for single/last page
        doc.save(`Reporte_Individual_${individualReportData.studentName}_${currentGradeName}_${currentPeriodName}.pdf`);

      } else if (reportType === 'group' && groupReportData) {
        drawHeader(doc, `Reporte Grupal de Asistencia`);
        doc.setFontSize(10);
        doc.text(`Grado: ${currentGradeName} - Periodo: ${currentPeriodName}`, 14, yPos); yPos += 6;
        doc.text(`Total Sesiones Registradas del Grupo: ${groupReportData.totalRecords}`, 14, yPos); yPos += 6;
        doc.text(`Promedio de Asistencia del Grupo (sesiones): ${groupReportData.groupAttendancePercentage}%`, 14, yPos); yPos += 8;

        let pieChartImage: string | null = null;
        let barChartImage: string | null = null;
        
        const pieContainer = document.getElementById('pdf-group-pie-chart');
        if (pieContainer?.querySelector('svg')) pieChartImage = await convertSvgToImage(pieContainer.querySelector('svg')!);
        
        const barContainer = document.getElementById('pdf-group-bar-chart');
        if (barContainer?.querySelector('svg')) barChartImage = await convertSvgToImage(barContainer.querySelector('svg')!);

        const chartWidth = 85; // mm
        const chartHeight = 50; // mm
        const chartSpacing = 10; // mm
        const totalChartWidth = (chartWidth * 2) + chartSpacing;
        const startX = (doc.internal.pageSize.getWidth() - totalChartWidth) / 2;

        if (pieChartImage && barChartImage) {
            doc.addImage(pieChartImage, 'PNG', startX, yPos, chartWidth, chartHeight);
            doc.addImage(barChartImage, 'PNG', startX + chartWidth + chartSpacing, yPos, chartWidth, chartHeight);
            yPos += chartHeight + 10;
        } else if (pieChartImage) {
            doc.addImage(pieChartImage, 'PNG', (doc.internal.pageSize.getWidth() - chartWidth)/2, yPos, chartWidth, chartHeight);
            yPos += chartHeight + 10;
        } else if (barChartImage) {
            doc.addImage(barChartImage, 'PNG', (doc.internal.pageSize.getWidth() - chartWidth)/2, yPos, chartWidth, chartHeight);
            yPos += chartHeight + 10;
        } else { yPos +=5; }


        const bodyData = (Object.keys(groupReportData.summary) as AttendanceStatus[]).map(status => [STATUS_LABELS[status], groupReportData.summary[status], groupReportData.totalRecords > 0 ? ((groupReportData.summary[status] / groupReportData.totalRecords) * 100).toFixed(1) + '%' : '0.0%']);
        (doc as any).autoTable({ 
            startY: yPos, 
            head: [['Estado de Asistencia', 'Total Sesiones Grupo', 'Porcentaje del Grupo']], 
            body: bodyData, 
            theme: 'striped', 
            headStyles: { fillColor: [10, 79, 138], textColor: 255 },
            didDrawPage: (data: any) => { drawFooter(doc); drawHeader(doc, `Reporte Grupal de Asistencia`); }
        });
        
        if(groupReportData.studentSummaries.length > 0) {
            const studentTableBody = groupReportData.studentSummaries.map(s => [
                s.name, s.PRESENT, s.ABSENT_UNEXCUSED, s.ABSENT_EXCUSED, s.SICK_BAY, s.TotalSesionesRegistradas, s.PorcentajeAsistencia
            ]);
            (doc as any).autoTable({
                startY: (doc as any).lastAutoTable.finalY + 10,
                head: [['Estudiante', 'P', 'A(SE)', 'A(J)', 'Enf.', 'Total Ses.', '% Asist.']],
                body: studentTableBody,
                theme: 'grid',
                headStyles: { fillColor: [10, 79, 138], textColor: 255, fontSize: 8 },
                bodyStyles: { fontSize: 7, cellPadding: 1 },
                columnStyles: {
                    0: {cellWidth: 'auto'}, 1: {cellWidth: 10}, 2: {cellWidth: 10}, 3: {cellWidth: 10}, 4: {cellWidth: 10}, 5: {cellWidth: 15}, 6: {cellWidth: 15}
                },
                didDrawPage: (data: any) => { drawFooter(doc); drawHeader(doc, `Reporte Grupal de Asistencia`); }
            });
        }
        drawFooter(doc);
        doc.save(`Reporte_Grupal_${currentGradeName}_${currentPeriodName}.pdf`);
      } else { alert("No hay datos para exportar en formato PDF."); }
      setIsGeneratingPdf(false);
    }
  }, [reportType, individualReportData, groupReportData, selectedGradeId, selectedPeriodId, grades, periods]);

  // On-screen chart rendering function
  const renderChartComponent = (data: ReportData[], chartType: 'pie' | 'bar') => {
    if (!data || data.length === 0 || data.every(d => d.value === 0)) {
        return <p className="text-gray-500 text-center py-8">No hay suficientes datos para generar el gráfico.</p>;
    }
    
    if (chartType === 'bar') { 
      return (
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 20, right: 10, left: 0, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="name" tick={{ fontSize: 10 }} />
            <YAxis allowDecimals={false} label={{ value: 'Total Sesiones', angle: -90, position: 'insideLeft', fontSize: 10, offset:10 }} tick={{ fontSize: 10 }}/>
            <Tooltip formatter={(value: number) => [value, "Total Sesiones"]}/>
            <Legend wrapperStyle={{fontSize: "12px"}}/>
            <Bar dataKey="value" name="Total Sesiones">
              {data.map((entry, index) => (<Cell key={`cell-bar-${index}`} fill={entry.fill} />))}
              <LabelList dataKey="value" position="top" style={{ fill: '#374151' }} fontSize="12px" fontWeight="bold"/>
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      );
    }
    if (chartType === 'pie') { 
      return (
        <ResponsiveContainer width="100%" height="100%">
          <PieChart margin={{ top: 0, right: 0, bottom: 0, left: 0 }}>
            <Pie 
              data={data} 
              dataKey="value" 
              nameKey="name" 
              cx="50%" 
              cy="50%" 
              outerRadius={reportType === 'group' ? 80 : 100} 
              labelLine={reportType === 'group'} // Enable line only for group for outer labels
              label={reportType === 'group' ? renderOuterCustomizedPieLabel : (props: any) => { // Simpler label for individual
                const { name, percent } = props;
                if (percent * 100 < 5) return null;
                return `${name} (${(percent * 100).toFixed(0)}%)`;
              }}
              isAnimationActive={true}
            >
              {data.map((entry, index) => (<Cell key={`cell-pie-${index}`} fill={entry.fill} />))}
            </Pie>
            <Tooltip formatter={(value: number, name: string, props: any) => {
                const percentage = props.payload && props.payload.percent !== undefined 
                                   ? (props.payload.percent * 100).toFixed(1) 
                                   : 'N/A';
                return [`${value} sesiones (${percentage}%)`, name];
            }}/>
            <Legend wrapperStyle={{fontSize: "12px", marginTop: reportType === 'group' ? '15px' : '5px'}}/>
          </PieChart>
        </ResponsiveContainer>
      );
    }
    return null;
  }

  return (
    <div className="p-6 animate-fadeIn">
      {/* Hidden divs for PDF chart rendering */}
      {isGeneratingPdf && (
        <div style={{ position: 'absolute', left: '-9999px', width: '700px', height: '350px', background:'white' }}>
          {reportType === 'individual' && individualReportData?.pieChartData && (
            <div id="pdf-individual-pie-chart" style={{ width: '100%', height: '100%' }}>
              {renderChartComponent(individualReportData.pieChartData, 'pie')}
            </div>
          )}
          {reportType === 'group' && groupReportData?.pieChartData && (
            <div id="pdf-group-pie-chart" style={{ width: '100%', height: '100%' }}>
              {renderChartComponent(groupReportData.pieChartData, 'pie')}
            </div>
          )}
          {reportType === 'group' && groupReportData?.barChartData && (
             <div id="pdf-group-bar-chart" style={{ width: '100%', height: '100%' }}>
              {renderChartComponent(groupReportData.barChartData, 'bar')}
            </div>
          )}
        </div>
      )}

      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-6`}>Reportes de Asistencia</h2>
      <div className="mb-6 flex flex-wrap gap-4 items-center">
        <div className="space-x-2">
          <Button variant={reportType === 'individual' ? 'primary' : 'ghost'} onClick={() => setReportType('individual')}>Reporte Individual</Button>
          <Button variant={reportType === 'group' ? 'primary' : 'ghost'} onClick={() => setReportType('group')}>Reporte Grupal</Button>
        </div>
        <select value={selectedGradeId} onChange={e => setSelectedGradeId(e.target.value)} className="form-select">
          {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
        </select>
        {reportType === 'individual' && (
          <select value={selectedStudentId} onChange={e => setSelectedStudentId(e.target.value)} className="form-select" disabled={studentsInSelectedGrade.length === 0}>
            {studentsInSelectedGrade.length === 0 && <option value="">-- Sin estudiantes --</option>}
            {studentsInSelectedGrade.map(s => <option key={s.id} value={s.id}>{s.name} (PC: {s.assignedComputer})</option>)}
          </select>
        )}
        <select value={selectedPeriodId} onChange={e => setSelectedPeriodId(e.target.value)} className="form-select">
          {periods.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      </div>

      {reportType === 'individual' && individualReportData && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold mb-4">Reporte de {individualReportData.studentName} - {periods.find(p=>p.id === selectedPeriodId)?.name || 'N/A'}</h3>
          {individualReportData.totalRecords > 0 ? (
            <>
              <p><strong>Porcentaje de Asistencia General (sesiones):</strong> {individualReportData.attendancePercentage}%</p>
              <p><strong>Resumen de Asistencias (Total Sesiones):</strong></p>
              <ul className="list-disc list-inside mb-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                {Object.entries(individualReportData.summary).map(([status, count]) => (<li key={status}>{STATUS_LABELS[status as AttendanceStatus]}: {count}</li>))}
              </ul>
              <div className="mb-6 h-[300px] md:h-[350px]">
                {renderChartComponent(individualReportData.pieChartData, 'pie')}
              </div>
              
              <h4 className="text-lg font-semibold mt-6 mb-3">Tabla de Asistencia Detallada Individual:</h4>
              {individualReportData.dailyRecordsTable.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200 border">
                    <thead className="bg-gray-50"><tr>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fecha</th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Horas Cubiertas</th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PC Asignado</th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PC Usado Hoy</th>
                        <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Observación PC</th>
                    </tr></thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {individualReportData.dailyRecordsTable.map((record, index) => (
                        <tr key={index}>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{record.date}</td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-900">{record.classHoursCovered}</td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm">
                            <span style={{ backgroundColor: record.statusColor, color: record.statusLabel === STATUS_LABELS.ABSENT_EXCUSED ? '#000': '#FFF', padding: '0.25rem 0.5rem', borderRadius: '0.25rem' }}>
                              {record.statusLabel}
                            </span>
                          </td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-700">{record.assignedComputer}</td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-gray-700">{record.usedComputer}</td>
                          <td className="px-4 py-4 whitespace-nowrap text-sm text-yellow-700">{record.pcObservation}</td>
                        </tr>
                      ))}
                    </tbody></table></div>
              ) : <p className="text-gray-500">No hay registros diarios para mostrar.</p>}
            </>
          ) : <p className="text-gray-500">No hay registros para este estudiante en el periodo.</p>}
        </div>
      )}
      
      {reportType === 'group' && groupReportData && (
        <div className="bg-white p-6 rounded-lg shadow">
          <h3 className="text-xl font-semibold mb-4">Reporte Grupal de {grades.find(g=>g.id === selectedGradeId)?.name || 'N/A'} - {periods.find(p=>p.id === selectedPeriodId)?.name || 'N/A'}</h3>
           {groupReportData.totalRecords > 0 ? (
            <>
              <p><strong>Promedio de Asistencia del Grupo (sesiones):</strong> {groupReportData.groupAttendancePercentage}%</p>
              <p><strong>Resumen Total de Asistencias del Grupo (Total Sesiones):</strong></p>
              <ul className="list-disc list-inside mb-4 grid grid-cols-1 sm:grid-cols-2 gap-x-4">
                 {Object.entries(groupReportData.summary).map(([status, count]) => (<li key={status}>{STATUS_LABELS[status as AttendanceStatus]}: {count}</li>))}
              </ul>
              <div className="grid md:grid-cols-2 gap-4 h-[350px] md:h-[400px]">
                <div className="h-full">{renderChartComponent(groupReportData.pieChartData, 'pie')}</div>
                <div className="h-full">{renderChartComponent(groupReportData.barChartData, 'bar')}</div>
              </div>
            </>
           ) : <p className="text-gray-500">No hay registros para este grupo en el periodo.</p>}
        </div>
      )}
      
      {((reportType === 'individual' && individualReportData?.totalRecords > 0) || (reportType === 'group' && groupReportData?.totalRecords > 0)) && (
        <div className="mt-6 space-x-2">
            <Button onClick={() => handleExport('CSV')} variant="secondary" disabled={isGeneratingPdf}>Exportar a CSV</Button>
            <Button onClick={() => handleExport('PDF')} variant="secondary" disabled={isGeneratingPdf}>
                {isGeneratingPdf ? 'Generando PDF...' : 'Exportar a PDF'}
            </Button>
        </div>
      )}
    </div>
  );
};

export default AttendanceReportsScreen;
