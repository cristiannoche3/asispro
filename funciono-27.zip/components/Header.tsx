
import React, { useState, useEffect, useRef } from 'react';
import { APP_TITLE, APP_SUBTITLE, INSTITUTIONAL_COLORS } from '../constants';
import { ScreenView, AppAlert } from '../types';
import BellIcon from './icons/BellIcon';
import ChatBubbleIcon from './icons/ChatBubbleIcon'; // Import AsiBot icon
import DoorIcon from './icons/DoorIcon'; // Import DoorIcon for logout
import Button from './Button';

interface HeaderProps {
  setCurrentView: (view: ScreenView) => void;
  activeAlerts: AppAlert[];
  dismissAlert: (alertId: string) => void;
  openAsiBot: () => void; // Handler to open AsiBot
  onLogoutRequest: () => void; // Handler to request logout (open confirmation)
}

const Header: React.FC<HeaderProps> = ({ setCurrentView, activeAlerts, dismissAlert, openAsiBot, onLogoutRequest }) => {
  const [currentDate, setCurrentDate] = useState('');
  const [isAlertPanelOpen, setIsAlertPanelOpen] = useState(false);
  const [animateBell, setAnimateBell] = useState(false);
  const alertPanelRef = useRef<HTMLDivElement>(null);
  const bellButtonRef = useRef<HTMLButtonElement>(null);
  const prevAlertsLength = useRef(activeAlerts.length);

  useEffect(() => {
    const date = new Date();
    setCurrentDate(date.toLocaleDateString('es-ES', { day: '2-digit', month: '2-digit', year: 'numeric' }));
  }, []);

  useEffect(() => {
    // Animate bell if new alerts arrive and panel is closed
    if (activeAlerts.length > prevAlertsLength.current && !isAlertPanelOpen) {
      setAnimateBell(true);
      const timer = setTimeout(() => setAnimateBell(false), 500); // Duration of animation
      return () => clearTimeout(timer);
    }
    prevAlertsLength.current = activeAlerts.length;
  }, [activeAlerts.length, isAlertPanelOpen]);

  const handleLogoClick = () => {
    setCurrentView(ScreenView.DAILY_SUMMARY);
  };

  const toggleAlertPanel = () => {
    setIsAlertPanelOpen(prev => !prev);
  };

  const handleDismissAlert = (alertId: string) => {
    dismissAlert(alertId);
    // If this was the last alert, close the panel
    if (activeAlerts.length === 1) {
      setIsAlertPanelOpen(false);
    }
  };

  // Close alert panel when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        alertPanelRef.current && !alertPanelRef.current.contains(event.target as Node) &&
        bellButtonRef.current && !bellButtonRef.current.contains(event.target as Node)
      ) {
        setIsAlertPanelOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <header className={`bg-${INSTITUTIONAL_COLORS.BLUE} ${INSTITUTIONAL_COLORS.TEXT_LIGHT} p-4 shadow-md sticky top-0 z-50`}>
      <div className="container mx-auto flex justify-between items-center">
        <div className="flex items-center">
          <div
            onClick={handleLogoClick}
            className={`asispro-logo-animated text-3xl font-bold mr-3 text-${INSTITUTIONAL_COLORS.YELLOW} hover:scale-105 hover:opacity-90 transition-all duration-200 cursor-pointer`}
            title="Ir al Resumen del Día"
          >
            AsisPRO
          </div>
          <div>
            <h1 className="text-xl font-semibold">{APP_TITLE}</h1>
            <p className="text-sm opacity-90">{APP_SUBTITLE}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2 sm:space-x-3">
          <div className="text-lg font-medium hidden sm:block">
            {currentDate}
          </div>
          <button
            onClick={openAsiBot}
            className={`p-2 rounded-full hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-${INSTITUTIONAL_COLORS.YELLOW} transition-colors`}
            aria-label="Consultar a AsiBot"
            title="Consultar a AsiBot"
          >
            <ChatBubbleIcon className={`w-6 h-6 text-gray-300 hover:text-${INSTITUTIONAL_COLORS.YELLOW}`} />
          </button>
          <div className="relative">
            <button
              ref={bellButtonRef}
              onClick={toggleAlertPanel}
              className={`relative p-2 rounded-full hover:bg-sky-700 focus:outline-none focus:ring-2 focus:ring-${INSTITUTIONAL_COLORS.YELLOW} transition-colors`}
              aria-label="Notificaciones"
            >
              <BellIcon className={`w-6 h-6 ${activeAlerts.length > 0 ? `text-${INSTITUTIONAL_COLORS.YELLOW}` : 'text-gray-300'} ${animateBell ? 'bell-animate-shake' : ''}`} />
              {activeAlerts.length > 0 && (
                <span className="notification-bell-badge">
                  {activeAlerts.length}
                </span>
              )}
            </button>
            {isAlertPanelOpen && (
              <div
                ref={alertPanelRef}
                // alert-panel class from index.html provides base structure like max-height, overflow
                className="alert-panel bg-slate-800 border border-slate-700 shadow-2xl"
              >
                <div className="p-3 border-b border-slate-700">
                  <h4 className="font-semibold text-gray-100 text-center">🔔 Notificaciones de Asistencia</h4>
                </div>
                {activeAlerts.length === 0 ? (
                  <p className="text-gray-300 text-sm p-4 text-center">No hay alertas nuevas.</p>
                ) : (
                  <ul className="divide-y divide-slate-700">
                    {activeAlerts.map(alert => (
                      <li key={alert.id} className="p-3 hover:bg-slate-700/50 transition-colors">
                        <p className="text-sm font-semibold text-white">{alert.studentName}
                          <span className="text-xs text-gray-300 ml-1">({alert.gradeName})</span>
                        </p>
                        <p className="text-xs text-red-400 font-medium my-0.5">
                          {alert.unexcusedAbsenceCount} inasistencias S.E.
                        </p>
                        <p className="text-xs text-gray-400">
                          Última ausencia: {new Date(alert.lastUnexcusedAbsenceDate + 'T00:00:00').toLocaleDateString('es-ES')}
                        </p>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleDismissAlert(alert.id)}
                          className="mt-2 text-xs !px-2 !py-1 border-sky-500 text-sky-400 hover:bg-slate-700 hover:text-sky-300"
                        >
                          Marcar como revisada
                        </Button>
                      </li>
                    ))}
                  </ul>
                )}
                <div className="p-2 border-t border-slate-700 text-center">
                    <button
                        onClick={() => { /* Placeholder for future "View All" functionality */ setIsAlertPanelOpen(false); }}
                        className="text-xs text-sky-400 hover:text-sky-300 hover:underline"
                    >
                        Ver todo »
                    </button>
                </div>
              </div>
            )}
          </div>
          <Button
            onClick={onLogoutRequest}
            variant="primary" 
            size="sm"
            className={`!bg-transparent hover:!bg-sky-700 !border !border-${INSTITUTIONAL_COLORS.YELLOW} !text-${INSTITUTIONAL_COLORS.YELLOW} focus:!ring-${INSTITUTIONAL_COLORS.YELLOW}/50 !px-3 !py-1.5`}
            title="Cerrar Sesión"
            aria-label="Cerrar Sesión"
          >
            <DoorIcon className="w-5 h-5 mr-1 sm:mr-2" />
            <span className="hidden sm:inline">Salir</span>
          </Button>
        </div>
      </div>
    </header>
  );
};

export default Header;
