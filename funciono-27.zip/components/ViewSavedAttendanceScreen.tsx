
import React, { useState, useMemo, useCallback, useEffect } from 'react';
import { Grade, Student, Period, AttendanceRecord, AttendanceStatus, ScreenView } from '../types';
import Button from './Button';
import EditIcon from './icons/EditIcon';
import DeleteIcon from './icons/DeleteIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS } from '../constants';
import PlusIcon from './icons/PlusIcon';
import Modal from './Modal'; 

interface ViewSavedAttendanceScreenProps {
  grades: Grade[];
  students: Student[];
  periods: Period[];
  attendanceRecords: AttendanceRecord[];
  setCurrentView: (view: ScreenView) => void;
  setAttendanceToEdit: (record: AttendanceRecord | null) => void;
  deleteAttendanceRecord: (recordId: string) => void;
  deleteAllAttendanceForGradeDate: (gradeId: string, date: string) => void;
  setInitialTakeAttendanceContext: (context: { gradeId: string; date: string } | null) => void;
  goBack: () => void;
  canGoBack: boolean;
}

interface DeleteAllContext {
  gradeId: string;
  date: string;
  gradeName: string;
  formattedDate: string;
}

const formatDisplayDate = (dateString: string): string => {
  if (!dateString) return "";
  const dateObj = new Date(dateString + 'T00:00:00'); // Ensure interpretation as local date
  return dateObj.toLocaleDateString('es-ES', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });
};

const ViewSavedAttendanceScreen: React.FC<ViewSavedAttendanceScreenProps> = ({
  grades,
  students,
  periods,
  attendanceRecords,
  setCurrentView,
  setAttendanceToEdit,
  deleteAttendanceRecord,
  deleteAllAttendanceForGradeDate,
  setInitialTakeAttendanceContext,
  goBack,
  canGoBack
}) => {
  const [selectedGradeId, setSelectedGradeId] = useState<string>(grades.length > 0 ? grades[0].id : '');
  const [selectedDate, setSelectedDate] = useState<string>('');
  
  const [isConfirmDeleteAllModalOpen, setIsConfirmDeleteAllModalOpen] = useState(false);
  const [deleteAllModalContext, setDeleteAllModalContext] = useState<DeleteAllContext | null>(null);

  const availableDatesForGrade = useMemo(() => {
    if (!selectedGradeId) return [];
    const datesWithRecords = new Set<string>();
    attendanceRecords.forEach(record => {
      if (record.gradeId === selectedGradeId) {
        datesWithRecords.add(record.date);
      }
    });
    return Array.from(datesWithRecords).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());
  }, [attendanceRecords, selectedGradeId]);

  useEffect(() => {
    if (availableDatesForGrade.length > 0) {
      if (!selectedDate || !availableDatesForGrade.includes(selectedDate)) {
        setSelectedDate(availableDatesForGrade[0]); // Default to the most recent date if current selection is invalid
      }
    } else {
      setSelectedDate(''); // No dates available
    }
  }, [availableDatesForGrade, selectedDate]);

  const filteredAttendance = useMemo(() => {
    if (!selectedDate) return []; 
    return attendanceRecords
      .filter(ar => ar.gradeId === selectedGradeId && ar.date === selectedDate)
      .map(ar => {
        const student = students.find(s => s.id === ar.studentId);
        const period = periods.find(p => p.id === ar.periodId);
        return {
          ...ar,
          studentName: student?.name || 'Desconocido',
          assignedComputer: student?.assignedComputer, // Get student's current assigned PC
          periodName: period?.name || 'Desconocido'
        };
      })
      .sort((a,b) => (a.assignedComputer ?? 999) - (b.assignedComputer ?? 999) || a.studentName.localeCompare(b.studentName));
  }, [attendanceRecords, selectedGradeId, selectedDate, students, periods]);

  const handleModifyIndividual = useCallback((record: AttendanceRecord) => {
    const student = students.find(s => s.id === record.studentId);
    // Ensure the record passed to edit has a usedComputer value, defaulting to assigned if not present
    const recordToEdit = {
        ...record,
        usedComputer: record.usedComputer ?? student?.assignedComputer ?? 0 // Fallback to 0 if student not found
    };
    setAttendanceToEdit(recordToEdit);
    setCurrentView(ScreenView.TAKE_ATTENDANCE);
  }, [setAttendanceToEdit, setCurrentView, students]);

  const handleDeleteIndividual = useCallback((recordId: string, studentName: string) => {
    if (window.confirm(`¿Está seguro que desea eliminar la asistencia de ${studentName} para esta fecha y periodo? Esta acción no se puede deshacer.`)) {
      deleteAttendanceRecord(recordId);
    }
  }, [deleteAttendanceRecord]);

  const handleGoToTakeAttendanceForDay = useCallback(() => {
    if (!selectedGradeId || !selectedDate) {
      alert("Por favor seleccione un grado y una fecha válida con registros.");
      return;
    }
    setInitialTakeAttendanceContext({ gradeId: selectedGradeId, date: selectedDate });
    setCurrentView(ScreenView.TAKE_ATTENDANCE);
  }, [selectedGradeId, selectedDate, setInitialTakeAttendanceContext, setCurrentView]);

  const openDeleteAllConfirmationModal = useCallback(() => {
    if (!selectedGradeId || !selectedDate) {
      alert("Por favor seleccione un grado y una fecha válida con registros.");
      return;
    }
    const gradeName = grades.find(g => g.id === selectedGradeId)?.name || "este grado";
    const formattedDate = formatDisplayDate(selectedDate);
    
    setDeleteAllModalContext({ gradeId: selectedGradeId, date: selectedDate, gradeName, formattedDate });
    setIsConfirmDeleteAllModalOpen(true);
  }, [selectedGradeId, selectedDate, grades]);

  const executeConfirmDeleteAllForDayAndGrade = useCallback(() => {
    if (deleteAllModalContext) {
      deleteAllAttendanceForGradeDate(deleteAllModalContext.gradeId, deleteAllModalContext.date);
      alert(`Toda la asistencia para ${deleteAllModalContext.gradeName} del ${deleteAllModalContext.formattedDate} ha sido eliminada.`);
    }
    setIsConfirmDeleteAllModalOpen(false);
    setDeleteAllModalContext(null);
  }, [deleteAllModalContext, deleteAllAttendanceForGradeDate]);

  const cancelDeleteAll = useCallback(() => {
    setIsConfirmDeleteAllModalOpen(false);
    setDeleteAllModalContext(null);
  }, []);
  
  const getStatusLabel = (status: AttendanceStatus): string => {
    switch (status) {
        case AttendanceStatus.PRESENT: return 'Presente';
        case AttendanceStatus.ABSENT_UNEXCUSED: return 'Ausente (S.E.)';
        case AttendanceStatus.ABSENT_EXCUSED: return 'Ausente (Just.)';
        case AttendanceStatus.SICK_BAY: return 'Enfermería';
        default: return 'Desconocido';
    }
  }
  
  const getStatusColorClass = (status: AttendanceStatus): string => {
    switch (status) {
      case AttendanceStatus.PRESENT: return 'bg-present text-present-text';
      case AttendanceStatus.ABSENT_UNEXCUSED: return 'bg-absent-unexcused text-white';
      case AttendanceStatus.ABSENT_EXCUSED: return 'bg-absent-excused text-black';
      case AttendanceStatus.SICK_BAY: return 'bg-sick-bay text-white';
      default: return 'bg-gray-200 text-gray-700';
    }
  };
  
  const baseScreenContent = (message: string, buttonTargetView?: ScreenView, buttonLabel?: string) => (
    <div className="p-6 text-center">
        {canGoBack && (
            <div className="text-left mb-6">
                <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
                    Regresar
                </Button>
            </div>
        )}
        <p className="text-gray-600 text-lg mb-4">{message}</p>
        {buttonTargetView && buttonLabel && (
            <Button onClick={() => setCurrentView(buttonTargetView)} variant="primary">
                {buttonLabel}
            </Button>
        )}
    </div>
  );

  if (grades.length === 0) {
    return baseScreenContent("No hay grados creados. Por favor, primero gestione los grados.", ScreenView.MANAGE_GRADES, "Ir a Gestionar Grados");
  }

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-6`}>Ver Asistencias Guardadas</h2>

      <div className="mb-6 flex flex-col sm:flex-row gap-4 items-end bg-white p-4 rounded-lg shadow-sm">
        <div className="flex-grow">
          <label htmlFor="gradeSelectView" className="block text-sm font-medium text-gray-700 mb-1">Grado:</label>
          <select
            id="gradeSelectView"
            value={selectedGradeId}
            onChange={(e) => setSelectedGradeId(e.target.value)}
            className="form-select w-full"
          >
            {grades.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
          </select>
        </div>
        <div className="flex-grow">
          <label htmlFor="dateSelectView" className="block text-sm font-medium text-gray-700 mb-1">Fecha con Registros:</label>
          {availableDatesForGrade.length > 0 ? (
            <select
              id="dateSelectView"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="form-select w-full"
            >
              {availableDatesForGrade.map(date => (
                <option key={date} value={date}>
                  {formatDisplayDate(date)}
                </option>
              ))}
            </select>
          ) : (
            <p className="text-sm text-gray-500 mt-2 italic h-[calc(1.5em+1rem+2px)] flex items-center">
              {selectedGradeId ? "No hay fechas con registros para este grado." : "Seleccione un grado."}
            </p>
          )}
        </div>
        <div className="flex flex-col sm:flex-row gap-2 pt-2 sm:pt-0 self-end">
             <Button 
                onClick={handleGoToTakeAttendanceForDay} 
                variant="ghost" 
                size="md"
                leftIcon={<PlusIcon className="w-5 h-5"/>}
                title="Ir a tomar/modificar asistencia para el grado y fecha seleccionados"
                disabled={!selectedGradeId || !selectedDate}
            >
                Gestionar Día
            </Button>
            <Button 
                onClick={openDeleteAllConfirmationModal} 
                variant="danger" 
                size="md"
                leftIcon={<DeleteIcon className="w-5 h-5"/>}
                title="Eliminar toda la asistencia para el grado y fecha seleccionados"
                disabled={!selectedGradeId || !selectedDate || filteredAttendance.length === 0}
            >
                Borrar Día
            </Button>
        </div>
      </div>

      {selectedGradeId && !selectedDate && availableDatesForGrade.length === 0 && (
        <p className="text-gray-600 text-center py-10">No se ha llamado lista en este grado para ninguna fecha disponible.</p>
      )}

      {selectedDate && filteredAttendance.length === 0 && (
         <p className="text-gray-600 text-center py-10">No hay registros de asistencia para el grado y fecha seleccionados.</p>
      )}

      {selectedDate && filteredAttendance.length > 0 && (
        <div className="bg-white shadow-md rounded-lg overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estudiante</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Periodo</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Estado</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PC Asignado</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">PC Usado Hoy</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Horas Cubiertas</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Acciones</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {filteredAttendance.map((record) => (
                <tr key={record.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{record.studentName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.periodName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColorClass(record.status)}`}>
                        {getStatusLabel(record.status)}
                     </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.assignedComputer ?? 'N/A'}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                    {record.usedComputer ?? record.assignedComputer ?? 'N/A'}
                    {record.usedComputer && record.assignedComputer && record.usedComputer !== record.assignedComputer && (
                        <span className="text-yellow-600 ml-1">(Cambiado)</span>
                    )}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{record.classHours.join(', ')}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium space-x-2">
                    <Button variant="ghost" size="sm" onClick={() => handleModifyIndividual(record)} leftIcon={<EditIcon className="w-4 h-4" />}>
                      Modificar
                    </Button>
                    <Button variant="danger" size="sm" onClick={() => handleDeleteIndividual(record.id, record.studentName)} leftIcon={<DeleteIcon className="w-4 h-4" />}>
                      Eliminar
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}


      {deleteAllModalContext && (
        <Modal
          isOpen={isConfirmDeleteAllModalOpen}
          onClose={cancelDeleteAll}
          title="Confirmar Eliminación Total"
          footer={
            <>
              <Button variant="ghost" onClick={cancelDeleteAll}>Cancelar</Button>
              <Button variant="danger" onClick={executeConfirmDeleteAllForDayAndGrade}>Sí, Borrar Todo</Button>
            </>
          }
        >
          <p className="text-gray-700">
            ¿Está seguro que desea eliminar TODA la asistencia para el grado <strong>{deleteAllModalContext.gradeName}</strong> del día <strong>{deleteAllModalContext.formattedDate}</strong>?
          </p>
          <p className="text-sm text-red-600 mt-2">Esta acción no se puede deshacer y afectará a todos los periodos registrados para este grado en esta fecha.</p>
        </Modal>
      )}
    </div>
  );
};

export default ViewSavedAttendanceScreen;