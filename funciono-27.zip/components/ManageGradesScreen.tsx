
import React, { useState, useCallback } from 'react';
import { Grade, ScreenView, AttendanceRecord } from '../types'; // Added AttendanceRecord
import Button from './Button';
import Modal from './Modal';
import PlusIcon from './icons/PlusIcon';
import EditIcon from './icons/EditIcon';
import DeleteIcon from './icons/DeleteIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import UploadIcon from './icons/UploadIcon';
import { INSTITUTIONAL_COLORS } from '../constants';

interface ManageGradesScreenProps {
  grades: Grade[];
  attendanceRecords: AttendanceRecord[]; // Added for validation
  addGrade: (name: string) => string | void;
  editGrade: (id: string, newName: string) => void;
  deleteGrade: (id: string) => void;
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const ManageGradesScreen: React.FC<ManageGradesScreenProps> = ({ 
  grades, 
  attendanceRecords,
  addGrade, 
  editGrade, 
  deleteGrade, 
  setCurrentView, 
  goBack, 
  canGoBack 
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingGrade, setEditingGrade] = useState<Grade | null>(null);
  const [gradeName, setGradeName] = useState('');
  const [error, setError] = useState('');

  // State for delete confirmation
  const [isDeleteConfirmModalOpen, setIsDeleteConfirmModalOpen] = useState(false);
  const [gradeToDeleteId, setGradeToDeleteId] = useState<string | null>(null);

  const openModalForAdd = useCallback(() => {
    setEditingGrade(null);
    setGradeName('');
    setError('');
    setIsModalOpen(true);
  }, []);

  const openModalForEdit = useCallback((grade: Grade) => {
    setEditingGrade(grade);
    setGradeName(grade.name);
    setError('');
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setEditingGrade(null);
    setGradeName('');
    setError('');
  }, []);

  const handleSubmit = useCallback(() => {
    if (!gradeName.trim()) {
      setError('El nombre del grado no puede estar vacío.');
      return;
    }
    if (grades.some(g => g.name.toLowerCase() === gradeName.trim().toLowerCase() && g.id !== editingGrade?.id)) {
      setError('Ya existe un grado con este nombre.');
      return;
    }

    if (editingGrade) {
      editGrade(editingGrade.id, gradeName.trim());
    } else {
      addGrade(gradeName.trim());
    }
    closeModal();
  }, [gradeName, editingGrade, grades, addGrade, editGrade, closeModal]);

  const handleDeleteInitiate = useCallback((id: string) => {
    setGradeToDeleteId(id);
    setIsDeleteConfirmModalOpen(true);
  }, []);

  const confirmDeleteGrade = useCallback(() => {
    if (!gradeToDeleteId) return;

    const hasAttendanceRecords = attendanceRecords.some(record => record.gradeId === gradeToDeleteId);

    if (hasAttendanceRecords) {
      alert("No se puede eliminar este grado porque tiene registros de asistencia asociados.");
      setIsDeleteConfirmModalOpen(false);
      setGradeToDeleteId(null);
      return;
    }

    deleteGrade(gradeToDeleteId);
    alert("El grado se ha eliminado correctamente.");
    setIsDeleteConfirmModalOpen(false);
    setGradeToDeleteId(null);
  }, [gradeToDeleteId, deleteGrade, attendanceRecords]);

  const closeDeleteConfirmModal = useCallback(() => {
    setIsDeleteConfirmModalOpen(false);
    setGradeToDeleteId(null);
  }, []);


  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-6 gap-3">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE}`}>Gestionar Grados</h2>
        <div className="flex space-x-2">
          <Button onClick={() => setCurrentView(ScreenView.BULK_UPLOAD_COURSES)} variant="secondary" leftIcon={<UploadIcon className="w-5 h-5"/>}>
            Carga Masiva (Excel)
          </Button>
          <Button onClick={openModalForAdd} leftIcon={<PlusIcon className="w-5 h-5" />}>
            Nuevo Grado
          </Button>
        </div>
      </div>
      
      {grades.length === 0 ? (
        <p className="text-gray-600 text-center py-10">No hay grados creados. Haga clic en "Nuevo Grado" o "Carga Masiva" para comenzar.</p>
      ) : (
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {grades.map((grade) => (
              <li key={grade.id} className="p-4 flex justify-between items-center hover:bg-gray-50 transition-colors">
                <span className="text-lg text-gray-700">{grade.name}</span>
                <div className="space-x-2">
                  <Button variant="ghost" size="sm" onClick={() => openModalForEdit(grade)} leftIcon={<EditIcon className="w-4 h-4" />}>Editar</Button>
                  <Button variant="danger" size="sm" onClick={() => handleDeleteInitiate(grade.id)} leftIcon={<DeleteIcon className="w-4 h-4" />}>Eliminar</Button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title={editingGrade ? 'Editar Grado' : 'Nuevo Grado'}
        footer={
          <>
            <Button variant="ghost" onClick={closeModal}>Cancelar</Button>
            <Button onClick={handleSubmit}>{editingGrade ? 'Guardar Cambios' : 'Crear Grado'}</Button>
          </>
        }
      >
        <div>
          <label htmlFor="gradeName" className="block text-sm font-medium text-gray-700 mb-1">Nombre del Grado</label>
          <input
            type="text"
            id="gradeName"
            value={gradeName}
            onChange={(e) => setGradeName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
            placeholder="Ej: 6°A, Décimo B"
          />
          {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
           <p className="text-xs text-gray-500 mt-2">Asegúrese que el nombre sea único.</p>
        </div>
      </Modal>

      {/* Delete Confirmation Modal */}
      <Modal
        isOpen={isDeleteConfirmModalOpen}
        onClose={closeDeleteConfirmModal}
        title="Confirmar Eliminación"
        footer={
          <>
            <Button variant="ghost" onClick={closeDeleteConfirmModal}>Cancelar</Button>
            <Button variant="danger" onClick={confirmDeleteGrade}>Sí, eliminar</Button>
          </>
        }
      >
        <p className="text-gray-700">
          ¿Estás seguro de que deseas eliminar este grado?
        </p>
        <p className="text-sm text-red-600 mt-1">
          Esta acción eliminará también todos los estudiantes registrados en él.
        </p>
      </Modal>
    </div>
  );
};

export default ManageGradesScreen;
