
import React, { useState, useCallback } from 'react';
import { Period, ScreenView } from '../types';
import Button from './Button';
import Modal from './Modal';
import PlusIcon from './icons/PlusIcon';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import { INSTITUTIONAL_COLORS } from '../constants';

interface ConfigurePeriodsScreenProps {
  periods: Period[];
  activePeriodId: string | null;
  addPeriod: (name: string) => void;
  setActivePeriodId: (id: string) => void;
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const ConfigurePeriodsScreen: React.FC<ConfigurePeriodsScreenProps> = ({
  periods,
  activePeriodId,
  addPeriod,
  setActivePeriodId,
  setCurrentView,
  goBack,
  canGoBack
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [periodName, setPeriodName] = useState('');
  const [error, setError] = useState('');

  const openModal = useCallback(() => {
    setPeriodName('');
    setError('');
    setIsModalOpen(true);
  }, []);

  const closeModal = useCallback(() => {
    setIsModalOpen(false);
    setPeriodName('');
    setError('');
  }, []);

  const handleSubmit = useCallback(() => {
    if (!periodName.trim()) {
      setError('El nombre del periodo no puede estar vacío.');
      return;
    }
    if (periods.some(p => p.name === periodName.trim())) {
      setError('Ya existe un periodo con este nombre.');
      return;
    }
    addPeriod(periodName.trim());
    closeModal();
  }, [periodName, periods, addPeriod, closeModal]);

  return (
    <div className="p-6 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="flex justify-between items-center mb-6">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE}`}>Configurar Periodos Académicos</h2>
        <Button onClick={openModal} leftIcon={<PlusIcon className="w-5 h-5" />}>
          Nuevo Periodo
        </Button>
      </div>

      {periods.length === 0 ? (
        <p className="text-gray-600 text-center py-10">No hay periodos creados. Haga clic en "Nuevo Periodo" para comenzar.</p>
      ) : (
        <div className="bg-white shadow-md rounded-lg overflow-hidden">
          <ul className="divide-y divide-gray-200">
            {periods.map((period) => (
              <li
                key={period.id}
                className={`p-4 flex justify-between items-center transition-colors ${
                  period.id === activePeriodId ? `bg-${INSTITUTIONAL_COLORS.YELLOW} bg-opacity-30` : 'hover:bg-gray-50'
                }`}
              >
                <span className={`text-lg ${period.id === activePeriodId ? `font-semibold text-${INSTITUTIONAL_COLORS.BLUE}` : 'text-gray-700'}`}>
                  {period.name}
                  {period.id === activePeriodId && <span className="ml-2 text-sm text-green-600">(Activo)</span>}
                </span>
                {period.id !== activePeriodId && (
                  <Button variant="secondary" size="sm" onClick={() => setActivePeriodId(period.id)}>
                    Marcar como Activo
                  </Button>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}
      
      {/* Removed "Volver al Resumen del Día" button */}

      <Modal
        isOpen={isModalOpen}
        onClose={closeModal}
        title="Nuevo Periodo Académico"
        footer={
          <>
            <Button variant="ghost" onClick={closeModal}>Cancelar</Button>
            <Button onClick={handleSubmit}>Crear Periodo</Button>
          </>
        }
      >
        <div>
          <label htmlFor="periodName" className="block text-sm font-medium text-gray-700 mb-1">Nombre del Periodo</label>
          <input
            type="text"
            id="periodName"
            value={periodName}
            onChange={(e) => setPeriodName(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-institucional-blue focus:border-institucional-blue"
            placeholder="Ej: Cuarto Periodo, Periodo Final"
          />
          {error && <p className="text-red-500 text-sm mt-1">{error}</p>}
          <p className="text-xs text-gray-500 mt-2">Asegúrese que el nombre sea único.</p>
        </div>
      </Modal>
    </div>
  );
};

export default ConfigurePeriodsScreen;