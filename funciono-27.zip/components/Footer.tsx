
import React from 'react';
import { FOOTER_TEXT, AUTHOR_NAME } from '../constants'; // Added AUTHOR_NAME

const Footer: React.FC = () => {
  return (
    <footer className={`bg-gray-200 text-center p-4 text-gray-600`}>
      <p className="text-sm">{FOOTER_TEXT}</p>
      <p className="text-xs text-gray-500 mt-1">{AUTHOR_NAME}</p>
    </footer>
  );
};

export default Footer;