
import React from 'react';
import { ScreenView } from '../types';
import Button from './Button';
import ArrowLeftIcon from './icons/ArrowLeftIcon';
import IdentificationIcon from './icons/IdentificationIcon'; // For "Por Grado"
import DesktopComputerIcon from './icons/DesktopComputerIcon'; // For "General"
import { INSTITUTIONAL_COLORS } from '../constants';

interface ComputerReportsHubScreenProps {
  setCurrentView: (view: ScreenView) => void;
  goBack: () => void;
  canGoBack: boolean;
}

const ComputerReportsHubScreen: React.FC<ComputerReportsHubScreenProps> = ({ setCurrentView, goBack, canGoBack }) => {
  
  const hubItems = [
    { 
      label: 'Reporte por Computadores – Por Grado', 
      icon: <IdentificationIcon className="w-10 h-10" />, 
      view: ScreenView.COMPUTER_USAGE_BY_GRADE_REPORT,
      color: 'primary' as 'primary' | 'secondary' | 'ghost',
      description: "Visualiza el uso de computadores detallado por estudiante dentro de un grado específico."
    },
    { 
      label: 'Reporte por Computadores – General', 
      icon: <DesktopComputerIcon className="w-10 h-10" />, 
      view: ScreenView.COMPUTER_USAGE_GENERAL_REPORT,
      color: 'secondary' as 'primary' | 'secondary' | 'ghost',
      description: "Obtén una vista general de qué estudiante usó cada computador en fechas seleccionadas, a través de todos los grados."
    },
  ];

  return (
    <div className="p-6 md:p-10 animate-fadeIn">
      {canGoBack && (
        <div className="mb-6">
          <Button onClick={goBack} variant="ghost" size="sm" leftIcon={<ArrowLeftIcon className="w-5 h-5" />}>
            Regresar
          </Button>
        </div>
      )}
      <div className="text-center mb-8">
        <h2 className={`text-2xl font-bold text-${INSTITUTIONAL_COLORS.BLUE} mb-3`}>
          Reportes de Uso de Computadores
        </h2>
        <p className="text-gray-600">
          Seleccione el tipo de reporte que desea generar.
        </p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hubItems.map((item) => (
          <Button
            key={item.label}
            variant={item.color}
            size="lg"
            className="flex flex-col items-center justify-start text-center p-6 !h-auto min-h-[200px] transform hover:scale-105 transition-transform duration-200 !font-medium"
            onClick={() => setCurrentView(item.view)}
            aria-label={item.label}
          >
            {React.cloneElement(item.icon, { 
              className: `w-12 h-12 mb-3 ${
                item.color === 'primary' ? 'text-institucional-yellow' 
                : item.color === 'secondary' ? 'text-institucional-blue' 
                : 'text-gray-700' // Should not happen with current config
              }` 
            })}
            <span className="text-lg mb-2">{item.label}</span>
            <p className={`text-sm font-normal ${item.color === 'primary' ? 'text-gray-100' : 'text-gray-700'} opacity-90`}>
              {item.description}
            </p>
          </Button>
        ))}
      </div>
       <p className="text-center text-gray-500 mt-12 text-sm">
        Estos reportes ayudan a llevar una trazabilidad del uso de los equipos.
      </p>
    </div>
  );
};

export default ComputerReportsHubScreen;